# Tok vreća do kutija — prijedlog nakon pregleda izvornog KIP-a

Status 25.09.2026: završetak verifikacije, raspodjela prihvaćenih koverti i kutije do statusa Napunjena su implementirani. Važeći obuhvat i postupak su u UPGRADE-PACKAGING.md. Donji tekst čuva raniju analizu; zaseban prijem odbijenih/KR, sortiranje i skeneri nisu implementirani.

Pregledani izvori na main grani sulejmanhasanovic/gcb: Tracking/CreateBox.aspx i .aspx.cs, BagsPackaging.aspx i .aspx.cs, BagsPackagingDetail.aspx i .aspx.cs, BagsUpdateVerification.aspx.cs, BoxFillDetails.aspx.cs, te slike KIP formiranje kutije.png i Kip obrada vrece.png.

## Nalazi

- CreateBox bira tip vreće i kombinaciju, pa kreira kutiju. Slika prikazuje Poštu i K600.
- BagsPackaging učitava primljene, prihvaćene i odbijene količine nakon verifikacije.
- BagsPackagingDetail upisuje kombinaciju, broj iz spiska, potpise, prebrojane koverte, razliku i odredišnu kutiju. Izbor kutija poziva proceduru s tipom i kombinacijom. Tijelo te procedure nije provjereno.
- Zapis je veza vreća–kutija–kombinacija s količinom. Kod ne ograničava kutiju na jednu izvornu vreću. Jedna vreća može imati više stavki za različite kombinacije/kutije.
- Završetak pakovanja traži da zbir redovnih stavki odgovara prihvaćenim kovertama, a zbir KR stavki odbijenim. Stari KR tretman je referenca za dogovor, ne automatski usvojeno novo pravilo.
- BoxFillDetails razlikuje punjenje i zatvaranje kutije.
- Stara verifikacija poredi količine sa skeniranim biračima. Korisnik traži nezavisno skeniranje, pa ovu vezu ne prenositi niti koristiti VoteCast za količine KIP-a.

## Predloženi tok

Generisanje vreće → prijem → kontrolno brojanje → priprema → prijem na verifikaciju → rezultat i završetak verifikacije → KIP raspodjela po kombinacijama → punjenje kutija → zatvaranje kutije.

Postojeći BagStage.Verification znači samo primljeno na verifikaciju. Nije dokaz da je verifikacija završena. Dodati zaseban konačni rezultat, bez prepisivanja ranijih količina pripreme.

Za svaku vreću čuvati konačno prihvaćeno/odbijeno, razloge, operatera i vrijeme. Prihvaćeno + odbijeno mora odgovarati količini primljenoj na verifikaciju. Odbijeno u pripremi i odbijeno na verifikaciji su različite količine; njihov daljnji tok treba eksplicitno dogovoriti.

Kutiju kreirati za izborne šifre, kategoriju i kombinaciju; može biti prazna prije punjenja. Korisnik je dostavio izvorne statuse: 1 Formirana, 2 Napunjena, 3 Na sortiranju, 4 Sortirana, 5 Na brojanju, 6 Prebrojana, 7 Arhivirana. Trenutni predloženi obuhvat završava statusom Napunjena. Stari BoxFillDetails pri zatvaranju postavlja 3, što znači slanje na sortiranje. Nova stavka smije ići samo u kutiju dostupnu za punjenje, iste kategorije i kombinacije. Bez automatskog miješanja kategorija.

Veza je više-prema-više: BoxItems s BagId, BoxId, CombinationId i Quantity te operaterom/vremenom. Broj u kutiji se izvodi iz stavki; ne prepisivati samo zbir bez porijekla. Ista količina iz vreće ne smije biti dodijeljena dvaput. Podjela jedne kombinacije iz vreće između više kutija mora biti moguća ako je potrebna zbog kapaciteta.

Prikaz vreće: prihvaćeno nakon verifikacije, raspoređeno, preostalo, odbijeno i status obrade. Prikaz kutije: kategorija, kombinacija, ukupan broj koverti, izvorne vreće i njihove količine, historija. Završena obrada vreće tek kada je sav relevantni materijal raspoređen/evidentiran.

Zatvaranje kutije zaključava stavke. Korekcije uz razlog i ovlaštenje, s auditom. Verifikacija vreće koja ima stavke u kutijama ne smije se mijenjati bez kontrolisanog razduženja. Upis raspodjele i ažuriranje statusa vreće/kutije moraju biti atomski uz kontrolu paralelnih promjena.

Meni: Generisanje vreća; Prijem pošiljki; Prijem i verifikacija; KIP — Obrada vreća, Formiranje i pregled kutija; Skeniranje; Administracija. Šifrarnik kombinacija pripada Administraciji.

## Za razjasniti prije implementacije zavisnih pravila

1. Šifrarnik kombinacija je dostavljen u combinations.sql (nalazi ispod). Ostaje način utvrđivanja broja prihvaćenih koverti po kombinaciji, nezavisno od VoteCast. Prijedlog: ručni unos po kombinaciji na KIP-u uz provjeru ukupnog rezultata verifikacije.
2. Da li odbijene koverte i dalje idu u posebne KR kutije; obuhvata li to i odbijene u pripremi ili samo poslije verifikacije?
3. Postoji li maksimalan broj koverti po kutiji? Ako ne, zatvaranje je ručna operacija; ne uvoditi proizvoljan kapacitet.

Primjer: dvije vreće Pošte daju 80 i 120 prihvaćenih koverti kombinacije K01. Kutija Pošta/K01 sadrži 200 koverti kroz dvije odvojene stavke, čuvajući porijeklo svake količine.

## Dostavljeni šifrarnik kombinacija — 25.09.2026.

Izvor: https://github.com/sulejmanhasanovic/gcb/blob/main/combinations.sql

- p3_Combinations sadrži 152 reda s jedinstvenim MunicipalityCode: 24 kombinacije K01–K24 i posebni KXX. Više opština dijeli kombinaciju. Unutar svake kombinacije vrijednosti osam Tip kolona su jednake.
- KXX pripada šifri 200, Brčko distrikt, sa zvjezdicama u svim Tip kolonama. Ne tretirati ga kao običnu kombinaciju za pakovanje bez razjašnjenja. Brčko opcija FBiH (027) ima K24, a opcija RS (028) K20.
- MunicipalityCode199 se razlikuje od MunicipalityCode za sedam mostarskih šifri 151–157, koje sve mapiraju na 199. Sačuvati oba podatka i vodeće nule šifri.
- K600 sa ranije slike ne postoji u ovom šifrarniku. Tip600 je zasebna kolona i nije šifra kombinacije.
- Predložena nova struktura: Combinations (po izborima, jedinstveni Code i izvorne Tip vrijednosti), MunicipalityCombinations (po izborima, MunicipalityCode, MunicipalityCode199, nazivi, Entity i veza na kombinaciju). Nazive prilagoditi konvencijama aplikacije; značenje Tip kolona ne preimenovati napamet.
- Šifrarnik određuje kombinaciju prema opštini za koju se glasa; sam ne sadrži količine koverti. Ne pretpostavljati da je opština fizičkog biračkog mjesta dovoljna za sadržaj cijele vreće.
- p3_BoxDetail predstavlja rezultate po LevelCode za kasnije sortiranje/brojanje; nije zamjena za vezu izvorne vreće i kutije. TotalNoOfEnvelopes nove kutije izvoditi iz stavki pakovanja. RejectedInSorting odvojiti od odbijanja na verifikaciji. Dostavljena vrijednost POBox 451 nije podatak o kapacitetu kutije.

Ovo je dopuna analize; šifrarnik nije još uvezen i KIP nije implementiran.

## Prijem odbijenih materijala — dodatni pregled

Pregledani DeniedBagsReceiveVerification.aspx/.cs, povezana AddEditDeniedVoter.aspx/.cs i slika Verifikacija prijem odbijenih materijala.png na main grani.

- Posebna forma bira tip odbijene vreće i njen broj, prima količinu koverti, prikazuje zaprimljene vreće i vodi na pojedinačnu evidenciju odbijenih birača. Ta evidencija ima JMB, ime, prezime, vreću i razlog iz šifrarnika; dopušta dodavanje i brisanje.
- Referenca na BeforeVerificationRejected u kodu sugeriše prijem materijala odbijenog prije verifikacije. Ta dodjela i prikaz datuma su komentarisani, pa tačan izbor vreća treba potvrditi tijelom p3_getDeniedBagsForTypeOfPS_Verification. Sam naziv forme ne dokazuje kako su odbijene vreće nastale niti njihovu vezu s KR kutijama.
- Snimanje poziva p3_VerificationReceivedEnvelopesUpdate i p3_ActivateBagforScanning. Poziv aktivacije skeniranja ne prenositi u novu aplikaciju jer je skeniranje nezavisno.
- Provjera primljene i očekivane količine je komentarisana. Na povezanoj formi komentarisana je i kontrola broja evidentiranih odbijenih birača. Dugme Završi samo vraća na prijemnu stranicu, bez eksplicitnog završnog statusa u tom handleru. To nisu pouzdana nova poslovna pravila.
- Predložiti zasebnu granu pod Prijem i verifikacija: Prijem odbijenog materijala → Evidencija odbijenih. Čuvati vezu s izvornom vrećom, porijeklo/fazu odbijanja, količine i operatera/vrijeme, bez prepisivanja prijema prihvaćenog dijela. Pojedinačna evidencija odbijanja ne smije automatski kreirati ili mijenjati VotesCast.
- Ostaje dogovor o fizičkom formiranju odbijenih vreća, obaveznosti pojedinačne evidencije kada JMB nije poznat/čitljiv i eventualnom pakovanju u KR kutije. Nova forma sama ne rješava te tačke.

Ova grana je zasad samo analizirana, nije implementirana.
