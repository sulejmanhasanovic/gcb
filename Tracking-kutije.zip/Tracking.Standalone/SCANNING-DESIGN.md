# Evidentiranje izlaznosti — struktura i odluke

Status: modul je implementiran. Operativne upute, ograničenja i redoslijed skripti su u UPGRADE-SCANNING.md. Ovo je bilješka o mapiranju i poslovnim odlukama; izvršne skripte su database/05-upgrade-scanning.sql i database/06-import-voters.sql.

Izvor: `sulejmanhasanovic/gcb`, grana `main`, `voter_votecast_insert sp.sql`.

Skeniranje je nezavisno od prijema, vreća i verifikacije. JMBG se unosi tastaturom ili skenerom. Evidencija ne sadrži izbor za koga je birač glasao.

## Voters

| Izvor Voter | Naziv u aplikaciji | Pravilo |
| --- | --- | --- |
| ID | Id | Interni ključ; stari ID sačuvati kao SourceId pri migraciji između baza |
| RegID | Jmbg | Tekst od 13 cifara; identifikator za skeniranje, početne nule ostaju |
| Eligible | IsEligible | Pravo postoji samo kada je izvorna vrijednost `1`; NULL i ostale vrijednosti nisu pravo glasa |
| TypeOfPollingStationCode | SourceTypeCode | Izvorna oznaka, kao u postojećem PollingStation modelu |
| PollingStation / PSCode | PollingStationCode | Tekst do 10 znakova; uvoz koristi PSCode ako postoji, inače PollingStation |
| FirstName | FirstName | Sačuvati dužinu 60 |
| LastName | LastName | Sačuvati dužinu 60 |
| ParentsName | ParentsName | Sačuvati dužinu 50 |
| DateOfBirth | DateOfBirth | Nullable datum |
| VoteForMunicipalityCode | VoteForMunicipalityCode | Opština za koju glasa |
| VoteInMunicipalityCode | VoteInMunicipalityCode | Opština u kojoj glasa |
| CurrentMunicipalityCode | CurrentMunicipalityCode | Sačuvati izvorni tekst |
| — | ElectionCode | Kao postojeći registar mjesta; jedinstvenost JMBG po izborima |

Izvorni `PersonalID` je zasebna kolona i ne zamjenjuje automatski `RegID`. Ostale izvorne kolone ne brisati niti mijenjati u postojećoj bazi. Konačna uvozna skripta mora eksplicitno navesti kolone; bez SELECT * i bez zamjene postojeće Voter tabele. Sačuvati izvorni Eligible kao SourceEligibilityCode radi provjere uvoza.

## Kategorije

| SourceTypeCode | Kategorija |
| --- | --- |
| 1 | Redovni |
| 2 | Odsustvo |
| M | Mobilni |
| N | Nepotvrđeni |
| O | Pošta |
| D | DKP |

Nepoznat kod se ne pretvara u Redovne. Tip skeniranja voditi zasebnim enumom od IntakeGroup, kako Redovni ne bi postali kategorija prijema vreća. Postojeći registar mjesta podržava samo specijalna mjesta; podršku za redovna mjesta treba dodati bez uključivanja u generisanje vreća.

## VotesCast — prihvaćene evidencije

- Id: bigint interni ključ.
- ElectionCode, VoterId: izbori i birač; zaštita od dvostrukog aktivnog evidentiranja istog birača na nivou baze, uključujući paralelne operatere.
- ScanningSessionId: sesija kojoj zapis pripada.
- Category: kategorija u kojoj je evidentiran.
- RegisteredPollingStationCode, RegisteredSourceTypeCode: stanje registracije u trenutku unosa, odvojeno od mjesta koje operater skenira.
- CreatedById: nvarchar(450), veza na AspNetUsers.Id, umjesto starog Clerk int.
- CreatedAtUtc: datetime2, umjesto TimeVerified; vrijeme postavlja server.

Stari Name/Surname imaju samo 50 znakova, dok Voter podržava 60; ne skraćivati imena pri eventualnom čuvanju snimka. Stari PSBag nije pouzdana zamjena za vezu na biračko mjesto. Stari Mode i TypeOfVote ne koristiti kao izvorne Voter kodove: npr. TypeOfVote O znači Odsustvo, dok Voter kod O znači Pošta.

Odbijeni pokušaji pripadaju zasebnoj ScanAttempts evidenciji: sesija, pronađeni VoterId ako postoji, rezultat/razlog, operater i UTC vrijeme. Ne povećavaju izlaznost. Za pristup pokušajima i prikaz JMBG koristiti ovlaštenja aplikacije; JMBG ne slati u URL ili opšte aplikacijske logove.

## ScanningSessions — status skeniranja

- Id, ElectionCode, Category, PollingStationId (za Poštu NULL).
- Jedna sesija po izborima, kategoriji i mjestu; za Poštu jedna zajednička sesija po izborima.
- Status: Započeto, U toku, Završeno. Prije otvaranja sesije pregled prikazuje Nije započeto.
- StartedById / StartedAtUtc, CompletedById / CompletedAtUtc.
- Version: Guid, kao postojeći modeli, za zaštitu paralelnih promjena.
- Otvaranje daje Započeto; prvi prihvaćen unos daje U toku; dugme Završi skeniranje daje Završeno.
- Završena sesija ne prima nove unose. Završavanje i upis moraju biti međusobno usklađeni transakcijom, uključujući rad više operatera.

Broj evidentiranih birača izračunavati iz prihvaćenih VotesCast zapisa. Broj birača s pravom glasa voditi odvojeno: stara procedura povećava TotalVoters prilikom skeniranja, što nije odgovarajući naziv za ukupan broj registrovanih birača.

## Provjere unosa

1. Sesija je otvorena i operater ima pravo skeniranja.
2. JMBG je tekst od 13 cifara i birač postoji u odabranim izborima.
3. Eligible je 1.
4. Izvorni tip odgovara pravilima odabrane kategorije.
5. Za skeniranje po mjestu provjeriti pripadnost tom mjestu; Pošta je zajednička kategorija.
6. Nema prethodno prihvaćene evidencije tog birača u istim izborima.
7. Atomski snimiti evidenciju, operatera, vrijeme i promjenu statusa.

## Otvorena poslovna pravila

- Uvoz automatski koristi PSCode ako postoji, inače PollingStation; odabrani naziv prikazuje u rezultatu.
- Potvrđeno: sve kategorije po mjestu koriste istu provjeru prava, tipa, pripadnosti mjestu i duplikata. Nepotvrđeni prihvataju samo svoj tip N; stari izuzetak za O se ne prenosi.
- Redoslijed Nepotvrđeni → Odsustvo → Mobilni → Pošta je poznat; još nije određeno da li je obavezna blokada naredne kategorije te gdje ulaze DKP i Redovni.
- Stara procedura za Nepotvrđene ima prihvat preko imena i datuma rođenja kada JMBG nije pronađen. To ne prenositi bez izričitog zahtjeva: novi opis zahtijeva provjeru JMBG u Voteru.
- Eventualno poništavanje zapisa i ponovno otvaranje mjesta zahtijevaju dogovor o ulozi i obaveznom razlogu, uz audit.

U starim procedurama nedostaju aktivna provjera Eligible i poređenje sa mjestom koje se skenira. Pravila duplikata razlikuju se među kategorijama. Koriste @@IDENTITY i više odvojenih upisa bez jedinstvene transakcije. Zato ih ne preimenovati i pokrenuti neizmijenjene u novom modulu.

## Potvrđena organizacija i pregled slika

Redovni koriste isti pojedinačni unos kao specijalne kategorije. Otvaranje mjesta kreira samo sesiju/status; nema prethodnog kopiranja birača iz Voters u VotesCast.

Pregledane slike iz korijena grane main: `Aktivacija skeniranja.png` i `Skeniranje.png`. Aktivacija prikazuje izbor označen Broj vreće sa šifrom 001A501 i dugme Aktiviraj. Skeniranje prikazuje istu šifru, rezultat provjere, broj prihvaćenih/odbijenih, unos bar-koda, Scan, Finish i tabelu pokušaja. U novom modulu naziv je Biračko mjesto, unos JMBG, dugmad Započni skeniranje i Završi skeniranje. Pokušaji imaju jasno odvojen rezultat i razlog; odbijen pokušaj ne postaje glas u izlaznosti. Izgled zadržava stil nove aplikacije.

Pošta ostaje zajednička kategorija bez provjere pripadnosti otvorenom biračkom mjestu. Slike ne potvrđuju poseban zahtjev za poštanskim brojem vreće, pa ga ne uvoditi kao uslov skeniranja.

Redoslijed menija: Generisanje vreća; Prijem pošiljki sa kategorijama; Prijem i verifikacija sa fazama; Skeniranje sa kategorijama Nepotvrđeni, Odsustvo, Mobilni, Pošta, DKP, Redovni; Administracija sa Biračkim mjestima, Razlozima odbijanja i Korisnicima i ulogama. Raspored DKP/Redovnih u meniju nije blokada operativnog redoslijeda. Sve stavke skeniranja sada vode na odgovarajuće kategorije; aktivna grupa menija se automatski otvara.
