using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Controllers;
public class AccountController(SignInManager<AppUser> signIn, UserManager<AppUser> users) : Controller {
    [AllowAnonymous]
    public async Task<IActionResult> Login(string? returnUrl) {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Intake");
        ViewData["NeedsSetup"] = !await users.Users.AnyAsync();
        return View(new LoginInput { ReturnUrl = returnUrl });
    }
    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> Login(LoginInput input) {
        if (ModelState.IsValid) {
            var result = await signIn.PasswordSignInAsync(input.UserName.Trim(), input.Password, false, lockoutOnFailure: true);
            if (result.Succeeded) return Url.IsLocalUrl(input.ReturnUrl) ? LocalRedirect(input.ReturnUrl!) : RedirectToAction("Index", "Intake");
            ModelState.AddModelError("", "Prijava nije uspjela. Provjerite podatke ili pokušajte ponovo za 15 minuta.");
        }
        ViewData["NeedsSetup"] = !await users.Users.AnyAsync();
        return View(input);
    }
    [HttpPost]
    public async Task<IActionResult> Logout() { await signIn.SignOutAsync(); return RedirectToAction(nameof(Login)); }
    public IActionResult Password() => View(new PasswordInput());
    [HttpPost]
    public async Task<IActionResult> Password(PasswordInput input) {
        if (ModelState.IsValid) {
            var user = (await users.GetUserAsync(User))!;
            var result = await users.ChangePasswordAsync(user, input.CurrentPassword, input.NewPassword);
            if (result.Succeeded) { await signIn.RefreshSignInAsync(user); TempData["Success"] = "Lozinka je promijenjena."; return RedirectToAction(nameof(Password)); }
            ModelState.AddModelError("", "Promjena nije uspjela. Provjerite trenutnu lozinku; nova mora imati najmanje 12 znakova, veliko i malo slovo, broj i poseban znak.");
        }
        return View(input);
    }
    public IActionResult Denied() { Response.StatusCode = 403; return View(); }
    [AllowAnonymous]
    public IActionResult Error() { Response.StatusCode = 500; return View(); }
}
