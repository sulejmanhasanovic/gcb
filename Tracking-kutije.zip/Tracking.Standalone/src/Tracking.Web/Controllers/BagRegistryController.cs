using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;

[Authorize(Policy = Permissions.View)]
public class BagRegistryController(TrackingDbContext db, BagRegistryService registry, UserManager<AppUser> users) : Controller {
    public async Task<IActionResult> Index(IntakeGroup? group, string? search, bool? received, int page = 1) {
        if (!ModelState.IsValid || (group.HasValue && !Enum.IsDefined(group.Value))) return BadRequest();
        page = Math.Clamp(page, 1, 100000); search = search?.Trim();
        var q = db.GeneratedBags.AsNoTracking();
        if (group.HasValue) q = q.Where(x => x.Group == group.Value);
        if (received.HasValue) q = q.Where(x => (x.Receipt != null) == received.Value);
        if (!string.IsNullOrWhiteSpace(search)) {
            var term = search.ToUpperInvariant();
            q = q.Where(x => x.Barcode.Contains(term) || (x.PollingStation != null && (x.PollingStation.MunicipalityName!.Contains(term) || x.PollingStation.Name!.Contains(term))));
        }
        return View(new BagRegistryList {
            Bags = await q.Include(x => x.PollingStation).Include(x => x.Receipt).OrderByDescending(x => x.Id).Skip((page - 1) * 50).Take(50).ToListAsync(),
            Stations = await db.PollingStations.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Group).ThenBy(x => x.Code).ToListAsync(),
            Group = group, Search = search, Received = received, Page = page, Total = await q.CountAsync()
        });
    }
    [HttpPost, Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Generate(GenerateBagsInput input) {
        if (!ModelState.IsValid) { TempData["Error"] = "Provjerite kategoriju, količinu i biračko mjesto."; return RedirectToAction(nameof(Index)); }
        try {
            var count = await registry.GenerateAsync(input, (await users.GetUserAsync(User))!);
            TempData["Success"] = count == 0 ? "Sve odabrane vreće već postoje." : $"Generisano vreća: {count}.";
        } catch (IntakeException e) { TempData["Error"] = e.Message; }
        return RedirectToAction(nameof(Index), new { group = input.Group });
    }
    [HttpPost, Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Delete(int[] ids) {
        if (!ModelState.IsValid) return BadRequest();
        try { var count = await registry.DeleteAsync(ids, (await users.GetUserAsync(User))!); TempData["Success"] = $"Obrisano nezaprimljenih vreća: {count}."; }
        catch (IntakeException e) { TempData["Error"] = e.Message; }
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Stations(IntakeGroup? group, string? search, int page = 1) {
        if (!ModelState.IsValid || (group.HasValue && !Enum.IsDefined(group.Value))) return BadRequest();
        page = Math.Clamp(page, 1, 100000);
        var q = db.PollingStations.AsNoTracking();
        if (group.HasValue) q = q.Where(x => x.Group == group);
        if (!string.IsNullOrWhiteSpace(search)) { var term = search.Trim().ToUpperInvariant(); q = q.Where(x => x.Code.Contains(term) || x.MunicipalityName!.Contains(term) || x.Name!.Contains(term)); }
        ViewData["Group"] = group; ViewData["Search"] = search; ViewData["Page"] = page; ViewData["Total"] = await q.CountAsync();
        return View(await q.OrderBy(x => x.Code).Skip((page - 1) * 50).Take(50).ToListAsync());
    }
}
