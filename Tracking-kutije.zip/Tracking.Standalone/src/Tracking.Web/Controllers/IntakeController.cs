using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;
[Authorize(Policy = Permissions.View)]
public class IntakeController(TrackingDbContext db, IntakeService intake, UserManager<AppUser> users) : Controller {
    [Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> Direct(IntakeGroup group=IntakeGroup.Odsustvo) {
        if(!ModelState.IsValid||!Enum.IsDefined(group)||group==IntakeGroup.Posta)return BadRequest();
        await DirectOptions(group);return View(new DirectReceiptInput{Group=group});
    }
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> Direct(DirectReceiptInput input) {
        if(ModelState.IsValid)try{var id=await intake.DirectReceiptAsync(input,(await users.GetUserAsync(User))!);TempData["Success"]="Vreća je zaprimljena. Provjerite podatke i završite prijem.";return RedirectToAction(nameof(Details),new{id});}catch(IntakeException e){ModelState.AddModelError("",e.Message);}
        await DirectOptions(input.Group);return View(input);
    }
    private async Task DirectOptions(IntakeGroup group)=>ViewData["Bags"]=await db.GeneratedBags.AsNoTracking().Where(x=>x.Group==group&&x.Receipt==null&&x.PollingStation!.IsActive).OrderBy(x=>x.Barcode).ToListAsync();
    public async Task<IActionResult> Index(IntakeGroup? group, string? search, IntakeStatus? status, int page = 1) {
        if (!ModelState.IsValid || (group.HasValue && !Enum.IsDefined(group.Value)) || (status.HasValue && !Enum.IsDefined(status.Value))) return BadRequest();
        page = Math.Clamp(page, 1, 100000); search = search?.Trim();
        var q = db.Shipments.AsNoTracking();
        var counts = await q.GroupBy(x => x.Group).Select(g => new { Group = g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Group, x => x.Count);
        if (group.HasValue) q = q.Where(x => x.Group == group);
        if (status.HasValue) q = q.Where(x => x.Status == status);
        if (!string.IsNullOrWhiteSpace(search)) {
            var normalized = IntakeService.Normalize(search);
            q = q.Where(x => x.Reference.Contains(normalized) || x.Bags.Any(b => b.Barcode.Contains(normalized)));
        }
        var total = await q.CountAsync();
        var rows = await q.Include(x => x.Bags).Include(x => x.CreatedBy).OrderByDescending(x => x.Id).Skip((page - 1) * 25).Take(25).ToListAsync();
        return View(new IntakeList { Shipments = rows, Counts = counts, Group = group, Search = search, Status = status, Page = page, Total = total });
    }
    [Authorize(Policy = Permissions.Receive)]
    public IActionResult Create(IntakeGroup group = IntakeGroup.Posta) => ModelState.IsValid && Enum.IsDefined(group) ? View(new ShipmentInput { Group = group }) : BadRequest();
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> Create(ShipmentInput input) {
        if (ModelState.IsValid) try {
            var id = await intake.CreateAsync(input, (await users.GetUserAsync(User))!);
            TempData["Success"] = "Pošiljka je otvorena. Možete evidentirati vreće.";
            return RedirectToAction(nameof(Details), new { id });
        } catch (IntakeException e) { ModelState.AddModelError("", e.Message); }
        return View(input);
    }
    public async Task<IActionResult> Details(int id) {
        var model = await DetailModel(id);
        return model == null ? NotFound() : View(model);
    }
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> AddBag(int id, [Bind(Prefix = "Bag")] BagInput input) {
        if (ModelState.IsValid) try {
            await intake.AddBagAsync(id, input, (await users.GetUserAsync(User))!);
            TempData["Success"] = "Vreća je evidentirana.";
            return RedirectToAction(nameof(Details), new { id });
        } catch (IntakeException e) { ModelState.AddModelError("", e.Message); }
        db.ChangeTracker.Clear();
        var model = await DetailModel(id);
        if (model == null) return NotFound();
        model.Bag = input;
        return View("Details", model);
    }
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> Close(int id, Guid version) {
        if (!ModelState.IsValid) return BadRequest();
        try { await intake.CloseAsync(id, version, (await users.GetUserAsync(User))!); TempData["Success"] = "Prijem je završen."; }
        catch (IntakeException e) { TempData["Error"] = e.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }
    [Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Edit(int id) {
        var s = await db.Shipments.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id);
        if (s == null) return NotFound();
        if (s.Status != IntakeStatus.Open) { TempData["Error"] = "Završen prijem nije moguće mijenjati."; return RedirectToAction(nameof(Details), new { id }); }
        ViewData["ShipmentId"] = id;
        return View(new ShipmentInput { Reference = s.Reference, Group = s.Group, ReceivedDate = s.ReceivedDate, ExpectedEnvelopes = s.ExpectedEnvelopes,
            Undelivered = s.Undelivered, OtherMaterials = s.OtherMaterials, Comment = s.Comment, Version = s.Version });
    }
    [HttpPost, Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Edit(int id, ShipmentInput input) {
        if (ModelState.IsValid) try {
            await intake.EditAsync(id, input, (await users.GetUserAsync(User))!);
            TempData["Success"] = "Ispravka je sačuvana u historiji.";
            return RedirectToAction(nameof(Details), new { id });
        } catch (IntakeException e) { ModelState.AddModelError("", e.Message); }
        ViewData["ShipmentId"] = id; return View(input);
    }
    private async Task<IntakeDetails?> DetailModel(int id) {
        var s = await db.Shipments.AsNoTracking().Include(x => x.CreatedBy).Include(x => x.Materials).Include(x => x.Bags).ThenInclude(x => x.Entries).Include(x => x.Bags).ThenInclude(x => x.CreatedBy).SingleOrDefaultAsync(x => x.Id == id);
        return s == null ? null : new IntakeDetails { Shipment = s, Bag = new BagInput { Version = s.Version },
            Material = new() { Version = s.Version },
            AvailableBags = await db.GeneratedBags.AsNoTracking().Where(x => x.Group == s.Group && (x.Receipt == null || s.Group == IntakeGroup.Posta && x.Receipt.ShipmentId == id)).OrderBy(x => x.Barcode).ToListAsync(),
            History = await db.AuditEntries.AsNoTracking().Where(x => x.ShipmentId == id).OrderByDescending(x => x.Id).ToListAsync() };
    }
    [Authorize(Policy=Permissions.Correct)]
    public async Task<IActionResult> EditReceipt(int id,int entryId) {
        var e=await db.BagReceiptEntries.AsNoTracking().Include(x=>x.Bag).ThenInclude(x=>x.Shipment).SingleOrDefaultAsync(x=>x.Id==entryId&&x.Bag.ShipmentId==id);
        if(e==null)return NotFound(); if(e.Bag.Shipment.Status!=IntakeStatus.Open)return BadRequest();
        ViewData["ShipmentId"]=id;ViewData["Group"]=e.Bag.Shipment.Group;
        return View(new ReceiptEditInput { EntryId=e.Id,Version=e.Bag.Shipment.Version,Barcode=e.Bag.Barcode,RegularEnvelopes=e.RegularEnvelopes,ExpressEnvelopes=e.ExpressEnvelopes,TotalEnvelopes=e.TotalEnvelopes,PoBox=e.PoBox,Comment=e.Comment });
    }
    [HttpPost,Authorize(Policy=Permissions.Correct)]
    public async Task<IActionResult> EditReceipt(int id,ReceiptEditInput input) {
        if(ModelState.IsValid)try{await intake.EditReceiptAsync(id,input,(await users.GetUserAsync(User))!);TempData["Success"]="Ispravka je sačuvana.";return RedirectToAction(nameof(Details),new{id});}catch(IntakeException e){ModelState.AddModelError("",e.Message);}
        var s=await db.Shipments.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id);if(s==null)return NotFound();
        ViewData["ShipmentId"]=id;ViewData["Group"]=s.Group;return View(input);
    }
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> AddMaterial(int id,[Bind(Prefix="Material")] MaterialInput input) {
        if(input.EntryId!=0)return BadRequest();
        if(ModelState.IsValid)try{await intake.SaveMaterialAsync(id,input,(await users.GetUserAsync(User))!);TempData["Success"]="Materijal je evidentiran.";return RedirectToAction(nameof(Details),new{id});}catch(IntakeException e){ModelState.AddModelError("",e.Message);}
        db.ChangeTracker.Clear();var m=await DetailModel(id);if(m==null)return NotFound();m.Material=input;return View("Details",m);
    }
    [Authorize(Policy=Permissions.Correct)]
    public async Task<IActionResult> EditMaterial(int id,int entryId) {
        var e=await db.MaterialReceipts.AsNoTracking().Include(x=>x.Shipment).SingleOrDefaultAsync(x=>x.Id==entryId&&x.ShipmentId==id);if(e==null)return NotFound();if(e.Shipment.Status!=IntakeStatus.Open)return BadRequest();
        ViewData["ShipmentId"]=id;return View(new MaterialInput{EntryId=e.Id,Version=e.Shipment.Version,IsUndelivered=e.IsUndelivered,Quantity=e.Quantity,Comment=e.Comment});
    }
    [HttpPost,Authorize(Policy=Permissions.Correct)]
    public async Task<IActionResult> EditMaterial(int id,MaterialInput input) {
        if(input.EntryId==0)return BadRequest();
        if(ModelState.IsValid)try{await intake.SaveMaterialAsync(id,input,(await users.GetUserAsync(User))!);TempData["Success"]="Ispravka materijala je sačuvana.";return RedirectToAction(nameof(Details),new{id});}catch(IntakeException e){ModelState.AddModelError("",e.Message);}
        ViewData["ShipmentId"]=id;return View(input);
    }
}
