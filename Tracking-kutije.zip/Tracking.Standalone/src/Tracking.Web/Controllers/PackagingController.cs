using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;
[Authorize(Policy=Permissions.View)]
public class PackagingController(TrackingDbContext db,PackagingService service,UserManager<AppUser> users):Controller {
    public async Task<IActionResult> Index(IntakeGroup? group,BoxStatus? status,int page=1) {
        if(!ModelState.IsValid||group.HasValue&&!Enum.IsDefined(group.Value)||status.HasValue&&!Enum.IsDefined(status.Value))return BadRequest();
        page=Math.Clamp(page,1,100000);var q=db.Boxes.AsNoTracking().AsQueryable();
        if(group.HasValue)q=q.Where(x=>x.Group==group);if(status.HasValue)q=q.Where(x=>x.Status==status);
        return View(new BoxList {Group=group,Status=status,Page=page,Total=await q.CountAsync(),Boxes=await q.Include(x=>x.Combination).Include(x=>x.Items).OrderByDescending(x=>x.Id).Skip((page-1)*25).Take(25).ToListAsync(),Combinations=await db.Combinations.AsNoTracking().Where(x=>x.IsActive).OrderBy(x=>x.Code).ToListAsync()});
    }
    public async Task<IActionResult> Bag(int id) {
        var bag=await db.Bags.AsNoTracking().Include(x=>x.Shipment).SingleOrDefaultAsync(x=>x.Id==id);if(bag==null)return NotFound();
        var result=await db.VerificationResults.AsNoTracking().SingleOrDefaultAsync(x=>x.BagId==id);
        if(result==null){TempData["Error"]="Prvo završite verifikaciju vreće.";return RedirectToAction("Details","Workflow",new{id});}
        return View(new PackagingBag {Bag=bag,Result=result,Items=await db.BoxItems.AsNoTracking().Include(x=>x.Box).ThenInclude(x=>x.Combination).Where(x=>x.BagId==id).OrderBy(x=>x.Id).ToListAsync(),Boxes=await db.Boxes.AsNoTracking().Include(x=>x.Combination).Where(x=>x.Group==bag.Shipment.Group&&x.Status==BoxStatus.Formed).OrderByDescending(x=>x.Id).ToListAsync()});
    }
    public async Task<IActionResult> Details(int id) {
        var box=await db.Boxes.AsNoTracking().Include(x=>x.Combination).Include(x=>x.Items).ThenInclude(x=>x.Bag).SingleOrDefaultAsync(x=>x.Id==id);if(box==null)return NotFound();
        ViewBag.History=await db.AuditEntries.AsNoTracking().Where(x=>x.BoxId==id).OrderByDescending(x=>x.Id).ToListAsync();return View(box);
    }
    public async Task<IActionResult> Combinations()=>View(await db.Combinations.AsNoTracking().OrderBy(x=>x.Code).ToListAsync());
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> Create(CreateBoxInput input) {
        if(!ModelState.IsValid){TempData["Error"]="Izaberite kategoriju i kombinaciju.";return RedirectToAction(nameof(Index));}
        try{var box=await service.CreateAsync(input,(await users.GetUserAsync(User))!);TempData["Success"]="Kutija je formirana. Dodajte sadržaj kroz obradu verificiranih vreća.";return RedirectToAction(nameof(Details),new{id=box.Id});}catch(IntakeException e){TempData["Error"]=e.Message;return RedirectToAction(nameof(Index));}
    }
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> Allocate(int id,AllocateInput input) {
        if(!ModelState.IsValid){TempData["Error"]="Provjerite kutiju i količinu.";return RedirectToAction(nameof(Bag),new{id});}
        try{await service.AllocateAsync(id,input,(await users.GetUserAsync(User))!);TempData["Success"]="Količina je dodana u kutiju.";}catch(IntakeException e){TempData["Error"]=e.Message;}return RedirectToAction(nameof(Bag),new{id});
    }
    [HttpPost,Authorize(Policy=Permissions.Correct)]
    public async Task<IActionResult> Remove(int id,int itemId,Guid version,Guid boxVersion,string reason) {
        if(!ModelState.IsValid)return BadRequest();
        if(!await db.BoxItems.AnyAsync(x=>x.Id==itemId&&x.BagId==id))return NotFound();
        try{await service.RemoveAsync(itemId,version,boxVersion,reason,(await users.GetUserAsync(User))!);TempData["Success"]="Stavka je uklonjena uz zapis u historiji.";}catch(IntakeException e){TempData["Error"]=e.Message;}return RedirectToAction(nameof(Bag),new{id});
    }
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> FinishBag(int id,Guid version) {
        if(!ModelState.IsValid)return BadRequest();try{await service.FinishBagAsync(id,version,(await users.GetUserAsync(User))!);TempData["Success"]="Pakovanje prihvaćenih koverti je završeno.";}catch(IntakeException e){TempData["Error"]=e.Message;}return RedirectToAction(nameof(Bag),new{id});
    }
    [HttpPost,Authorize(Policy=Permissions.Receive)]
    public async Task<IActionResult> Fill(int id,Guid version) {
        if(!ModelState.IsValid)return BadRequest();try{await service.FillAsync(id,version,(await users.GetUserAsync(User))!);TempData["Success"]="Kutija je napunjena. Sadržaj je zaključan.";}catch(IntakeException e){TempData["Error"]=e.Message;}return RedirectToAction(nameof(Details),new{id});
    }
}
