using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;
[Authorize(Policy = Permissions.View)]
public class RejectionReasonsController(TrackingDbContext db, WorkflowService service, UserManager<AppUser> users) : Controller {
    public async Task<IActionResult> Index(IntakeGroup? group) {
        if(!ModelState.IsValid || group.HasValue && !Enum.IsDefined(group.Value))return BadRequest();
        ViewData["Group"]=group;
        return View(await db.RejectionReasons.AsNoTracking().Where(x=>!group.HasValue || x.Group==group).OrderBy(x=>x.Group).ThenBy(x=>x.Name).ToListAsync());
    }
    [Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Edit(int id=0,IntakeGroup group=IntakeGroup.Posta) {
        if(!ModelState.IsValid || !Enum.IsDefined(group))return BadRequest();
        if(id==0)return View(new ReasonInput{Group=group});
        var r=await db.RejectionReasons.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id);
        return r==null?NotFound():View(new ReasonInput{Id=r.Id,Name=r.Name,Group=r.Group,IsActive=r.IsActive,Version=r.Version});
    }
    [HttpPost,Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Edit(ReasonInput input) {
        if(ModelState.IsValid)try { await service.SaveReasonAsync(input,(await users.GetUserAsync(User))!); TempData["Success"]="Razlog je sačuvan."; return RedirectToAction(nameof(Index),new{group=input.Group}); }catch(IntakeException e){ModelState.AddModelError("",e.Message);}
        return View(input);
    }
}
