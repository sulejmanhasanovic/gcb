using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;
[Authorize(Policy = Permissions.View)]
public class ScanningController(ScanningService scanning) : Controller {
    public async Task<IActionResult> Index(ScanCategory category = ScanCategory.Nepotvrdjeni, string? search = null, int page = 1) {
        if (!ModelState.IsValid || !Enum.IsDefined(category)) return BadRequest();
        try { return View(await scanning.ListAsync(category, search, page)); }
        catch (ScanningException e) { return View(new ScanningList { Category = category, SetupMessage = e.Message }); }
    }
    public async Task<IActionResult> Details(int id, int page = 1) {
        try { var m = await scanning.DetailsAsync(id,page); return m == null ? NotFound() : View(m); }
        catch (ScanningException e) { TempData["Error"] = e.Message; return RedirectToAction(nameof(Index)); }
    }
    [HttpPost, Authorize(Policy = Permissions.Scan)]
    public async Task<IActionResult> Start(ScanCategory category, string? code) {
        if (!ModelState.IsValid || !Enum.IsDefined(category)) return BadRequest();
        try { return RedirectToAction(nameof(Details), new { id = await scanning.StartAsync(category, code, User.FindFirstValue(ClaimTypes.NameIdentifier)!) }); }
        catch (ScanningException e) { TempData["Error"] = e.Message; return RedirectToAction(nameof(Index),new { category }); }
    }
    [HttpPost, Authorize(Policy = Permissions.Scan), RequestSizeLimit(8192)]
    public async Task<IActionResult> Scan(int id, string? jmbg) {
        if (!ModelState.IsValid) return BadRequest();
        try { var result = await scanning.ScanAsync(id,jmbg,User.FindFirstValue(ClaimTypes.NameIdentifier)!); TempData[result.Accepted ? "Success" : "Error"] = result.Message; }
        catch (ScanningException e) { TempData["Error"] = e.Message; }
        return RedirectToAction(nameof(Details), new { id });
    }
    [HttpPost, Authorize(Policy = Permissions.Scan)]
    public async Task<IActionResult> Finish(int id) {
        try { await scanning.FinishAsync(id,User.FindFirstValue(ClaimTypes.NameIdentifier)!); TempData["Success"] = "Skeniranje je završeno."; }
        catch (ScanningException e) { TempData["Error"] = e.Message; }
        return RedirectToAction(nameof(Details),new { id });
    }
}
