using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Controllers;
[Authorize(Policy = Permissions.Users)]
public class UsersController(UserManager<AppUser> users, TrackingDbContext db) : Controller {
    public async Task<IActionResult> Index() {
        var list = await users.Users.AsNoTracking().OrderBy(x => x.UserName).ToListAsync();
        var roles = new Dictionary<string, string>();
        foreach (var user in list) roles[user.Id] = string.Join(", ", (await users.GetRolesAsync(user)).Select(Roles.Label));
        ViewData["Roles"] = roles; return View(list);
    }
    public IActionResult Create() => View(new UserInput());
    [HttpPost]
    public async Task<IActionResult> Create(UserInput input) {
        if (!Roles.All.Contains(input.Role)) ModelState.AddModelError(nameof(input.Role), "Odaberite važeću ulogu.");
        if (ModelState.IsValid) {
            await using var tx = await db.Database.BeginTransactionAsync();
            var user = new AppUser { UserName = input.UserName.Trim(), DisplayName = input.DisplayName.Trim(), Email = input.Email.Trim(), EmailConfirmed = true };
            var result = await users.CreateAsync(user, input.Password);
            if (result.Succeeded) result = await users.AddToRoleAsync(user, input.Role);
            if (result.Succeeded) {
                var actor = (await users.GetUserAsync(User))!;
                db.AuditEntries.Add(new AuditEntry { ActorId = actor.Id, ActorName = actor.DisplayName, Action = "Kreiran korisnik", AfterJson = System.Text.Json.JsonSerializer.Serialize(new { user.Id, user.UserName, input.Role }) });
                await db.SaveChangesAsync(); await tx.CommitAsync();
                TempData["Success"] = "Korisnik je kreiran."; return RedirectToAction(nameof(Index));
            }
            ModelState.AddModelError("", "Korisnik nije kreiran. Provjerite jedinstvenost imena i e-maila te pravila lozinke (12 znakova, veliko i malo slovo, broj, poseban znak).");
        }
        return View(input);
    }
}
