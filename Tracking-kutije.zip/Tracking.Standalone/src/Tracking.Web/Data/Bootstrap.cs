using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;
public static class Bootstrap {
    public static async Task InitializeAsync(IServiceProvider services, IConfiguration config) {
        var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var role in Roles.All) if (!await roles.RoleExistsAsync(role)) Check(await roles.CreateAsync(new IdentityRole(role)));
        var users = services.GetRequiredService<UserManager<AppUser>>();
        if (await users.Users.AnyAsync()) return;
        var name = config["Bootstrap:UserName"]; var password = config["Bootstrap:Password"]; var email = config["Bootstrap:Email"];
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(email)) return;
        var db = services.GetRequiredService<TrackingDbContext>();
        await using var transaction = await db.Database.BeginTransactionAsync();
        var user = new AppUser { UserName = name, Email = email, DisplayName = "Administrator", EmailConfirmed = true };
        Check(await users.CreateAsync(user, password)); Check(await users.AddToRoleAsync(user, Roles.Admin));
        await transaction.CommitAsync();
    }
    private static void Check(IdentityResult result) { if (!result.Succeeded) throw new InvalidOperationException(string.Join("; ", result.Errors.Select(e => e.Description))); }
}
