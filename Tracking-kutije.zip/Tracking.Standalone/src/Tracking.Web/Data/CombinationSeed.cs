using Tracking.Web.Models;
namespace Tracking.Web.Data;
// Unique combinations from the supplied combinations.sql; KXX requires a resolved Brčko option.
public static class CombinationSeed {
    public static readonly Combination[] Rows = [
        new() { Id = 1, Code = "K01", Levels = "201, 401, 511, 7012", IsActive = true },
        new() { Id = 2, Code = "K02", Levels = "202, 402, 515, 7012", IsActive = true },
        new() { Id = 3, Code = "K03", Levels = "203, 402, 515, 7012", IsActive = true },
        new() { Id = 4, Code = "K04", Levels = "203, 403, 515, 7012", IsActive = true },
        new() { Id = 5, Code = "K05", Levels = "203, 404, 515, 7012", IsActive = true },
        new() { Id = 6, Code = "K06", Levels = "204, 405, 514, 7012", IsActive = true },
        new() { Id = 7, Code = "K07", Levels = "204, 406, 514, 7012", IsActive = true },
        new() { Id = 8, Code = "K08", Levels = "205, 407, 513, 7012", IsActive = true },
        new() { Id = 9, Code = "K09", Levels = "206, 408, 514, 7012", IsActive = true },
        new() { Id = 10, Code = "K10", Levels = "207, 409, 512, 7012", IsActive = true },
        new() { Id = 11, Code = "K11", Levels = "208, 410, 512, 7012", IsActive = true },
        new() { Id = 12, Code = "K12", Levels = "209, 407, 513, 7012", IsActive = true },
        new() { Id = 13, Code = "K13", Levels = "209, 411, 513, 7012", IsActive = true },
        new() { Id = 14, Code = "K14", Levels = "210, 412, 511, 7012", IsActive = true },
        new() { Id = 15, Code = "K15", Levels = "301, 521, 600, 703", IsActive = true },
        new() { Id = 16, Code = "K16", Levels = "302, 521, 600, 703", IsActive = true },
        new() { Id = 17, Code = "K17", Levels = "303, 521, 600, 703", IsActive = true },
        new() { Id = 18, Code = "K18", Levels = "304, 522, 600, 703", IsActive = true },
        new() { Id = 19, Code = "K19", Levels = "305, 522, 600, 703", IsActive = true },
        new() { Id = 20, Code = "K20", Levels = "306, 522, 600, 703", IsActive = true },
        new() { Id = 21, Code = "K21", Levels = "307, 523, 600, 703", IsActive = true },
        new() { Id = 22, Code = "K22", Levels = "308, 523, 600, 703", IsActive = true },
        new() { Id = 23, Code = "K23", Levels = "309, 523, 600, 703", IsActive = true },
        new() { Id = 24, Code = "K24", Levels = "402, 515, 7012", IsActive = true },
        new() { Id = 25, Code = "KXX", Levels = "", IsActive = false },
    ];
}
