using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;
public static class PackagingSchema {
    public static void Configure(ModelBuilder b) {
        b.Entity<Combination>().HasIndex(x=>x.Code).IsUnique();
        b.Entity<Combination>().HasData(CombinationSeed.Rows);
        b.Entity<VerificationResult>().HasOne(x=>x.Bag).WithOne().HasForeignKey<VerificationResult>(x=>x.BagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VerificationResult>().HasOne<AppUser>().WithMany().HasForeignKey(x=>x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VerificationResult>().ToTable(t=>t.HasCheckConstraint("CK_Verification_Counts","Accepted >= 0 AND Rejected >= 0 AND Accepted + Rejected <= 1000000"));
        b.Entity<VerificationRejection>().HasOne(x=>x.Result).WithMany(x=>x.Reasons).HasForeignKey(x=>x.BagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VerificationRejection>().HasOne<RejectionReason>().WithMany().HasForeignKey(x=>x.RejectionReasonId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VerificationRejection>().HasIndex(x=>new{x.BagId,x.RejectionReasonId}).IsUnique();
        b.Entity<VerificationRejection>().ToTable(t=>t.HasCheckConstraint("CK_VerificationRejection_Quantity","Quantity > 0 AND Quantity <= 1000000"));
        b.Entity<Box>().Ignore(x=>x.Name);
        b.Entity<Box>().Property(x=>x.Version).IsConcurrencyToken();
        b.Entity<Box>().HasOne(x=>x.Combination).WithMany().HasForeignKey(x=>x.CombinationId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Box>().HasOne<AppUser>().WithMany().HasForeignKey(x=>x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Box>().HasOne<AppUser>().WithMany().HasForeignKey(x=>x.FilledById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Box>().HasIndex(x=>new{x.Group,x.Status,x.CombinationId});
        b.Entity<Box>().ToTable(t=>{
            t.HasCheckConstraint("CK_Box_Group","\"Group\" IN (1,2,3,4,5)");
            t.HasCheckConstraint("CK_Box_Status","(Status = 1 AND FilledById IS NULL AND FilledAtUtc IS NULL) OR (Status = 2 AND FilledById IS NOT NULL AND FilledAtUtc IS NOT NULL)");
        });
        b.Entity<BoxItem>().HasOne(x=>x.Bag).WithMany().HasForeignKey(x=>x.BagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BoxItem>().HasOne(x=>x.Box).WithMany(x=>x.Items).HasForeignKey(x=>x.BoxId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BoxItem>().HasOne<AppUser>().WithMany().HasForeignKey(x=>x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BoxItem>().HasIndex(x=>new{x.BagId,x.BoxId});
        b.Entity<BoxItem>().ToTable(t=>t.HasCheckConstraint("CK_BoxItem_Quantity","Quantity > 0 AND Quantity <= 1000000"));
    }
}
