using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;

public static class PollingStationImport {
    public static async Task<int> ImportAsync(TrackingDbContext db, string path) {
        var rows = JsonSerializer.Deserialize<List<PollingStation>>(await File.ReadAllTextAsync(path))
            ?? throw new InvalidOperationException("Prazan šifrarnik.");
        if (rows.Count == 0 || rows.Count > 50000) throw new InvalidOperationException("Neispravan broj biračkih mjesta.");
        foreach (var row in rows) {
            row.Code = row.Code.Trim().ToUpperInvariant(); row.Id = 0;
            Validator.ValidateObject(row, new ValidationContext(row), true);
            var expected = row.SourceTypeCode switch { "2" => IntakeGroup.Odsustvo, "M" => IntakeGroup.Mobilni, "N" => IntakeGroup.Nepotvrdjeni, "D" => IntakeGroup.Dkp, _ => (IntakeGroup)0 };
            if (expected == 0 || row.Group != expected || string.IsNullOrWhiteSpace(row.Code) || string.IsNullOrWhiteSpace(row.ElectionCode))
                throw new InvalidOperationException("Neispravna kategorija ili šifra biračkog mjesta: " + row.Code);
            if (new[] { row.RegularVoters, row.AbsenteeVoters, row.ByMailVoters, row.TotalVoters, row.RegisteredRegularVoters, row.InPersonVoters, row.PostalVoters, row.DkpVoters }.Any(x => x < 0))
                throw new InvalidOperationException("Broj glasača ne može biti negativan.");
        }
        if (rows.Select(x => x.Code).Distinct().Count() != rows.Count || rows.Select(x => x.ElectionCode).Distinct().Count() != 1)
            throw new InvalidOperationException("Šifrarnik mora sadržavati jedan izborni ciklus i jedinstvene šifre.");
        await using var tx = await db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
        var existing = await db.PollingStations.ToDictionaryAsync(x => x.Code);
        if (existing.Values.Any(x => x.ElectionCode != rows[0].ElectionCode)) throw new InvalidOperationException("Baza već sadrži drugi izborni ciklus.");
        var count = 0;
        foreach (var row in rows) {
            // Re-import only adds missing rows; it never rewrites existing operational data.
            if (existing.TryGetValue(row.Code, out var old)) {
                if (old.Group != row.Group) throw new InvalidOperationException("Kategorija postojećeg mjesta se razlikuje: " + row.Code);
                continue;
            }
            db.PollingStations.Add(row); count++;
        }
        await db.SaveChangesAsync(); await tx.CommitAsync(); return count;
    }
}
