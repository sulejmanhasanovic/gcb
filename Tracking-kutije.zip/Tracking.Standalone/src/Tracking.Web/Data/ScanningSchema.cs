using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;
public static class ScanningSchema {
    public static void Configure(ModelBuilder b) {
        b.Entity<Voter>().HasIndex(x => new { x.ElectionCode, x.Jmbg }).IsUnique();
        b.Entity<Voter>().HasIndex(x => new { x.ElectionCode, x.SourceTypeCode, x.PollingStationCode });
        b.Entity<ScanningSession>().HasIndex(x => new { x.ElectionCode, x.Category, x.PollingStationCode }).IsUnique();
        b.Entity<ScanningSession>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<ScanningSession>().HasOne(x => x.StartedBy).WithMany().HasForeignKey(x => x.StartedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ScanningSession>().HasOne(x => x.CompletedBy).WithMany().HasForeignKey(x => x.CompletedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ScanningSession>().ToTable(t => {
            t.HasCheckConstraint("CK_ScanningSession_Category", "Category IN (1,2,3,4,5,6)");
            t.HasCheckConstraint("CK_ScanningSession_Station", "(Category = 4 AND PollingStationCode = '') OR (Category <> 4 AND PollingStationCode <> '')");
            t.HasCheckConstraint("CK_ScanningSession_Status", "(Status IN (1,2) AND CompletedAtUtc IS NULL AND CompletedById IS NULL) OR (Status = 3 AND CompletedAtUtc IS NOT NULL AND CompletedById IS NOT NULL)");
        });
        b.Entity<VoteCast>().HasIndex(x => new { x.ElectionCode, x.VoterId }).IsUnique();
        b.Entity<VoteCast>().HasOne(x => x.Voter).WithMany().HasForeignKey(x => x.VoterId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VoteCast>().HasOne(x => x.ScanningSession).WithMany().HasForeignKey(x => x.ScanningSessionId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<VoteCast>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ScanAttempt>().HasIndex(x => new { x.ScanningSessionId, x.Id });
        b.Entity<ScanAttempt>().HasOne(x => x.Voter).WithMany().HasForeignKey(x => x.VoterId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ScanAttempt>().HasOne(x => x.ScanningSession).WithMany().HasForeignKey(x => x.ScanningSessionId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<ScanAttempt>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
    }
}
