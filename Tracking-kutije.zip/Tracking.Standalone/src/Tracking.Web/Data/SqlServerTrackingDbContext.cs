using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace Tracking.Web.Data;

// Separate context keeps provider-specific migrations independent.
public class SqlServerTrackingDbContext(DbContextOptions<SqlServerTrackingDbContext> options) : TrackingDbContext(options);

public class SqlServerDesignFactory : IDesignTimeDbContextFactory<SqlServerTrackingDbContext>
{
    public SqlServerTrackingDbContext CreateDbContext(string[] args) => new(
        new DbContextOptionsBuilder<SqlServerTrackingDbContext>()
            .UseSqlServer("Server=localhost;Database=Tracking;Integrated Security=True;Encrypt=True")
            .Options);
}
