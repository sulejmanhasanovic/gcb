using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace Tracking.Web.Data;
public class SqliteDesignFactory : IDesignTimeDbContextFactory<TrackingDbContext> {
    public TrackingDbContext CreateDbContext(string[] args) => new(new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source=tracking-design.db").Options);
}
