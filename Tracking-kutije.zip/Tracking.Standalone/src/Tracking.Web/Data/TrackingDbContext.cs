using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;
public class TrackingDbContext : IdentityDbContext<AppUser> {
    public DbSet<Combination> Combinations => Set<Combination>();
    public DbSet<VerificationResult> VerificationResults => Set<VerificationResult>();
    public DbSet<VerificationRejection> VerificationRejections => Set<VerificationRejection>();
    public DbSet<Box> Boxes => Set<Box>();
    public DbSet<BoxItem> BoxItems => Set<BoxItem>();
    public TrackingDbContext(DbContextOptions<TrackingDbContext> options) : base(options) { }
    protected TrackingDbContext(DbContextOptions options) : base(options) { }
    public DbSet<PollingStation> PollingStations => Set<PollingStation>();
    public DbSet<GeneratedBag> GeneratedBags => Set<GeneratedBag>();
    public DbSet<BagSequence> BagSequences => Set<BagSequence>();
    public DbSet<Shipment> Shipments => Set<Shipment>();
    public DbSet<Bag> Bags => Set<Bag>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();
    public DbSet<RejectionReason> RejectionReasons => Set<RejectionReason>();
    public DbSet<BagRejection> BagRejections => Set<BagRejection>();
    public DbSet<BagReceiptEntry> BagReceiptEntries => Set<BagReceiptEntry>();
    public DbSet<MaterialReceipt> MaterialReceipts => Set<MaterialReceipt>();
    public DbSet<Voter> Voters => Set<Voter>();
    public DbSet<VoteCast> VotesCast => Set<VoteCast>();
    public DbSet<ScanningSession> ScanningSessions => Set<ScanningSession>();
    public DbSet<ScanAttempt> ScanAttempts => Set<ScanAttempt>();
    protected override void OnModelCreating(ModelBuilder b) {
        base.OnModelCreating(b);
        ScanningSchema.Configure(b);
        PackagingSchema.Configure(b);
        b.Entity<AuditEntry>().HasIndex(x=>new{x.BoxId,x.AtUtc});
        b.Entity<Bag>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<Bag>().ToTable(t => {
            t.HasCheckConstraint("CK_Bag_Stage", "Stage IN (1,2,3,4,5,6)");
            t.HasCheckConstraint("CK_Bag_Workflow", "(Stage = 1) OR (CountedEnvelopes IS NOT NULL AND CountedEnvelopes BETWEEN 0 AND 1000000 AND RunId IS NOT NULL AND (Stage = 2 OR (ApprovedEnvelopes IS NOT NULL AND RejectedEnvelopes IS NOT NULL AND ApprovedEnvelopes >= 0 AND RejectedEnvelopes >= 0 AND ApprovedEnvelopes + RejectedEnvelopes = CountedEnvelopes AND (Stage = 3 OR (VerificationReceived IS NOT NULL AND VerificationReceived = ApprovedEnvelopes)))))");
        });
        b.Entity<RejectionReason>().HasIndex(x => new { x.Group, x.NormalizedName }).IsUnique();
        b.Entity<RejectionReason>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<RejectionReason>().ToTable(t => t.HasCheckConstraint("CK_Reason_Group", "\"Group\" IN (1,2,3,4,5)"));
        b.Entity<BagRejection>().HasIndex(x => new { x.BagId, x.RunId, x.RejectionReasonId }).IsUnique();
        b.Entity<BagRejection>().HasOne(x => x.Bag).WithMany().HasForeignKey(x => x.BagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BagRejection>().HasOne(x => x.RejectionReason).WithMany().HasForeignKey(x => x.RejectionReasonId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BagRejection>().ToTable(t => t.HasCheckConstraint("CK_Rejection_Quantity", "Quantity > 0 AND Quantity <= 1000000"));
        b.Entity<BagReceiptEntry>().HasOne(x => x.Bag).WithMany(x => x.Entries).HasForeignKey(x => x.BagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BagReceiptEntry>().ToTable(t => t.HasCheckConstraint("CK_Receipt_Counts", "TotalEnvelopes > 0 AND TotalEnvelopes <= 1000000 AND RegularEnvelopes >= 0 AND ExpressEnvelopes >= 0"));
        b.Entity<MaterialReceipt>().HasOne(x => x.Shipment).WithMany(x => x.Materials).HasForeignKey(x => x.ShipmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<MaterialReceipt>().ToTable(t => t.HasCheckConstraint("CK_Material_Quantity", "Quantity > 0 AND Quantity <= 1000000"));
        b.Entity<AuditEntry>().HasIndex(x => new { x.BagId, x.AtUtc });
        b.Entity<PollingStation>().HasIndex(x => x.Code).IsUnique();
        b.Entity<PollingStation>().HasIndex(x => new { x.Group, x.MunicipalityCode });
        b.Entity<PollingStation>().ToTable(t => t.HasCheckConstraint("CK_PollingStation_Group", "\"Group\" IN (2, 3, 4, 5)"));
        b.Entity<GeneratedBag>().HasIndex(x => x.Barcode).IsUnique();
        b.Entity<GeneratedBag>().HasIndex(x => x.PollingStationId).IsUnique().HasFilter("\"PollingStationId\" IS NOT NULL");
        b.Entity<GeneratedBag>().HasOne(x => x.PollingStation).WithMany().HasForeignKey(x => x.PollingStationId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<GeneratedBag>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<GeneratedBag>().ToTable(t => t.HasCheckConstraint("CK_GeneratedBag_Group", "(\"Group\" = 1 AND PollingStationId IS NULL) OR (\"Group\" IN (2,3,4,5) AND PollingStationId IS NOT NULL)"));
        b.Entity<Bag>().HasOne(x => x.GeneratedBag).WithOne(x => x.Receipt).HasForeignKey<Bag>(x => x.GeneratedBagId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BagSequence>().Property(x => x.Id).ValueGeneratedNever();
        b.Entity<BagSequence>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<Shipment>().HasIndex(x => x.Reference).IsUnique();
        b.Entity<Shipment>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<Shipment>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Bag>().HasIndex(x => x.Barcode).IsUnique();
        b.Entity<Bag>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Bag>().HasOne(x => x.Shipment).WithMany(x => x.Bags).HasForeignKey(x => x.ShipmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<AuditEntry>().HasIndex(x => new { x.ShipmentId, x.AtUtc });
        b.Entity<Shipment>().ToTable(t => {
            t.HasCheckConstraint("CK_Shipment_Counts", "ExpectedEnvelopes >= 0 AND ExpectedEnvelopes <= 1000000 AND Undelivered >= 0 AND Undelivered <= 1000000 AND OtherMaterials >= 0 AND OtherMaterials <= 1000000");
            t.HasCheckConstraint("CK_Shipment_Group", "\"Group\" IN (1, 2, 3, 4, 5)");
        });
        b.Entity<Bag>().ToTable(t => t.HasCheckConstraint("CK_Bag_Counts", "TotalEnvelopes > 0 AND TotalEnvelopes <= 1000000 AND RegularEnvelopes >= 0 AND ExpressEnvelopes >= 0"));
    }
}
