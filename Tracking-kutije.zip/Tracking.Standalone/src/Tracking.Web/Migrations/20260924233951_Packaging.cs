﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Tracking.Web.Migrations
{
    /// <inheritdoc />
    public partial class Packaging : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags");

            migrationBuilder.AddColumn<int>(
                name: "BoxId",
                table: "AuditEntries",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Combinations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Code = table.Column<string>(type: "TEXT", maxLength: 10, nullable: false),
                    Levels = table.Column<string>(type: "TEXT", maxLength: 200, nullable: false),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Combinations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "VerificationResults",
                columns: table => new
                {
                    BagId = table.Column<int>(type: "INTEGER", nullable: false),
                    Accepted = table.Column<int>(type: "INTEGER", nullable: false),
                    Rejected = table.Column<int>(type: "INTEGER", nullable: false),
                    Comment = table.Column<string>(type: "TEXT", maxLength: 1000, nullable: true),
                    CreatedById = table.Column<string>(type: "TEXT", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VerificationResults", x => x.BagId);
                    table.CheckConstraint("CK_Verification_Counts", "Accepted >= 0 AND Rejected >= 0 AND Accepted + Rejected <= 1000000");
                    table.ForeignKey(
                        name: "FK_VerificationResults_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VerificationResults_Bags_BagId",
                        column: x => x.BagId,
                        principalTable: "Bags",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Boxes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Group = table.Column<int>(type: "INTEGER", nullable: false),
                    CombinationId = table.Column<int>(type: "INTEGER", nullable: false),
                    Status = table.Column<int>(type: "INTEGER", nullable: false),
                    Version = table.Column<Guid>(type: "TEXT", nullable: false),
                    CreatedById = table.Column<string>(type: "TEXT", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "TEXT", nullable: false),
                    FilledById = table.Column<string>(type: "TEXT", maxLength: 450, nullable: true),
                    FilledAtUtc = table.Column<DateTime>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Boxes", x => x.Id);
                    table.CheckConstraint("CK_Box_Group", "\"Group\" IN (1,2,3,4,5)");
                    table.CheckConstraint("CK_Box_Status", "(Status = 1 AND FilledById IS NULL AND FilledAtUtc IS NULL) OR (Status = 2 AND FilledById IS NOT NULL AND FilledAtUtc IS NOT NULL)");
                    table.ForeignKey(
                        name: "FK_Boxes_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Boxes_AspNetUsers_FilledById",
                        column: x => x.FilledById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Boxes_Combinations_CombinationId",
                        column: x => x.CombinationId,
                        principalTable: "Combinations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "VerificationRejections",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    BagId = table.Column<int>(type: "INTEGER", nullable: false),
                    RejectionReasonId = table.Column<int>(type: "INTEGER", nullable: false),
                    ReasonName = table.Column<string>(type: "TEXT", maxLength: 200, nullable: false),
                    Quantity = table.Column<int>(type: "INTEGER", nullable: false),
                    Comment = table.Column<string>(type: "TEXT", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VerificationRejections", x => x.Id);
                    table.CheckConstraint("CK_VerificationRejection_Quantity", "Quantity > 0 AND Quantity <= 1000000");
                    table.ForeignKey(
                        name: "FK_VerificationRejections_RejectionReasons_RejectionReasonId",
                        column: x => x.RejectionReasonId,
                        principalTable: "RejectionReasons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VerificationRejections_VerificationResults_BagId",
                        column: x => x.BagId,
                        principalTable: "VerificationResults",
                        principalColumn: "BagId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BoxItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    BagId = table.Column<int>(type: "INTEGER", nullable: false),
                    BoxId = table.Column<int>(type: "INTEGER", nullable: false),
                    Quantity = table.Column<int>(type: "INTEGER", nullable: false),
                    CreatedById = table.Column<string>(type: "TEXT", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BoxItems", x => x.Id);
                    table.CheckConstraint("CK_BoxItem_Quantity", "Quantity > 0 AND Quantity <= 1000000");
                    table.ForeignKey(
                        name: "FK_BoxItems_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BoxItems_Bags_BagId",
                        column: x => x.BagId,
                        principalTable: "Bags",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BoxItems_Boxes_BoxId",
                        column: x => x.BoxId,
                        principalTable: "Boxes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Combinations",
                columns: new[] { "Id", "Code", "IsActive", "Levels" },
                values: new object[,]
                {
                    { 1, "K01", true, "201, 401, 511, 7012" },
                    { 2, "K02", true, "202, 402, 515, 7012" },
                    { 3, "K03", true, "203, 402, 515, 7012" },
                    { 4, "K04", true, "203, 403, 515, 7012" },
                    { 5, "K05", true, "203, 404, 515, 7012" },
                    { 6, "K06", true, "204, 405, 514, 7012" },
                    { 7, "K07", true, "204, 406, 514, 7012" },
                    { 8, "K08", true, "205, 407, 513, 7012" },
                    { 9, "K09", true, "206, 408, 514, 7012" },
                    { 10, "K10", true, "207, 409, 512, 7012" },
                    { 11, "K11", true, "208, 410, 512, 7012" },
                    { 12, "K12", true, "209, 407, 513, 7012" },
                    { 13, "K13", true, "209, 411, 513, 7012" },
                    { 14, "K14", true, "210, 412, 511, 7012" },
                    { 15, "K15", true, "301, 521, 600, 703" },
                    { 16, "K16", true, "302, 521, 600, 703" },
                    { 17, "K17", true, "303, 521, 600, 703" },
                    { 18, "K18", true, "304, 522, 600, 703" },
                    { 19, "K19", true, "305, 522, 600, 703" },
                    { 20, "K20", true, "306, 522, 600, 703" },
                    { 21, "K21", true, "307, 523, 600, 703" },
                    { 22, "K22", true, "308, 523, 600, 703" },
                    { 23, "K23", true, "309, 523, 600, 703" },
                    { 24, "K24", true, "402, 515, 7012" },
                    { 25, "KXX", false, "" }
                });

            migrationBuilder.AddCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags",
                sql: "Stage IN (1,2,3,4,5,6)");

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_BoxId_AtUtc",
                table: "AuditEntries",
                columns: new[] { "BoxId", "AtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_Boxes_CombinationId",
                table: "Boxes",
                column: "CombinationId");

            migrationBuilder.CreateIndex(
                name: "IX_Boxes_CreatedById",
                table: "Boxes",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_Boxes_FilledById",
                table: "Boxes",
                column: "FilledById");

            migrationBuilder.CreateIndex(
                name: "IX_Boxes_Group_Status_CombinationId",
                table: "Boxes",
                columns: new[] { "Group", "Status", "CombinationId" });

            migrationBuilder.CreateIndex(
                name: "IX_BoxItems_BagId_BoxId",
                table: "BoxItems",
                columns: new[] { "BagId", "BoxId" });

            migrationBuilder.CreateIndex(
                name: "IX_BoxItems_BoxId",
                table: "BoxItems",
                column: "BoxId");

            migrationBuilder.CreateIndex(
                name: "IX_BoxItems_CreatedById",
                table: "BoxItems",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_Combinations_Code",
                table: "Combinations",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_VerificationRejections_BagId_RejectionReasonId",
                table: "VerificationRejections",
                columns: new[] { "BagId", "RejectionReasonId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_VerificationRejections_RejectionReasonId",
                table: "VerificationRejections",
                column: "RejectionReasonId");

            migrationBuilder.CreateIndex(
                name: "IX_VerificationResults_CreatedById",
                table: "VerificationResults",
                column: "CreatedById");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BoxItems");

            migrationBuilder.DropTable(
                name: "VerificationRejections");

            migrationBuilder.DropTable(
                name: "Boxes");

            migrationBuilder.DropTable(
                name: "VerificationResults");

            migrationBuilder.DropTable(
                name: "Combinations");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_BoxId_AtUtc",
                table: "AuditEntries");

            migrationBuilder.DropColumn(
                name: "BoxId",
                table: "AuditEntries");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags",
                sql: "Stage IN (1,2,3,4)");
        }
    }
}
