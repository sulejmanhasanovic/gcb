﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tracking.Web.Migrations.SqlServer
{
    /// <inheritdoc />
    public partial class BagRegistrySqlServer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropCheckConstraint(
                name: "CK_Shipment_Group",
                table: "Shipments");

            migrationBuilder.AddColumn<int>(
                name: "GeneratedBagId",
                table: "Bags",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "BagSequences",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false),
                    NextNumber = table.Column<long>(type: "bigint", nullable: false),
                    Version = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BagSequences", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PollingStations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ElectionCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NameCyrillic = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    MunicipalityCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    MunicipalityName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    SourceTypeCode = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: false),
                    SourceValidityCode = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    Group = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    RegularVoters = table.Column<long>(type: "bigint", nullable: true),
                    AbsenteeVoters = table.Column<long>(type: "bigint", nullable: true),
                    ByMailVoters = table.Column<long>(type: "bigint", nullable: true),
                    TotalVoters = table.Column<long>(type: "bigint", nullable: true),
                    RegisteredRegularVoters = table.Column<long>(type: "bigint", nullable: true),
                    InPersonVoters = table.Column<long>(type: "bigint", nullable: true),
                    PostalVoters = table.Column<long>(type: "bigint", nullable: true),
                    DkpVoters = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PollingStations", x => x.Id);
                    table.CheckConstraint("CK_PollingStation_Group", "\"Group\" IN (2, 3, 4, 5)");
                });

            migrationBuilder.CreateTable(
                name: "GeneratedBags",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Barcode = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    Group = table.Column<int>(type: "int", nullable: false),
                    PollingStationId = table.Column<int>(type: "int", nullable: true),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GeneratedBags", x => x.Id);
                    table.CheckConstraint("CK_GeneratedBag_Group", "(\"Group\" = 1 AND PollingStationId IS NULL) OR (\"Group\" IN (2,3,4,5) AND PollingStationId IS NOT NULL)");
                    table.ForeignKey(
                        name: "FK_GeneratedBags_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GeneratedBags_PollingStations_PollingStationId",
                        column: x => x.PollingStationId,
                        principalTable: "PollingStations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.AddCheckConstraint(
                name: "CK_Shipment_Group",
                table: "Shipments",
                sql: "\"Group\" IN (1, 2, 3, 4, 5)");

            migrationBuilder.CreateIndex(
                name: "IX_Bags_GeneratedBagId",
                table: "Bags",
                column: "GeneratedBagId",
                unique: true,
                filter: "[GeneratedBagId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_GeneratedBags_Barcode",
                table: "GeneratedBags",
                column: "Barcode",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_GeneratedBags_CreatedById",
                table: "GeneratedBags",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_GeneratedBags_PollingStationId",
                table: "GeneratedBags",
                column: "PollingStationId",
                unique: true,
                filter: "\"PollingStationId\" IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_PollingStations_Code",
                table: "PollingStations",
                column: "Code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_PollingStations_Group_MunicipalityCode",
                table: "PollingStations",
                columns: new[] { "Group", "MunicipalityCode" });

            migrationBuilder.AddForeignKey(
                name: "FK_Bags_GeneratedBags_GeneratedBagId",
                table: "Bags",
                column: "GeneratedBagId",
                principalTable: "GeneratedBags",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Bags_GeneratedBags_GeneratedBagId",
                table: "Bags");

            migrationBuilder.DropTable(
                name: "BagSequences");

            migrationBuilder.DropTable(
                name: "GeneratedBags");

            migrationBuilder.DropTable(
                name: "PollingStations");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Shipment_Group",
                table: "Shipments");

            migrationBuilder.DropIndex(
                name: "IX_Bags_GeneratedBagId",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "GeneratedBagId",
                table: "Bags");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Shipment_Group",
                table: "Shipments",
                sql: "\"Group\" IN (1, 2, 3)");
        }
    }
}
