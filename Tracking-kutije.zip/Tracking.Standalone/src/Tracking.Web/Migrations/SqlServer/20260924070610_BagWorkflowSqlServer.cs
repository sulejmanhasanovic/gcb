using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tracking.Web.Migrations.SqlServer
{
    /// <inheritdoc />
    public partial class BagWorkflowSqlServer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ApprovedEnvelopes",
                table: "Bags",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CountedAtUtc",
                table: "Bags",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CountedEnvelopes",
                table: "Bags",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DifferenceReason",
                table: "Bags",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PreparationComment",
                table: "Bags",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "PreparedAtUtc",
                table: "Bags",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "RejectedEnvelopes",
                table: "Bags",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "RunId",
                table: "Bags",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Stage",
                table: "Bags",
                type: "int",
                nullable: false,
                defaultValue: 1);

            migrationBuilder.AddColumn<DateTime>(
                name: "VerificationAtUtc",
                table: "Bags",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VerificationComment",
                table: "Bags",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "VerificationReceived",
                table: "Bags",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "Version",
                table: "Bags",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("1badf100-2026-4024-8024-000000000001"));

            migrationBuilder.AddColumn<int>(
                name: "BagId",
                table: "AuditEntries",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "BagReceiptEntries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BagId = table.Column<int>(type: "int", nullable: false),
                    RegularEnvelopes = table.Column<int>(type: "int", nullable: false),
                    ExpressEnvelopes = table.Column<int>(type: "int", nullable: false),
                    TotalEnvelopes = table.Column<int>(type: "int", nullable: false),
                    PoBox = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    CreatedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BagReceiptEntries", x => x.Id);
                    table.CheckConstraint("CK_Receipt_Counts", "TotalEnvelopes > 0 AND TotalEnvelopes <= 1000000 AND RegularEnvelopes >= 0 AND ExpressEnvelopes >= 0");
                    table.ForeignKey(
                        name: "FK_BagReceiptEntries_Bags_BagId",
                        column: x => x.BagId,
                        principalTable: "Bags",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MaterialReceipts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShipmentId = table.Column<int>(type: "int", nullable: false),
                    IsUndelivered = table.Column<bool>(type: "bit", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true),
                    CreatedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaterialReceipts", x => x.Id);
                    table.CheckConstraint("CK_Material_Quantity", "Quantity > 0 AND Quantity <= 1000000");
                    table.ForeignKey(
                        name: "FK_MaterialReceipts_Shipments_ShipmentId",
                        column: x => x.ShipmentId,
                        principalTable: "Shipments",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RejectionReasons",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    NormalizedName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Group = table.Column<int>(type: "int", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Version = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RejectionReasons", x => x.Id);
                    table.CheckConstraint("CK_Reason_Group", "\"Group\" IN (1,2,3,4,5)");
                });

            migrationBuilder.CreateTable(
                name: "BagRejections",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BagId = table.Column<int>(type: "int", nullable: false),
                    RunId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RejectionReasonId = table.Column<int>(type: "int", nullable: false),
                    ReasonName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BagRejections", x => x.Id);
                    table.CheckConstraint("CK_Rejection_Quantity", "Quantity > 0 AND Quantity <= 1000000");
                    table.ForeignKey(
                        name: "FK_BagRejections_Bags_BagId",
                        column: x => x.BagId,
                        principalTable: "Bags",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BagRejections_RejectionReasons_RejectionReasonId",
                        column: x => x.RejectionReasonId,
                        principalTable: "RejectionReasons",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.AddCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags",
                sql: "Stage IN (1,2,3,4)");

            migrationBuilder.AddCheckConstraint(
                name: "CK_Bag_Workflow",
                table: "Bags",
                sql: "(Stage = 1) OR (CountedEnvelopes IS NOT NULL AND CountedEnvelopes BETWEEN 0 AND 1000000 AND RunId IS NOT NULL AND (Stage = 2 OR (ApprovedEnvelopes IS NOT NULL AND RejectedEnvelopes IS NOT NULL AND ApprovedEnvelopes >= 0 AND RejectedEnvelopes >= 0 AND ApprovedEnvelopes + RejectedEnvelopes = CountedEnvelopes AND (Stage = 3 OR (VerificationReceived IS NOT NULL AND VerificationReceived = ApprovedEnvelopes)))))");

            migrationBuilder.CreateIndex(
                name: "IX_AuditEntries_BagId_AtUtc",
                table: "AuditEntries",
                columns: new[] { "BagId", "AtUtc" });

            migrationBuilder.CreateIndex(
                name: "IX_BagReceiptEntries_BagId",
                table: "BagReceiptEntries",
                column: "BagId");

            migrationBuilder.CreateIndex(
                name: "IX_BagRejections_BagId_RunId_RejectionReasonId",
                table: "BagRejections",
                columns: new[] { "BagId", "RunId", "RejectionReasonId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BagRejections_RejectionReasonId",
                table: "BagRejections",
                column: "RejectionReasonId");

            migrationBuilder.CreateIndex(
                name: "IX_MaterialReceipts_ShipmentId",
                table: "MaterialReceipts",
                column: "ShipmentId");

            migrationBuilder.CreateIndex(
                name: "IX_RejectionReasons_Group_NormalizedName",
                table: "RejectionReasons",
                columns: new[] { "Group", "NormalizedName" },
                unique: true);
            // Preserve receipt detail from releases that stored only bag totals.
            migrationBuilder.Sql("INSERT INTO BagReceiptEntries (BagId,RegularEnvelopes,ExpressEnvelopes,TotalEnvelopes,PoBox,Comment,CreatedById,CreatedAtUtc) SELECT Id,RegularEnvelopes,ExpressEnvelopes,TotalEnvelopes,PoBox,Comment,CreatedById,CreatedAtUtc FROM Bags");
            migrationBuilder.Sql("INSERT INTO MaterialReceipts (ShipmentId,IsUndelivered,Quantity,Comment,CreatedById,CreatedAtUtc) SELECT Id,1,Undelivered,'Preneseno iz prethodne verzije',CreatedById,CreatedAtUtc FROM Shipments WHERE Undelivered > 0");
            migrationBuilder.Sql("INSERT INTO MaterialReceipts (ShipmentId,IsUndelivered,Quantity,Comment,CreatedById,CreatedAtUtc) SELECT Id,0,OtherMaterials,'Preneseno iz prethodne verzije',CreatedById,CreatedAtUtc FROM Shipments WHERE OtherMaterials > 0");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BagReceiptEntries");

            migrationBuilder.DropTable(
                name: "BagRejections");

            migrationBuilder.DropTable(
                name: "MaterialReceipts");

            migrationBuilder.DropTable(
                name: "RejectionReasons");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Bag_Stage",
                table: "Bags");

            migrationBuilder.DropCheckConstraint(
                name: "CK_Bag_Workflow",
                table: "Bags");

            migrationBuilder.DropIndex(
                name: "IX_AuditEntries_BagId_AtUtc",
                table: "AuditEntries");

            migrationBuilder.DropColumn(
                name: "ApprovedEnvelopes",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "CountedAtUtc",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "CountedEnvelopes",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "DifferenceReason",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "PreparationComment",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "PreparedAtUtc",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "RejectedEnvelopes",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "RunId",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "Stage",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "VerificationAtUtc",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "VerificationComment",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "VerificationReceived",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "Version",
                table: "Bags");

            migrationBuilder.DropColumn(
                name: "BagId",
                table: "AuditEntries");
        }
    }
}

