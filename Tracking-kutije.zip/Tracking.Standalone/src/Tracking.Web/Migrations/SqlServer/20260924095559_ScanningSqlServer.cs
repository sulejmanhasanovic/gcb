﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tracking.Web.Migrations.SqlServer
{
    /// <inheritdoc />
    public partial class ScanningSqlServer : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ScanningSessions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ElectionCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Category = table.Column<int>(type: "int", nullable: false),
                    PollingStationCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    StartedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    StartedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CompletedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: true),
                    CompletedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Version = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ScanningSessions", x => x.Id);
                    table.CheckConstraint("CK_ScanningSession_Category", "Category IN (1,2,3,4,5,6)");
                    table.CheckConstraint("CK_ScanningSession_Station", "(Category = 4 AND PollingStationCode = '') OR (Category <> 4 AND PollingStationCode <> '')");
                    table.CheckConstraint("CK_ScanningSession_Status", "(Status IN (1,2) AND CompletedAtUtc IS NULL AND CompletedById IS NULL) OR (Status = 3 AND CompletedAtUtc IS NOT NULL AND CompletedById IS NOT NULL)");
                    table.ForeignKey(
                        name: "FK_ScanningSessions_AspNetUsers_CompletedById",
                        column: x => x.CompletedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ScanningSessions_AspNetUsers_StartedById",
                        column: x => x.StartedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Voters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SourceId = table.Column<int>(type: "int", nullable: true),
                    ElectionCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Jmbg = table.Column<string>(type: "nvarchar(13)", maxLength: 13, nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: true),
                    ParentsName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsEligible = table.Column<bool>(type: "bit", nullable: false),
                    SourceEligibilityCode = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    SourceTypeCode = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    PollingStationCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    VoteForMunicipalityCode = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: true),
                    VoteInMunicipalityCode = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: true),
                    CurrentMunicipalityCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Voters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ScanAttempts",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ScanningSessionId = table.Column<int>(type: "int", nullable: false),
                    VoterId = table.Column<int>(type: "int", nullable: true),
                    JmbgLast4 = table.Column<string>(type: "nvarchar(4)", maxLength: 4, nullable: false),
                    Accepted = table.Column<bool>(type: "bit", nullable: false),
                    Result = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    CreatedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ScanAttempts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ScanAttempts_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ScanAttempts_ScanningSessions_ScanningSessionId",
                        column: x => x.ScanningSessionId,
                        principalTable: "ScanningSessions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ScanAttempts_Voters_VoterId",
                        column: x => x.VoterId,
                        principalTable: "Voters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "VotesCast",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ElectionCode = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    VoterId = table.Column<int>(type: "int", nullable: false),
                    ScanningSessionId = table.Column<int>(type: "int", nullable: false),
                    Category = table.Column<int>(type: "int", nullable: false),
                    RegisteredPollingStationCode = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    RegisteredSourceTypeCode = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    CreatedById = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false),
                    CreatedAtUtc = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VotesCast", x => x.Id);
                    table.ForeignKey(
                        name: "FK_VotesCast_AspNetUsers_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VotesCast_ScanningSessions_ScanningSessionId",
                        column: x => x.ScanningSessionId,
                        principalTable: "ScanningSessions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_VotesCast_Voters_VoterId",
                        column: x => x.VoterId,
                        principalTable: "Voters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ScanAttempts_CreatedById",
                table: "ScanAttempts",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_ScanAttempts_ScanningSessionId_Id",
                table: "ScanAttempts",
                columns: new[] { "ScanningSessionId", "Id" });

            migrationBuilder.CreateIndex(
                name: "IX_ScanAttempts_VoterId",
                table: "ScanAttempts",
                column: "VoterId");

            migrationBuilder.CreateIndex(
                name: "IX_ScanningSessions_CompletedById",
                table: "ScanningSessions",
                column: "CompletedById");

            migrationBuilder.CreateIndex(
                name: "IX_ScanningSessions_ElectionCode_Category_PollingStationCode",
                table: "ScanningSessions",
                columns: new[] { "ElectionCode", "Category", "PollingStationCode" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ScanningSessions_StartedById",
                table: "ScanningSessions",
                column: "StartedById");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_ElectionCode_Jmbg",
                table: "Voters",
                columns: new[] { "ElectionCode", "Jmbg" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Voters_ElectionCode_SourceTypeCode_PollingStationCode",
                table: "Voters",
                columns: new[] { "ElectionCode", "SourceTypeCode", "PollingStationCode" });

            migrationBuilder.CreateIndex(
                name: "IX_VotesCast_CreatedById",
                table: "VotesCast",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_VotesCast_ElectionCode_VoterId",
                table: "VotesCast",
                columns: new[] { "ElectionCode", "VoterId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_VotesCast_ScanningSessionId",
                table: "VotesCast",
                column: "ScanningSessionId");

            migrationBuilder.CreateIndex(
                name: "IX_VotesCast_VoterId",
                table: "VotesCast",
                column: "VoterId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ScanAttempts");

            migrationBuilder.DropTable(
                name: "VotesCast");

            migrationBuilder.DropTable(
                name: "ScanningSessions");

            migrationBuilder.DropTable(
                name: "Voters");
        }
    }
}
