using System.ComponentModel.DataAnnotations;
namespace Tracking.Web.Models;

public enum BoxStatus { Formed = 1, Filled = 2 }
public class Combination {
    public int Id { get; set; }
    [MaxLength(10)] public string Code { get; set; } = "";
    [MaxLength(200)] public string Levels { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
public class VerificationResult {
    [Key] public int BagId { get; set; }
    public Bag Bag { get; set; } = null!;
    public int Accepted { get; set; }
    public int Rejected { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public List<VerificationRejection> Reasons { get; set; } = [];
}
public class VerificationRejection {
    public int Id { get; set; }
    public int BagId { get; set; }
    public VerificationResult Result { get; set; } = null!;
    public int RejectionReasonId { get; set; }
    [MaxLength(200)] public string ReasonName { get; set; } = "";
    public int Quantity { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
}
public class Box {
    public int Id { get; set; }
    public string Name => $"KUT-{Id:D6}";
    public IntakeGroup Group { get; set; }
    public int CombinationId { get; set; }
    public Combination Combination { get; set; } = null!;
    public BoxStatus Status { get; set; } = BoxStatus.Formed;
    public Guid Version { get; set; } = Guid.NewGuid();
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    [MaxLength(450)] public string? FilledById { get; set; }
    public DateTime? FilledAtUtc { get; set; }
    public List<BoxItem> Items { get; set; } = [];
}
public class BoxItem {
    public int Id { get; set; }
    public int BagId { get; set; }
    public Bag Bag { get; set; } = null!;
    public int BoxId { get; set; }
    public Box Box { get; set; } = null!;
    public int Quantity { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
}
public class FinalVerificationInput {
    public Guid Version { get; set; }
    [Range(0,1000000)] public int Accepted { get; set; }
    [Range(0,1000000)] public int Rejected { get; set; }
    [StringLength(1000)] public string? Comment { get; set; }
    public List<RejectionInput> Reasons { get; set; } = [];
}
public class CreateBoxInput {
    [EnumDataType(typeof(IntakeGroup))] public IntakeGroup Group { get; set; } = IntakeGroup.Posta;
    [Range(1,int.MaxValue)] public int CombinationId { get; set; }
}
public class AllocateInput {
    public Guid Version { get; set; }
    public Guid BoxVersion { get; set; }
    [Range(1,int.MaxValue)] public int BoxId { get; set; }
    [Range(1,1000000)] public int Quantity { get; set; }
}
public class PackagingBag {
    public Bag Bag { get; set; } = null!;
    public VerificationResult Result { get; set; } = null!;
    public List<BoxItem> Items { get; set; } = [];
    public List<Box> Boxes { get; set; } = [];
    public long Allocated => Items.Sum(x => (long)x.Quantity);
}
public class BoxList {
    public List<Box> Boxes { get; set; } = [];
    public List<Combination> Combinations { get; set; } = [];
    public IntakeGroup? Group { get; set; }
    public BoxStatus? Status { get; set; }
    public int Page { get; set; }
    public int Total { get; set; }
}
