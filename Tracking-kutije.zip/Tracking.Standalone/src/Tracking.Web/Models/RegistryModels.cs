using System.ComponentModel.DataAnnotations;
namespace Tracking.Web.Models;

public class PollingStation {
    public int Id { get; set; }
    [MaxLength(50)] public string ElectionCode { get; set; } = "";
    [MaxLength(10)] public string Code { get; set; } = "";
    [MaxLength(50)] public string? Name { get; set; }
    [MaxLength(50)] public string? NameCyrillic { get; set; }
    [MaxLength(10)] public string? MunicipalityCode { get; set; }
    [MaxLength(255)] public string? MunicipalityName { get; set; }
    [MaxLength(1)] public string SourceTypeCode { get; set; } = "";
    [MaxLength(1)] public string? SourceValidityCode { get; set; }
    public IntakeGroup Group { get; set; }
    public bool IsActive { get; set; } = true;
    public long? RegularVoters { get; set; }
    public long? AbsenteeVoters { get; set; }
    public long? ByMailVoters { get; set; }
    public long? TotalVoters { get; set; }
    public long? RegisteredRegularVoters { get; set; }
    public long? InPersonVoters { get; set; }
    public long? PostalVoters { get; set; }
    public long? DkpVoters { get; set; }
}

// Registry exists before receipt; existing receipts remain intact during upgrade.
public class GeneratedBag {
    public int Id { get; set; }
    [MaxLength(40)] public string Barcode { get; set; } = "";
    public IntakeGroup Group { get; set; }
    public int? PollingStationId { get; set; }
    public PollingStation? PollingStation { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public AppUser CreatedBy { get; set; } = null!;
    public Bag? Receipt { get; set; }
}
public class BagSequence {
    public int Id { get; set; }
    public long NextNumber { get; set; } = 1;
    public Guid Version { get; set; } = Guid.NewGuid();
}
public class GenerateBagsInput {
    [EnumDataType(typeof(IntakeGroup)), Display(Name = "Kategorija")] public IntakeGroup Group { get; set; } = IntakeGroup.Posta;
    [Range(1, 1000), Display(Name = "Broj vreća za Poštu")] public int Quantity { get; set; } = 1;
    [Display(Name = "Biračko mjesto (za pojedinačno dodavanje)")] public int? PollingStationId { get; set; }
}
public class BagRegistryList {
    public List<GeneratedBag> Bags { get; set; } = [];
    public List<PollingStation> Stations { get; set; } = [];
    public IntakeGroup? Group { get; set; }
    public string? Search { get; set; }
    public bool? Received { get; set; }
    public int Page { get; set; }
    public int Total { get; set; }
}
