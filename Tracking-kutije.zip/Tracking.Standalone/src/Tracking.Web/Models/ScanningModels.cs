using System.ComponentModel.DataAnnotations;
namespace Tracking.Web.Models;

public enum ScanCategory { Nepotvrdjeni = 1, Odsustvo = 2, Mobilni = 3, Posta = 4, Dkp = 5, Redovni = 6 }
public enum ScanStatus { Started = 1, InProgress = 2, Finished = 3 }
public static class ScanLabels {
    public static string Category(ScanCategory c) => c switch { ScanCategory.Nepotvrdjeni => "Nepotvrđeni", ScanCategory.Odsustvo => "Odsustvo", ScanCategory.Mobilni => "Mobilni", ScanCategory.Posta => "Pošta", ScanCategory.Dkp => "DKP", ScanCategory.Redovni => "Redovni", _ => "—" };
    public static string SourceType(ScanCategory c) => c switch { ScanCategory.Nepotvrdjeni => "N", ScanCategory.Odsustvo => "2", ScanCategory.Mobilni => "M", ScanCategory.Posta => "O", ScanCategory.Dkp => "D", ScanCategory.Redovni => "1", _ => throw new ArgumentOutOfRangeException(nameof(c)) };
    public static string Status(ScanStatus? s) => s switch { ScanStatus.Started => "Započeto", ScanStatus.InProgress => "U toku", ScanStatus.Finished => "Završeno", _ => "Nije započeto" };
    public static string Mask(string? jmbg) => string.IsNullOrEmpty(jmbg) ? "—" : "•••••••••" + jmbg[^Math.Min(4,jmbg.Length)..];
}
public class Voter {
    public int Id { get; set; }
    public int? SourceId { get; set; }
    [MaxLength(50)] public string ElectionCode { get; set; } = "";
    [MaxLength(13)] public string Jmbg { get; set; } = "";
    [MaxLength(60)] public string? FirstName { get; set; }
    [MaxLength(60)] public string? LastName { get; set; }
    [MaxLength(50)] public string? ParentsName { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public bool IsEligible { get; set; }
    [MaxLength(1)] public string? SourceEligibilityCode { get; set; }
    [MaxLength(1)] public string? SourceTypeCode { get; set; }
    [MaxLength(10)] public string? PollingStationCode { get; set; }
    [MaxLength(4)] public string? VoteForMunicipalityCode { get; set; }
    [MaxLength(4)] public string? VoteInMunicipalityCode { get; set; }
    [MaxLength(50)] public string? CurrentMunicipalityCode { get; set; }
}
public class ScanningSession {
    public int Id { get; set; }
    [MaxLength(50)] public string ElectionCode { get; set; } = "";
    public ScanCategory Category { get; set; }
    // Empty only for the single postal session; no bag/receipt dependency.
    [MaxLength(10)] public string PollingStationCode { get; set; } = "";
    public ScanStatus Status { get; set; } = ScanStatus.Started;
    [MaxLength(450)] public string StartedById { get; set; } = "";
    public AppUser StartedBy { get; set; } = null!;
    public DateTime StartedAtUtc { get; set; }
    [MaxLength(450)] public string? CompletedById { get; set; }
    public AppUser? CompletedBy { get; set; }
    public DateTime? CompletedAtUtc { get; set; }
    public Guid Version { get; set; } = Guid.NewGuid();
}
public class VoteCast {
    public long Id { get; set; }
    [MaxLength(50)] public string ElectionCode { get; set; } = "";
    public int VoterId { get; set; }
    public Voter Voter { get; set; } = null!;
    public int ScanningSessionId { get; set; }
    public ScanningSession ScanningSession { get; set; } = null!;
    public ScanCategory Category { get; set; }
    [MaxLength(10)] public string? RegisteredPollingStationCode { get; set; }
    [MaxLength(1)] public string? RegisteredSourceTypeCode { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public AppUser CreatedBy { get; set; } = null!;
    public DateTime CreatedAtUtc { get; set; }
}
public class ScanAttempt {
    public long Id { get; set; }
    public int ScanningSessionId { get; set; }
    public ScanningSession ScanningSession { get; set; } = null!;
    public int? VoterId { get; set; }
    public Voter? Voter { get; set; }
    [MaxLength(4)] public string JmbgLast4 { get; set; } = "";
    public bool Accepted { get; set; }
    [MaxLength(250)] public string Result { get; set; } = "";
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public AppUser CreatedBy { get; set; } = null!;
    public DateTime CreatedAtUtc { get; set; }
}
public class ScanStationRow {
    public string Code { get; set; } = "";
    public ScanningSession? Session { get; set; }
    public int Eligible { get; set; }
    public int Accepted { get; set; }
}
public class ScanningList {
    public int AllEligible { get; set; }
    public int AllAccepted { get; set; }
    public ScanCategory Category { get; set; }
    public string ElectionCode { get; set; } = "";
    public string? Search { get; set; }
    public int Page { get; set; } = 1;
    public int Total { get; set; }
    public int Eligible { get; set; }
    public int Accepted { get; set; }
    public List<ScanStationRow> Stations { get; set; } = [];
    public string? SetupMessage { get; set; }
}
public class ScanningDetails {
    public ScanningSession Session { get; set; } = null!;
    public List<ScanAttempt> Attempts { get; set; } = [];
    public int Accepted { get; set; }
    public int Rejected { get; set; }
    public int Eligible { get; set; }
    public int Page { get; set; } = 1;
}
