using System.Data;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;

public class BagRegistryService(TrackingDbContext db) {
    public async Task<int> GenerateAsync(GenerateBagsInput input, AppUser actor) {
        if (!Enum.IsDefined(input.Group) || input.Quantity < 1 || input.Quantity > 1000)
            throw new IntakeException("Odaberite kategoriju i količinu od 1 do 1.000.");
        if (input.Group == IntakeGroup.Posta && input.PollingStationId != null)
            throw new IntakeException("Poštanske vreće nemaju biračko mjesto.");
        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        var added = new List<GeneratedBag>();
        if (input.Group == IntakeGroup.Posta) {
            var counter = await db.BagSequences.SingleOrDefaultAsync(x => x.Id == 1);
            if (counter == null) { counter = new BagSequence { Id = 1 }; db.BagSequences.Add(counter); }
            while (added.Count < input.Quantity) {
                var barcode = (counter.NextNumber++).ToString("D3", System.Globalization.CultureInfo.InvariantCulture);
                if (await db.GeneratedBags.AnyAsync(x => x.Barcode == barcode) || await db.Bags.AnyAsync(x => x.Barcode == barcode)) continue;
                added.Add(new GeneratedBag { Barcode = barcode, Group = input.Group, CreatedById = actor.Id });
            }
            counter.Version = Guid.NewGuid();
        } else {
            var q = db.PollingStations.Where(x => x.IsActive && x.Group == input.Group);
            if (input.PollingStationId.HasValue) q = q.Where(x => x.Id == input.PollingStationId.Value);
            var stations = await q.OrderBy(x => x.Code).ToListAsync();
            if (stations.Count == 0) throw new IntakeException("Nema aktivnih biračkih mjesta za ovaj izbor. Prvo učitajte šifrarnik.");
            var occupied = await db.GeneratedBags.Select(x => x.Barcode).Concat(db.Bags.Select(x => x.Barcode)).ToListAsync();
            var codes = occupied.ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var station in stations) {
                if (!codes.Add(station.Code)) continue;
                added.Add(new GeneratedBag { Barcode = station.Code, Group = station.Group, PollingStationId = station.Id, CreatedById = actor.Id });
            }
        }
        db.GeneratedBags.AddRange(added);
        if (added.Count > 0) Audit(actor, "Generisane vreće", new { Group = input.Group, Barcodes = added.Select(x => x.Barcode).ToArray() });
        await SaveAsync(); await tx.CommitAsync(); return added.Count;
    }
    public async Task<int> DeleteAsync(int[] ids, AppUser actor) {
        ids = ids.Distinct().ToArray();
        if (ids.Length == 0 || ids.Length > 100) throw new IntakeException("Odaberite od 1 do 100 vreća.");
        await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        var bags = await db.GeneratedBags.Where(x => ids.Contains(x.Id)).Include(x => x.Receipt).ToListAsync();
        if (bags.Count != ids.Length) throw new IntakeException("Pregled je promijenjen. Osvježite stranicu.");
        var codes = bags.Select(x => x.Barcode).ToArray();
        if (bags.Any(x => x.Receipt != null) || await db.Bags.AnyAsync(x => codes.Contains(x.Barcode)))
            throw new IntakeException("Zaprimljene vreće se ne mogu brisati. Nije obrisana nijedna od odabranih vreća.");
        Audit(actor, "Obrisane nezaprimljene vreće", bags.Select(x => new { x.Barcode, x.Group, x.PollingStationId }).ToArray());
        db.GeneratedBags.RemoveRange(bags); await SaveAsync(); await tx.CommitAsync(); return bags.Count;
    }
    private void Audit(AppUser actor, string action, object data) => db.AuditEntries.Add(new AuditEntry {
        ActorId = actor.Id, ActorName = actor.DisplayName, Action = action, AfterJson = JsonSerializer.Serialize(data)
    });
    private async Task SaveAsync() {
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException) { db.ChangeTracker.Clear(); throw new IntakeException("Podaci su promijenjeni ili oznaka već postoji. Osvježite pregled i ponovite radnju."); }
    }
}
