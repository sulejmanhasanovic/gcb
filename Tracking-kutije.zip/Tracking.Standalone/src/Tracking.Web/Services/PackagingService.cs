using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;
public class PackagingService(TrackingDbContext db) {
    public async Task FinalizeAsync(int id, FinalVerificationInput input, AppUser actor) {
        Validate(input);
        var bag=await BagAsync(id,input.Version);
        if(bag.Stage!=BagStage.Verification)throw new IntakeException("Vreća mora biti primljena na verifikaciju.");
        if((long)input.Accepted+input.Rejected!=bag.VerificationReceived)throw new IntakeException("Prihvaćeno i odbijeno mora odgovarati količini preuzetoj na verifikaciju.");
        if(input.Reasons==null || input.Reasons.Count>200)throw new IntakeException("Neispravna lista razloga.");
        foreach(var r in input.Reasons)Validate(r);
        if(input.Reasons.Select(x=>x.ReasonId).Distinct().Count()!=input.Reasons.Count || input.Reasons.Sum(x=>(long)x.Quantity)!=input.Rejected)throw new IntakeException("Razlozi se ne smiju ponavljati, a zbir mora odgovarati odbijenim kovertama.");
        var selected=input.Reasons.Where(x=>x.Quantity>0).ToList();
        var ids=selected.Select(x=>x.ReasonId).ToArray();
        var reasons=await db.RejectionReasons.Where(x=>ids.Contains(x.Id)&&x.IsActive&&x.Group==bag.Shipment.Group).ToDictionaryAsync(x=>x.Id);
        if(reasons.Count!=selected.Count)throw new IntakeException("Razlog nije aktivan ili ne pripada kategoriji vreće.");
        var result=new VerificationResult { BagId=id,Accepted=input.Accepted,Rejected=input.Rejected,Comment=input.Comment?.Trim(),CreatedById=actor.Id,CreatedAtUtc=DateTime.UtcNow,
            Reasons=selected.Select(x=>new VerificationRejection {RejectionReasonId=x.ReasonId,ReasonName=reasons[x.ReasonId].Name,Quantity=x.Quantity,Comment=x.Comment?.Trim()}).ToList() };
        db.VerificationResults.Add(result);
        bag.Stage=BagStage.Verified; bag.Version=Guid.NewGuid();
        Audit(actor,"Verifikacija završena",bag,null,new {result.Accepted,result.Rejected,result.Comment,Reasons=result.Reasons.Select(x=>new{x.ReasonName,x.Quantity,x.Comment})});
        await SaveAsync();
    }
    public async Task<Box> CreateAsync(CreateBoxInput input, AppUser actor) {
        Validate(input);
        var combination=await db.Combinations.SingleOrDefaultAsync(x=>x.Id==input.CombinationId&&x.IsActive)??throw new IntakeException("Izaberite aktivnu kombinaciju.");
        var box=new Box {Group=input.Group,CombinationId=input.CombinationId,CreatedById=actor.Id,CreatedAtUtc=DateTime.UtcNow};
        // The generated identity and its audit entry are committed together.
        await using var transaction=await db.Database.BeginTransactionAsync();
        db.Boxes.Add(box);await SaveAsync();
        Audit(actor,"Kutija formirana",null,box,new {box.Group,CombinationCode=combination.Code});await SaveAsync();
        await transaction.CommitAsync();return box;
    }
    public async Task AllocateAsync(int id, AllocateInput input, AppUser actor) {
        Validate(input);
        var bag=await BagAsync(id,input.Version);
        if(bag.Stage!=BagStage.Verified)throw new IntakeException("Pakovanje je dozvoljeno samo nakon završene verifikacije, prije završetka pakovanja.");
        var box=await BoxAsync(input.BoxId,input.BoxVersion);
        if(box.Group!=bag.Shipment.Group)throw new IntakeException("Kutija i vreća moraju biti iste kategorije.");
        var result=await db.VerificationResults.SingleAsync(x=>x.BagId==id);
        var allocated=await db.BoxItems.Where(x=>x.BagId==id).SumAsync(x=>(long)x.Quantity);
        if(allocated+input.Quantity>result.Accepted)throw new IntakeException($"Preostalo je {result.Accepted-allocated} prihvaćenih koverti za pakovanje.");
        db.BoxItems.Add(new BoxItem {BagId=id,BoxId=box.Id,Quantity=input.Quantity,CreatedById=actor.Id,CreatedAtUtc=DateTime.UtcNow});
        // Updating both tokens makes competing allocations and closing a box mutually exclusive.
        bag.Version=Guid.NewGuid();box.Version=Guid.NewGuid();
        Audit(actor,"Koverte raspoređene u kutiju",bag,box,new {input.Quantity,box.CombinationId});await SaveAsync();
    }
    public async Task RemoveAsync(int itemId, Guid bagVersion, Guid boxVersion, string reason, AppUser actor) {
        if(string.IsNullOrWhiteSpace(reason)||reason.Length>1000)throw new IntakeException("Unesite razlog uklanjanja stavke (do 1000 znakova).");
        var item=await db.BoxItems.SingleOrDefaultAsync(x=>x.Id==itemId)??throw new IntakeException("Stavka nije pronađena.");
        var bag=await BagAsync(item.BagId,bagVersion);var box=await BoxAsync(item.BoxId,boxVersion);
        if(bag.Stage!=BagStage.Verified)throw new IntakeException("Pakovanje vreće je završeno; stavka je zaključana.");
        db.BoxItems.Remove(item);bag.Version=Guid.NewGuid();box.Version=Guid.NewGuid();
        Audit(actor,"Uklonjena stavka pakovanja",bag,box,new {item.Quantity},reason.Trim());await SaveAsync();
    }
    public async Task FinishBagAsync(int id, Guid version, AppUser actor) {
        var bag=await BagAsync(id,version);
        if(bag.Stage!=BagStage.Verified)throw new IntakeException("Vreća nije spremna za završetak pakovanja.");
        var result=await db.VerificationResults.SingleAsync(x=>x.BagId==id);
        if(await db.BoxItems.Where(x=>x.BagId==id).SumAsync(x=>(long)x.Quantity)!=result.Accepted)throw new IntakeException("Rasporedite sve konačno prihvaćene koverte prije završetka pakovanja.");
        bag.Stage=BagStage.Packed;bag.Version=Guid.NewGuid();
        Audit(actor,"Pakovanje prihvaćenih koverti završeno",bag,null,new {result.Accepted,result.Rejected});await SaveAsync();
    }
    public async Task FillAsync(int id, Guid version, AppUser actor) {
        var box=await BoxAsync(id,version);
        if(!await db.BoxItems.AnyAsync(x=>x.BoxId==id))throw new IntakeException("Praznu kutiju nije moguće označiti kao napunjenu.");
        if(await db.BoxItems.AnyAsync(x=>x.BoxId==id&&x.Bag.Stage!=BagStage.Packed))throw new IntakeException("Prvo završite pakovanje svih vreća koje pune ovu kutiju.");
        box.Status=BoxStatus.Filled;box.FilledById=actor.Id;box.FilledAtUtc=DateTime.UtcNow;box.Version=Guid.NewGuid();
        Audit(actor,"Kutija napunjena i zaključana",null,box,new {Total=await db.BoxItems.Where(x=>x.BoxId==id).SumAsync(x=>(long)x.Quantity)});await SaveAsync();
    }
    private async Task<Bag> BagAsync(int id,Guid version) {
        var bag=await db.Bags.Include(x=>x.Shipment).SingleOrDefaultAsync(x=>x.Id==id)??throw new IntakeException("Vreća nije pronađena.");
        if(version==Guid.Empty||version!=bag.Version)throw new IntakeException("Vreća je izmijenjena. Osvježite stranicu.");
        if(bag.Shipment.Status!=IntakeStatus.Closed)throw new IntakeException("Prijem pošiljke nije završen.");
        return bag;
    }
    private async Task<Box> BoxAsync(int id,Guid version) {
        var box=await db.Boxes.SingleOrDefaultAsync(x=>x.Id==id)??throw new IntakeException("Kutija nije pronađena.");
        if(version==Guid.Empty||version!=box.Version)throw new IntakeException("Kutija je izmijenjena. Osvježite stranicu.");
        if(box.Status!=BoxStatus.Formed)throw new IntakeException("Kutija je zaključana i ne prima izmjene.");return box;
    }
    private void Audit(AppUser actor,string action,Bag? bag,Box? box,object data,string? reason=null) => db.AuditEntries.Add(new AuditEntry {BagId=bag?.Id,ShipmentId=bag?.ShipmentId,BoxId=box?.Id,ActorId=actor.Id,ActorName=actor.DisplayName,Action=action,Reason=reason,AfterJson=JsonSerializer.Serialize(data)});
    private static void Validate(object input) { var errors=new List<ValidationResult>();if(!Validator.TryValidateObject(input,new ValidationContext(input),errors,true))throw new IntakeException(string.Join(" ",errors.Select(x=>x.ErrorMessage))); }
    private async Task SaveAsync() {
        try {await db.SaveChangesAsync();}
        catch(DbUpdateConcurrencyException){db.ChangeTracker.Clear();throw new IntakeException("Drugi operater je izmijenio podatke. Osvježite pregled i pokušajte ponovo.");}
        catch(DbUpdateException){db.ChangeTracker.Clear();throw new IntakeException("Upis nije uspio. Osvježite pregled i provjerite podatke.");}
    }
}
