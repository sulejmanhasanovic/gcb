using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;

public class ScanningException(string message) : Exception(message);
public record ScanResult(bool Accepted, string Message);
public class ScanningService(TrackingDbContext db, IConfiguration config) {
    public async Task<string> ElectionAsync() {
        var configured = config["Tracking:ElectionCode"]?.Trim();
        if (!string.IsNullOrEmpty(configured)) {
            if (configured.Length > 50) throw new ScanningException("Šifra izbora smije imati najviše 50 znakova.");
            return configured;
        }
        var codes = await db.PollingStations.Select(x => x.ElectionCode).Union(db.Voters.Select(x => x.ElectionCode)).Distinct().Take(2).ToListAsync();
        if (codes.Count != 1) throw new ScanningException("Učitajte birački spisak i podesite Tracking:ElectionCode za izbore koje obrađujete.");
        return codes[0];
    }
    private IQueryable<string> Stations(string election, ScanCategory category) {
        var type = ScanLabels.SourceType(category);
        return db.PollingStations.Where(x => x.ElectionCode == election && x.IsActive && x.SourceTypeCode == type).Select(x => x.Code)
            .Union(db.Voters.Where(x => x.ElectionCode == election && x.SourceTypeCode == type && x.PollingStationCode != null && x.PollingStationCode != "").Select(x => x.PollingStationCode!))
            .Union(db.ScanningSessions.Where(x => x.ElectionCode == election && x.Category == category).Select(x => x.PollingStationCode));
    }
    public async Task<ScanningList> ListAsync(ScanCategory category, string? search, int page) {
        var election = await ElectionAsync(); var type = ScanLabels.SourceType(category);
        search = search?.Trim().ToUpperInvariant(); page = Math.Clamp(page, 1, 100000);
        var voters = db.Voters.Where(x => x.ElectionCode == election && x.SourceTypeCode == type && x.IsEligible);
        var votes = db.VotesCast.Where(x => x.ElectionCode == election && x.Category == category);
        var m = new ScanningList { Category = category, ElectionCode = election, Search = search, Page = page, Eligible = await voters.CountAsync(), Accepted = await votes.CountAsync() };
        var supportedTypes = Enum.GetValues<ScanCategory>().Select(ScanLabels.SourceType).ToArray();
        m.AllEligible = await db.Voters.CountAsync(x => x.ElectionCode == election && x.IsEligible && supportedTypes.Contains(x.SourceTypeCode!));
        m.AllAccepted = await db.VotesCast.CountAsync(x => x.ElectionCode == election);
        List<string> codes;
        if (category == ScanCategory.Posta) { codes = [""]; m.Total = 1; }
        else {
            var q = Stations(election, category);
            if (!string.IsNullOrEmpty(search)) q = q.Where(x => x.Contains(search));
            m.Total = await q.CountAsync(); codes = await q.OrderBy(x => x).Skip((page-1)*25).Take(25).ToListAsync();
        }
        var sessions = await db.ScanningSessions.AsNoTracking().Where(x => x.ElectionCode == election && x.Category == category && codes.Contains(x.PollingStationCode)).ToListAsync();
        var sessionIds = sessions.Select(x => x.Id).ToList();
        var counts = await votes.Where(x => sessionIds.Contains(x.ScanningSessionId)).GroupBy(x => x.ScanningSessionId).Select(g => new { Id = g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Id, x => x.Count);
        var totals = await voters.Where(x => x.PollingStationCode != null && codes.Contains(x.PollingStationCode)).GroupBy(x => x.PollingStationCode!).Select(g => new { Code = g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Code, x => x.Count);
        foreach (var code in codes) {
            var session = sessions.SingleOrDefault(x => x.PollingStationCode == code);
            m.Stations.Add(new() { Code = code, Session = session, Eligible = category == ScanCategory.Posta ? m.Eligible : totals.GetValueOrDefault(code), Accepted = session == null ? 0 : counts.GetValueOrDefault(session.Id) });
        }
        if (!await db.Voters.AnyAsync(x => x.ElectionCode == election)) m.SetupMessage = "Birački spisak za ove izbore još nije učitan. Skeniranje će biti dostupno nakon uvoza birača.";
        return m;
    }
    public async Task<int> StartAsync(ScanCategory category, string? code, string actorId) {
        if (!Enum.IsDefined(category)) throw new ScanningException("Nepoznata kategorija.");
        var election = await ElectionAsync(); code = code?.Trim().ToUpperInvariant() ?? "";
        if (category == ScanCategory.Posta) code = "";
        else if (code.Length is < 1 or > 10 || !await Stations(election, category).ContainsAsync(code)) throw new ScanningException("Biračko mjesto ne postoji u odabranoj kategoriji.");
        if (!await db.Voters.AnyAsync(x => x.ElectionCode == election)) throw new ScanningException("Prvo učitajte birački spisak za ove izbore.");
        var existing = await db.ScanningSessions.SingleOrDefaultAsync(x => x.ElectionCode == election && x.Category == category && x.PollingStationCode == code);
        if (existing != null) return existing.Id;
        var session = new ScanningSession { ElectionCode = election, Category = category, PollingStationCode = code, StartedById = actorId, StartedAtUtc = DateTime.UtcNow };
        db.ScanningSessions.Add(session);
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateException) {
            db.ChangeTracker.Clear();
            existing = await db.ScanningSessions.SingleOrDefaultAsync(x => x.ElectionCode == election && x.Category == category && x.PollingStationCode == code);
            if (existing == null) throw;
            return existing.Id;
        }
        return session.Id;
    }
    public async Task<ScanResult> ScanAsync(int id, string? jmbg, string actorId) {
        jmbg = jmbg?.Trim() ?? "";
        for (var retry = 0; retry < 3; retry++) {
            db.ChangeTracker.Clear();
            var session = await db.ScanningSessions.SingleOrDefaultAsync(x => x.Id == id) ?? throw new ScanningException("Skeniranje nije pronađeno.");
            if (session.ElectionCode != await ElectionAsync()) throw new ScanningException("Skeniranje pripada drugim izborima.");
            if (session.Status == ScanStatus.Finished) throw new ScanningException("Skeniranje ovog mjesta je završeno. Novi unosi nisu dozvoljeni.");
            Voter? voter = null; string? error = null;
            if (jmbg.Length != 13 || jmbg.Any(c => c < '0' || c > '9')) error = "JMBG mora sadržavati tačno 13 cifara.";
            else {
                voter = await db.Voters.AsNoTracking().SingleOrDefaultAsync(x => x.ElectionCode == session.ElectionCode && x.Jmbg == jmbg);
                if (voter == null) error = "Birač nije pronađen u biračkom spisku.";
                else if (!voter.IsEligible) error = "Birač nema pravo glasa (Eligible nije 1).";
                else if (voter.SourceTypeCode != ScanLabels.SourceType(session.Category)) error = "Birač nije registrovan za kategoriju " + ScanLabels.Category(session.Category) + ".";
                else if (session.Category != ScanCategory.Posta && voter.PollingStationCode != session.PollingStationCode) error = "Birač ne pripada otvorenom biračkom mjestu.";
                else if (await db.VotesCast.AnyAsync(x => x.ElectionCode == session.ElectionCode && x.VoterId == voter.Id)) error = "Birač je već evidentiran za ove izbore.";
            }
            var now = DateTime.UtcNow;
            if (error == null) {
                db.VotesCast.Add(new VoteCast { ElectionCode = session.ElectionCode, VoterId = voter!.Id, ScanningSessionId = id, Category = session.Category, RegisteredPollingStationCode = voter.PollingStationCode, RegisteredSourceTypeCode = voter.SourceTypeCode, CreatedById = actorId, CreatedAtUtc = now });
                session.Status = ScanStatus.InProgress;
            }
            var message = error ?? "Birač je uspješno evidentiran.";
            db.ScanAttempts.Add(new ScanAttempt { ScanningSessionId = id, VoterId = voter?.Id, JmbgLast4 = jmbg.Length == 13 && jmbg.All(c => c >= '0' && c <= '9') ? jmbg[^4..] : "", Accepted = error == null, Result = message, CreatedById = actorId, CreatedAtUtc = now });
            // Every write participates in the session's concurrency check. A concurrent finish
            // rolls back the entire save (including the vote and attempt), then rechecks state.
            session.Version = Guid.NewGuid();
            try { await db.SaveChangesAsync(); return new(error == null, message); }
            catch (DbUpdateConcurrencyException) { }
            catch (DbUpdateException) {
                db.ChangeTracker.Clear();
                if (voter == null || !await db.VotesCast.AnyAsync(x => x.ElectionCode == session.ElectionCode && x.VoterId == voter.Id)) throw;
                // Another session won the unique voter/election insert. Retry as a rejected attempt.
            }
        }
        throw new ScanningException("Drugi operater je upravo promijenio evidenciju. Ponovite unos.");
    }
    public async Task FinishAsync(int id, string actorId) {
        db.ChangeTracker.Clear();
        var session = await db.ScanningSessions.SingleOrDefaultAsync(x => x.Id == id) ?? throw new ScanningException("Skeniranje nije pronađeno.");
        if (session.ElectionCode != await ElectionAsync()) throw new ScanningException("Skeniranje pripada drugim izborima.");
        if (session.Status == ScanStatus.Finished) return;
        session.Status = ScanStatus.Finished; session.CompletedById = actorId; session.CompletedAtUtc = DateTime.UtcNow; session.Version = Guid.NewGuid();
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateConcurrencyException) { throw new ScanningException("U međuvremenu je evidentiran novi pokušaj. Pregledajte stanje i ponovo završite skeniranje."); }
    }
    public async Task<ScanningDetails?> DetailsAsync(int id, int page) {
        var election = await ElectionAsync();
        var session = await db.ScanningSessions.AsNoTracking().Include(x => x.StartedBy).Include(x => x.CompletedBy).SingleOrDefaultAsync(x => x.Id == id && x.ElectionCode == election);
        if (session == null) return null;
        page = Math.Clamp(page,1,100000); var type = ScanLabels.SourceType(session.Category);
        return new ScanningDetails {
            Session = session, Page = page,
            Accepted = await db.VotesCast.CountAsync(x => x.ScanningSessionId == id),
            Rejected = await db.ScanAttempts.CountAsync(x => x.ScanningSessionId == id && !x.Accepted),
            Eligible = await db.Voters.CountAsync(x => x.ElectionCode == election && x.IsEligible && x.SourceTypeCode == type && (session.Category == ScanCategory.Posta || x.PollingStationCode == session.PollingStationCode)),
            Attempts = await db.ScanAttempts.AsNoTracking().Include(x => x.Voter).Include(x => x.CreatedBy).Where(x => x.ScanningSessionId == id).OrderByDescending(x => x.Id).Skip((page-1)*25).Take(25).ToListAsync()
        };
    }
}
