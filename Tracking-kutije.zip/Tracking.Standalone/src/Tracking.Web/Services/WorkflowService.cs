using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;

public class WorkflowService(TrackingDbContext db) {
    public async Task CountAsync(int id, CountInput input, AppUser actor) {
        Validate(input);
        var bag = await GetAsync(id, input.Version, BagStage.Received);
        if (input.Counted != bag.TotalEnvelopes && (!input.ConfirmDifference || string.IsNullOrWhiteSpace(input.DifferenceReason)))
            throw new IntakeException($"Kontrolno brojanje ({input.Counted}) se razlikuje od prijema ({bag.TotalEnvelopes}). Ponovite brojanje, potvrdite razliku i unesite obrazloženje.");
        var before = Snapshot(bag);
        bag.CountedEnvelopes = input.Counted; bag.DifferenceReason = input.Counted != bag.TotalEnvelopes ? input.DifferenceReason?.Trim() : null;
        bag.RunId = Guid.NewGuid(); bag.CountedAtUtc = DateTime.UtcNow; bag.Stage = BagStage.Counted;
        Audit(bag, actor, "Kontrolno brojanje završeno", before, bag.DifferenceReason);
        await SaveAsync();
    }
    public async Task PrepareAsync(int id, PreparationInput input, AppUser actor) {
        Validate(input);
        if (input.Reasons == null || input.Reasons.Count > 200) throw new IntakeException("Neispravna lista razloga odbijanja.");
        foreach (var line in input.Reasons) Validate(line);
        var bag = await GetAsync(id, input.Version, BagStage.Counted);
        if ((long)input.Approved + input.Rejected != bag.CountedEnvelopes) throw new IntakeException("Zbir prihvaćenih i odbijenih koverata mora odgovarati kontrolnom brojanju.");
        if (input.Reasons.Select(x => x.ReasonId).Distinct().Count() != input.Reasons.Count) throw new IntakeException("Isti razlog je naveden više puta.");
        if (input.Reasons.Sum(x => (long)x.Quantity) != input.Rejected) throw new IntakeException("Zbir količina po razlozima mora odgovarati broju odbijenih koverata.");
        var selected = input.Reasons.Where(x => x.Quantity > 0).ToList();
        var ids = selected.Select(x => x.ReasonId).ToArray();
        var reasons = await db.RejectionReasons.Where(x => ids.Contains(x.Id) && x.Group == bag.Shipment.Group && x.IsActive).ToDictionaryAsync(x => x.Id);
        if (reasons.Count != selected.Count) throw new IntakeException("Razlog nije aktivan ili ne pripada kategoriji ove vreće. Osvježite stranicu.");
        var before = Snapshot(bag);
        var rows = selected.Select(x => new BagRejection { BagId = id, RunId = bag.RunId!.Value, RejectionReasonId = x.ReasonId, ReasonName = reasons[x.ReasonId].Name, Quantity = x.Quantity, Comment = x.Comment?.Trim() }).ToList();
        db.BagRejections.AddRange(rows);
        bag.ApprovedEnvelopes = input.Approved; bag.RejectedEnvelopes = input.Rejected; bag.PreparationComment = input.Comment?.Trim();
        bag.PreparedAtUtc = DateTime.UtcNow; bag.Stage = BagStage.Prepared;
        Audit(bag, actor, "Priprema za verifikaciju završena", before, null, rows.Select(x => new { x.ReasonName, x.Quantity, x.Comment }));
        await SaveAsync();
    }
    public async Task ReceiveAsync(int id, VerificationInput input, AppUser actor) {
        Validate(input);
        var bag = await GetAsync(id, input.Version, BagStage.Prepared);
        if (input.Received != bag.ApprovedEnvelopes) throw new IntakeException($"Preuzeto je {input.Received}, a pripremljeno {bag.ApprovedEnvelopes} koverata. Provjerite unos ili vratite vreću na pripremu.");
        var before = Snapshot(bag);
        bag.VerificationReceived = input.Received; bag.VerificationComment = input.Comment?.Trim(); bag.VerificationAtUtc = DateTime.UtcNow; bag.Stage = BagStage.Verification;
        Audit(bag, actor, "Primljeno na verifikaciju", before, null); await SaveAsync();
    }
    public async Task ReturnAsync(int id, VerificationInput input, AppUser actor) {
        Validate(input);
        if (string.IsNullOrWhiteSpace(input.Comment)) throw new IntakeException("Unesite razlog vraćanja na pripremu.");
        var bag = await GetAsync(id, input.Version, BagStage.Counted, BagStage.Prepared, BagStage.Verification);
        var before = Snapshot(bag);
        bag.Stage = BagStage.Received; bag.RunId = null; bag.CountedEnvelopes = null; bag.DifferenceReason = null;
        bag.ApprovedEnvelopes = null; bag.RejectedEnvelopes = null; bag.VerificationReceived = null;
        bag.CountedAtUtc = null; bag.PreparedAtUtc = null; bag.VerificationAtUtc = null; bag.PreparationComment = null; bag.VerificationComment = null;
        Audit(bag, actor, "Vraćeno na pripremu za verifikaciju", before, input.Comment.Trim()); await SaveAsync();
    }
    public async Task SaveReasonAsync(ReasonInput input, AppUser actor) {
        Validate(input);
        if (string.IsNullOrWhiteSpace(input.Name)) throw new IntakeException("Unesite naziv razloga.");
        var name = input.Name.Trim(); var normalized = name.ToUpperInvariant();
        if (await db.RejectionReasons.AnyAsync(x => x.Group == input.Group && x.NormalizedName == normalized && x.Id != input.Id)) throw new IntakeException("Razlog s ovim nazivom već postoji u kategoriji, uključujući neaktivne razloge.");
        RejectionReason reason; object? before = null;
        if (input.Id == 0) { reason = new(); db.RejectionReasons.Add(reason); }
        else {
            reason = await db.RejectionReasons.FindAsync(input.Id) ?? throw new IntakeException("Razlog nije pronađen.");
            if (input.Version == Guid.Empty || reason.Version != input.Version) throw new IntakeException("Razlog je u međuvremenu izmijenjen. Osvježite stranicu.");
            if (reason.Group != input.Group && (await db.BagRejections.AnyAsync(x => x.RejectionReasonId == reason.Id) || await db.VerificationRejections.AnyAsync(x=>x.RejectionReasonId==reason.Id))) throw new IntakeException("Kategoriju korištenog razloga nije moguće mijenjati. Deaktivirajte ga i dodajte novi razlog.");
            before = new { reason.Id, reason.Name, reason.Group, reason.IsActive };
        }
        reason.Name = name; reason.NormalizedName = normalized; reason.Group = input.Group; reason.IsActive = input.IsActive; reason.Version = Guid.NewGuid();
        db.AuditEntries.Add(new AuditEntry { ActorId = actor.Id, ActorName = actor.DisplayName, Action = input.Id == 0 ? "Dodan razlog odbijanja" : "Izmijenjen razlog odbijanja", BeforeJson = before == null ? null : JsonSerializer.Serialize(before), AfterJson = JsonSerializer.Serialize(new { reason.Name, reason.Group, reason.IsActive }) });
        await SaveAsync();
    }
    private async Task<Bag> GetAsync(int id, Guid version, params BagStage[] stages) {
        var bag = await db.Bags.Include(x => x.Shipment).SingleOrDefaultAsync(x => x.Id == id) ?? throw new IntakeException("Vreća nije pronađena.");
        if (bag.Shipment.Status != IntakeStatus.Closed) throw new IntakeException("Prvo završite prijem pošiljke.");
        if (!stages.Contains(bag.Stage)) throw new IntakeException("Vreća nije u odgovarajućem koraku obrade. Osvježite pregled.");
        if (version == Guid.Empty || version != bag.Version) throw new IntakeException("Drugi operater je izmijenio vreću. Osvježite stranicu.");
        return bag;
    }
    private static object Snapshot(Bag b) => new { b.Barcode, b.Stage, b.TotalEnvelopes, b.RunId, b.CountedEnvelopes, b.ApprovedEnvelopes, b.RejectedEnvelopes, b.VerificationReceived, b.DifferenceReason, b.PreparationComment, b.VerificationComment };
    private void Audit(Bag bag, AppUser actor, string action, object before, string? reason, object? rejections = null) {
        bag.Version = Guid.NewGuid();
        db.AuditEntries.Add(new AuditEntry { BagId = bag.Id, ShipmentId = bag.ShipmentId, ActorId = actor.Id, ActorName = actor.DisplayName, Action = action, Reason = reason, BeforeJson = JsonSerializer.Serialize(before), AfterJson = JsonSerializer.Serialize(new { Bag = Snapshot(bag), Rejections = rejections }) });
    }
    private static void Validate(object value) {
        var errors = new List<ValidationResult>();
        if (!Validator.TryValidateObject(value, new ValidationContext(value), errors, true)) throw new IntakeException(string.Join(" ", errors.Select(x => x.ErrorMessage)));
    }
    private async Task SaveAsync() {
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateConcurrencyException) { db.ChangeTracker.Clear(); throw new IntakeException("Podaci su izmijenjeni u drugom prozoru. Osvježite stranicu."); }
        catch (DbUpdateException) { db.ChangeTracker.Clear(); throw new IntakeException("Podaci nisu sačuvani. Provjerite duplikate i osvježite stranicu."); }
    }
}
