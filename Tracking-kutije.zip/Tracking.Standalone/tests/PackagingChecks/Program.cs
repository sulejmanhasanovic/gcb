using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
var count=0;
void Check(bool condition,string name){if(!condition)throw new Exception(name);count++;Console.WriteLine("PASS "+name);}
async Task Reject(Func<Task> action,string name){try{await action();}catch(IntakeException){Check(true,name);return;}throw new Exception("Expected rejection: "+name);}
var file=Path.Combine(Path.GetTempPath(),"tracking-pack-"+Guid.NewGuid()+".db");
var race=new RaceInterceptor();
var plain=new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source="+file).Options;
var options=new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source="+file).AddInterceptors(race).Options;
await using var db=new TrackingDbContext(options);await db.Database.MigrateAsync();
Check(!db.Database.HasPendingModelChanges(),"SQLite migration matches model");
await using var sql=new SqlServerDesignFactory().CreateDbContext([]);
Check(!sql.Database.HasPendingModelChanges(),"SQL Server migration matches model");
Check(sql.Database.GetMigrations().Count()==5&&db.Database.GetMigrations().Count()==5,"Provider migrations isolated");
Check(sql.Database.GenerateCreateScript().Contains("[FK_BoxItems_Boxes_BoxId]"),"SQL Server box relationship DDL");
Check(await db.Combinations.CountAsync(x=>x.IsActive)==24&&!await db.Combinations.AnyAsync(x=>x.Code=="KXX"&&x.IsActive),"24 usable combinations, KXX excluded");
var actor=new AppUser{Id="operator",UserName="operator",DisplayName="Test operater"};db.Users.Add(actor);await db.SaveChangesAsync();
var service=new PackagingService(db);var workflow=new WorkflowService(db);
async Task<Bag> NewBag(IntakeGroup group,string name,int total=10){
    var shipment=new Shipment{Reference=name,Group=group,ExpectedEnvelopes=total,Status=IntakeStatus.Closed,CreatedById=actor.Id};
    var bag=new Bag{Barcode=name,Shipment=shipment,TotalEnvelopes=total,CreatedById=actor.Id};db.Bags.Add(bag);await db.SaveChangesAsync();
    await Reject(()=>service.FinalizeAsync(bag.Id,new(){Version=bag.Version,Accepted=total},actor),"Cannot verify before receiving "+group);
    await workflow.CountAsync(bag.Id,new(){Version=bag.Version,Counted=total},actor);
    await workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=total,Rejected=0},actor);
    await workflow.ReceiveAsync(bag.Id,new(){Version=bag.Version,Received=total},actor);return bag;
}
foreach(var group in Enum.GetValues<IntakeGroup>()){
    var bag=await NewBag(group,"BAG-"+group);var reason=new RejectionReason{Name="Odbijeno",NormalizedName="ODBIJENO",Group=group};db.RejectionReasons.Add(reason);await db.SaveChangesAsync();
    await Reject(()=>service.FinalizeAsync(bag.Id,new(){Version=bag.Version,Accepted=11},actor),"Verification sum enforced "+group);
    await Reject(()=>service.FinalizeAsync(bag.Id,new(){Version=bag.Version,Accepted=8,Rejected=2},actor),"Rejection reasons required "+group);
    await service.FinalizeAsync(bag.Id,new(){Version=bag.Version,Accepted=8,Rejected=2,Reasons=[new(){ReasonId=reason.Id,Quantity=2}]},actor);
    Check(bag.Stage==BagStage.Verified&&bag.ApprovedEnvelopes==10,"Final verification preserves preparation "+group);
    Check((await db.VerificationResults.Include(x=>x.Reasons).SingleAsync(x=>x.BagId==bag.Id)).Reasons.Single().ReasonName=="Odbijeno","Reason snapshot "+group);
    await Reject(()=>workflow.ReturnAsync(bag.Id,new(){Version=bag.Version,Comment="test"},actor),"Cannot reset final verification "+group);
    await Reject(()=>service.FinalizeAsync(bag.Id,new(){Version=bag.Version,Accepted=10},actor),"Cannot finalize twice "+group);
    var box=await service.CreateAsync(new(){Group=group,CombinationId=1},actor);
    await Reject(()=>service.FillAsync(box.Id,box.Version,actor),"Cannot close empty box "+group);
    await Reject(()=>service.AllocateAsync(bag.Id,new(){Version=bag.Version,BoxId=box.Id,BoxVersion=box.Version,Quantity=9},actor),"Cannot over-allocate "+group);
    var oldVersion=bag.Version;
    await service.AllocateAsync(bag.Id,new(){Version=bag.Version,BoxId=box.Id,BoxVersion=box.Version,Quantity=3},actor);
    await Reject(()=>service.AllocateAsync(bag.Id,new(){Version=oldVersion,BoxId=box.Id,BoxVersion=box.Version,Quantity=3},actor),"Duplicate stale post rejected "+group);
    await Reject(()=>service.FinishBagAsync(bag.Id,bag.Version,actor),"Cannot finish partially packed bag "+group);
    await Reject(()=>service.FillAsync(box.Id,box.Version,actor),"Cannot close box with unfinished bag "+group);
    var item=await db.BoxItems.SingleAsync(x=>x.BagId==bag.Id);
    await service.RemoveAsync(item.Id,bag.Version,box.Version,"Pogrešna kutija",actor);
    Check(!await db.BoxItems.AnyAsync(x=>x.BagId==bag.Id),"Correction restores remaining quantity "+group);
    await service.AllocateAsync(bag.Id,new(){Version=bag.Version,BoxId=box.Id,BoxVersion=box.Version,Quantity=8},actor);
    await service.FinishBagAsync(bag.Id,bag.Version,actor);await service.FillAsync(box.Id,box.Version,actor);
    Check(box.Status==BoxStatus.Filled&&box.FilledById==actor.Id&&bag.Stage==BagStage.Packed,"Complete bag to filled box "+group);
    item=await db.BoxItems.SingleAsync(x=>x.BagId==bag.Id);
    await Reject(()=>service.RemoveAsync(item.Id,bag.Version,box.Version,"Test",actor),"Closed contents protected "+group);
}
await Reject(()=>service.CreateAsync(new(){Group=IntakeGroup.Posta,CombinationId=25},actor),"KXX cannot form a box");
await Reject(()=>service.CreateAsync(new(){Group=(IntakeGroup)99,CombinationId=1},actor),"Invalid category rejected");
var split=await NewBag(IntakeGroup.Posta,"SPLIT");await service.FinalizeAsync(split.Id,new(){Version=split.Version,Accepted=10},actor);
var first=await service.CreateAsync(new(){Group=IntakeGroup.Posta,CombinationId=1},actor);
var second=await service.CreateAsync(new(){Group=IntakeGroup.Posta,CombinationId=2},actor);
var wrong=await service.CreateAsync(new(){Group=IntakeGroup.Mobilni,CombinationId=1},actor);
await Reject(()=>service.AllocateAsync(split.Id,new(){Version=split.Version,BoxId=wrong.Id,BoxVersion=wrong.Version,Quantity=1},actor),"Cross-category allocation rejected");
await service.AllocateAsync(split.Id,new(){Version=split.Version,BoxId=first.Id,BoxVersion=first.Version,Quantity=6},actor);
await service.AllocateAsync(split.Id,new(){Version=split.Version,BoxId=second.Id,BoxVersion=second.Version,Quantity=4},actor);
await service.FinishBagAsync(split.Id,split.Version,actor);
Check(await db.BoxItems.Where(x=>x.BagId==split.Id).Select(x=>x.BoxId).Distinct().CountAsync()==2,"One bag split across combinations and boxes");
var extra=await NewBag(IntakeGroup.Posta,"EXTRA");await service.FinalizeAsync(extra.Id,new(){Version=extra.Version,Accepted=10},actor);
await service.AllocateAsync(extra.Id,new(){Version=extra.Version,BoxId=first.Id,BoxVersion=first.Version,Quantity=10},actor);await service.FinishBagAsync(extra.Id,extra.Version,actor);await service.FillAsync(first.Id,first.Version,actor);
Check(await db.BoxItems.Where(x=>x.BoxId==first.Id).SumAsync(x=>x.Quantity)==16,"Multiple bags contribute to one box");
var competing=await NewBag(IntakeGroup.Posta,"RACE");await service.FinalizeAsync(competing.Id,new(){Version=competing.Version,Accepted=10},actor);
var target=await service.CreateAsync(new(){Group=IntakeGroup.Posta,CombinationId=1},actor);
var stale=competing.Version;var boxToken=target.Version;
race.BeforeSave=async()=>{await using var other=new TrackingDbContext(plain);await new PackagingService(other).AllocateAsync(competing.Id,new(){Version=stale,BoxId=target.Id,BoxVersion=boxToken,Quantity=7},actor);};
await Reject(()=>service.AllocateAsync(competing.Id,new(){Version=stale,BoxId=target.Id,BoxVersion=boxToken,Quantity=7},actor),"Concurrent over-allocation rolls back loser");
Check(await db.BoxItems.Where(x=>x.BagId==competing.Id).SumAsync(x=>x.Quantity)==7,"Concurrent allocations preserve accepted limit");
Check(await db.AuditEntries.CountAsync(x=>x.BagId==competing.Id&&x.Action=="Koverte raspoređene u kutiju")==1,"Failed allocation audit rolled back");
db.ChangeTracker.Clear();competing=await db.Bags.Include(x=>x.Shipment).SingleAsync(x=>x.Id==competing.Id);target=await db.Boxes.SingleAsync(x=>x.Id==target.Id);
await service.AllocateAsync(competing.Id,new(){Version=competing.Version,BoxId=target.Id,BoxVersion=target.Version,Quantity=3},actor);await service.FinishBagAsync(competing.Id,competing.Version,actor);
var incoming=await NewBag(IntakeGroup.Posta,"CLOSE-RACE");await service.FinalizeAsync(incoming.Id,new(){Version=incoming.Version,Accepted=10},actor);
var closeToken=target.Version;
race.BeforeSave=async()=>{await using var other=new TrackingDbContext(plain);await new PackagingService(other).FillAsync(target.Id,closeToken,actor);};
await Reject(()=>service.AllocateAsync(incoming.Id,new(){Version=incoming.Version,BoxId=target.Id,BoxVersion=closeToken,Quantity=1},actor),"Concurrent box closure blocks new allocation");
Check(!await db.BoxItems.AnyAsync(x=>x.BagId==incoming.Id),"Closed box race leaves no stray item");
Check(await db.VotesCast.CountAsync()==0&&await db.ScanningSessions.CountAsync()==0,"Material workflow does not depend on scanning");
Check(await db.AuditEntries.AnyAsync(x=>x.BoxId!=null&&x.ActorId==actor.Id),"Box history records actor");
Console.WriteLine($"Completed {count} packaging checks.");
await db.Database.CloseConnectionAsync();Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();File.Delete(file);
class RaceInterceptor:SaveChangesInterceptor {
    public Func<Task>? BeforeSave;
    public override async ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData data,InterceptionResult<int> result,CancellationToken ct=default){var callback=BeforeSave;BeforeSave=null;if(callback!=null)await callback();return result;}
}
