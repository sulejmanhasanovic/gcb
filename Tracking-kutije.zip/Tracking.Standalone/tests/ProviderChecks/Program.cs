using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;

var checks = 0;
void Check(bool ok, string name) { if (!ok) throw new Exception(name); checks++; Console.WriteLine("PASS " + name); }
async Task Reject(Func<Task> action, string name) {
    var rejected = false;
    try { await action(); } catch (IntakeException) { rejected = true; }
    Check(rejected, name);
}
await using var sql = new SqlServerDesignFactory().CreateDbContext([]);
Check(sql.Database.GetMigrations().Count() == 5 && sql.Database.GetMigrations().Last().EndsWith("PackagingSqlServer"), "SQL Server migration isolation");
Check(!sql.Database.HasPendingModelChanges(), "SQL Server model matches migration");
var ddl = sql.Database.GenerateCreateScript();
Check(ddl.Contains("IDENTITY") && ddl.Contains("[PollingStations]") && ddl.Contains("[GeneratedBags]") && !ddl.Contains("AUTOINCREMENT"), "SQL Server registry DDL");
var options = new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source=:memory:").Options;
await using var db = new TrackingDbContext(options);
await db.Database.OpenConnectionAsync();
Check(db.Database.GetMigrations().Count() == 5, "SQLite migration isolation");
Check(!db.Database.HasPendingModelChanges(), "SQLite model matches migration");
// Upgrade from the first release with existing operational records.
await db.GetService<IMigrator>().MigrateAsync("20260923082830_InitialTracking");
var user = new AppUser { Id = "test-user", UserName = "test", DisplayName = "Test" };
db.Users.Add(user); await db.SaveChangesAsync();
await db.Database.ExecuteSqlRawAsync("INSERT INTO Shipments (Reference, \"Group\", ReceivedDate, ExpectedEnvelopes, Undelivered, OtherMaterials, Status, CreatedById, CreatedAtUtc, Version) VALUES ('LEGACY',1,'2026-09-23',5,0,0,1,'test-user','2026-09-23','00000000-0000-0000-0000-000000000001')");
await db.Database.ExecuteSqlRawAsync("INSERT INTO Bags (ShipmentId,Barcode,RegularEnvelopes,ExpressEnvelopes,TotalEnvelopes,CreatedById,CreatedAtUtc) VALUES (1,'001',5,0,5,'test-user','2026-09-23')");
await db.Database.MigrateAsync();
Check(await db.Bags.CountAsync() == 1 && (await db.Bags.SingleAsync()).GeneratedBagId == null, "Upgrade preserves old receipt");
var dataFile = Path.GetFullPath(args.Length > 0 ? args[0] : "outputs/Tracking/database/polling-stations.json");
Check(await PollingStationImport.ImportAsync(db, dataFile) == 662, "Imports all 662 supported polling stations");
Check(await PollingStationImport.ImportAsync(db, dataFile) == 0, "Re-import is idempotent");
Check(await db.PollingStations.CountAsync(x => x.Group == IntakeGroup.Dkp) == 20 && await db.PollingStations.CountAsync(x => x.Group == IntakeGroup.Odsustvo) == 114, "DKP and Odsustvo mappings");
Check(await db.PollingStations.AnyAsync(x => x.Code.StartsWith("0") && x.MunicipalityCode!.StartsWith("0")), "Leading zeroes retained");
var registry = new BagRegistryService(db);
var intake = new IntakeService(db);
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Posta, Quantity = 3 }, user) == 3, "Postal bulk generation");
Check(!await db.GeneratedBags.AnyAsync(x => x.Barcode == "001") && await db.GeneratedBags.AnyAsync(x => x.Barcode == "002"), "Postal sequence skips legacy barcodes");
var deletedPostal = await db.GeneratedBags.SingleAsync(x => x.Barcode == "004");
Check(await registry.DeleteAsync([deletedPostal.Id], user) == 1, "Delete unreceived postal bag");
await registry.GenerateAsync(new() { Group = IntakeGroup.Posta }, user);
Check(await db.GeneratedBags.AnyAsync(x => x.Barcode == "005") && !await db.GeneratedBags.AnyAsync(x => x.Barcode == "004"), "Deleted postal number not reused");
foreach (var group in Enum.GetValues<IntakeGroup>().Where(x => x != IntakeGroup.Posta)) {
    var station = await db.PollingStations.FirstAsync(x => x.Group == group);
    Check(await registry.GenerateAsync(new() { Group = group, PollingStationId = station.Id }, user) == 1, group + " single generation");
    Check(await registry.GenerateAsync(new() { Group = group, PollingStationId = station.Id }, user) == 0, group + " prevents duplicate generation");
}
await Reject(() => registry.GenerateAsync(new() { Group = IntakeGroup.Posta, PollingStationId = 1 }, user), "Postal station rejected");
await Reject(() => registry.GenerateAsync(new() { Group = IntakeGroup.Posta, Quantity = 1001 }, user), "Generation quantity bounded");
foreach (var group in Enum.GetValues<IntakeGroup>()) {
    var generated = await db.GeneratedBags.Include(x => x.PollingStation).FirstAsync(x => x.Group == group);
    var id = await intake.CreateAsync(new ShipmentInput { Reference = group.ToString(), Group = group, ExpectedEnvelopes = 5 }, user);
    var shipment = (await db.Shipments.FindAsync(id))!;
    var oldVersion = shipment.Version;
    BagInput Input(string barcode) => new() { Barcode = barcode, Version = oldVersion, RegularEnvelopes = group == IntakeGroup.Posta ? 5 : 0, TotalEnvelopes = group == IntakeGroup.Posta ? 0 : 5 };
    await Reject(() => intake.AddBagAsync(id, Input("NOT-GENERATED"), user), group + " rejects unknown bag");
    var other = await db.GeneratedBags.FirstAsync(x => x.Group != group);
    await Reject(() => intake.AddBagAsync(id, Input(other.Barcode), user), group + " rejects wrong category");
    await intake.AddBagAsync(id, Input(generated.Barcode), user);
    var receipt = await db.Bags.SingleAsync(x => x.GeneratedBagId == generated.Id);
    Check(receipt.PollingStationCode == generated.PollingStation?.Code, group + " receives generated bag with automatic station");
    await Reject(() => registry.DeleteAsync([generated.Id], user), group + " protects received bag");
    await Reject(() => intake.CloseAsync(id, oldVersion, user), group + " rejects stale version");
    await intake.CloseAsync(id, shipment.Version, user);
    Check(shipment.Status == IntakeStatus.Closed, group + " completes intake");
}
var freeBag = await db.GeneratedBags.FirstAsync(x => x.Receipt == null);
var usedBag = await db.GeneratedBags.FirstAsync(x => x.Receipt != null);
await Reject(() => registry.DeleteAsync([freeBag.Id, usedBag.Id], user), "Mixed deletion batch rejected atomically");
Check(await db.GeneratedBags.AnyAsync(x => x.Id == freeBag.Id), "Unreceived bag remains after failed batch");
var beforeCount = await db.GeneratedBags.CountAsync();
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Mobilni }, user) == 384, "Bulk station generation skips existing");
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Mobilni }, user) == 0, "Repeated bulk generation is idempotent");
Check(await db.AuditEntries.AnyAsync(x => x.Action == "Generisane vreće") && await db.AuditEntries.AnyAsync(x => x.Action == "Obrisane nezaprimljene vreće"), "Registry mutations audited");
Check(await db.BagReceiptEntries.AnyAsync(x=>x.Bag.Barcode=="001"&&x.TotalEnvelopes==5), "Legacy bag detail migrated");
Check(await db.Bags.AllAsync(x=>x.Version!=Guid.Empty&&x.Stage==BagStage.Received), "Legacy and new workflow versions initialized");
var workflow = new WorkflowService(db);
foreach(var group in Enum.GetValues<IntakeGroup>()) {
    await workflow.SaveReasonAsync(new(){Name="Test reason",Group=group},user);
    var reason=await db.RejectionReasons.SingleAsync(x=>x.Group==group);
    await Reject(()=>workflow.SaveReasonAsync(new(){Name=" test REASON ",Group=group},user),group+" rejects duplicate reason");
    var bag=await db.Bags.Include(x=>x.Shipment).FirstAsync(x=>x.Shipment.Group==group&&x.Shipment.Status==IntakeStatus.Closed);
    await Reject(()=>workflow.ReceiveAsync(bag.Id,new(){Version=bag.Version,Received=5},user),group+" cannot skip counting");
    await Reject(()=>workflow.CountAsync(bag.Id,new(){Version=bag.Version,Counted=6},user),group+" mismatch requires explicit confirmation");
    await workflow.CountAsync(bag.Id,new(){Version=bag.Version,Counted=6,ConfirmDifference=true,DifferenceReason="Recounted"},user);
    Check(bag.TotalEnvelopes==5&&bag.CountedEnvelopes==6,group+" original intake preserved after discrepancy");
    await Reject(()=>workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=4,Rejected=1,Reasons=[new(){ReasonId=reason.Id,Quantity=1}]},user),group+" preparation total enforced");
    await Reject(()=>workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=5,Rejected=1},user),group+" rejection sum enforced");
    var wrong=await db.RejectionReasons.FirstOrDefaultAsync(x=>x.Group!=group);
    if(wrong!=null)await Reject(()=>workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=5,Rejected=1,Reasons=[new(){ReasonId=wrong.Id,Quantity=1}]},user),group+" reason category enforced");
    await workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=5,Rejected=1,Reasons=[new(){ReasonId=reason.Id,Quantity=1,Comment="Checked"}]},user);
    var run=bag.RunId;
    await Reject(()=>workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=6},user),group+" duplicate preparation blocked");
    await workflow.SaveReasonAsync(new(){Id=reason.Id,Version=reason.Version,Name="Renamed reason",Group=group,IsActive=false},user);
    Check(await db.BagRejections.AnyAsync(x=>x.BagId==bag.Id&&x.ReasonName=="Test reason"),group+" used reason label preserved");
    await Reject(()=>workflow.ReceiveAsync(bag.Id,new(){Version=bag.Version,Received=4},user),group+" verification mismatch blocked");
    await workflow.ReceiveAsync(bag.Id,new(){Version=bag.Version,Received=5},user);
    Check(bag.Stage==BagStage.Verification&&bag.VerificationReceived==5,group+" completes verification receipt");
    await Reject(()=>workflow.ReturnAsync(bag.Id,new(){Version=bag.Version},user),group+" return requires reason");
    await workflow.ReturnAsync(bag.Id,new(){Version=bag.Version,Comment="Repeat preparation"},user);
    Check(bag.Stage==BagStage.Received&&bag.CountedEnvelopes==null&&bag.VerificationReceived==null&&await db.BagRejections.AnyAsync(x=>x.BagId==bag.Id&&x.RunId==run),group+" return preserves previous run");
    await workflow.CountAsync(bag.Id,new(){Version=bag.Version,Counted=5},user);
    await Reject(()=>workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=4,Rejected=1,Reasons=[new(){ReasonId=reason.Id,Quantity=1}]},user),group+" inactive reason rejected");
    await workflow.PrepareAsync(bag.Id,new(){Version=bag.Version,Approved=5,Rejected=0},user);
    await workflow.ReceiveAsync(bag.Id,new(){Version=bag.Version,Received=5},user);
    Check(bag.RunId!=run,group+" new preparation has separate history");
}
var postalId=await intake.CreateAsync(new(){Reference="POSTAL-MULTI",Group=IntakeGroup.Posta,ExpectedEnvelopes=10,Undelivered=2,OtherMaterials=3},user);
var postal=(await db.Shipments.FindAsync(postalId))!;
var postalCode=(await db.GeneratedBags.FirstAsync(x=>x.Group==IntakeGroup.Posta&&x.Receipt==null)).Barcode;
await intake.AddBagAsync(postalId,new(){Version=postal.Version,Barcode=postalCode,RegularEnvelopes=3,PoBox="451"},user);
await intake.AddBagAsync(postalId,new(){Version=postal.Version,Barcode=postalCode,ExpressEnvelopes=6,PoBox="452"},user);
var postalBag=await db.Bags.Include(x=>x.Entries).SingleAsync(x=>x.Barcode==postalCode);
Check(postalBag.Entries.Count==2&&postalBag.TotalEnvelopes==9,"Postal multiple receipt lines aggregate in same bag");
await Reject(()=>workflow.CountAsync(postalBag.Id,new(){Version=postalBag.Version,Counted=9},user),"Open shipment cannot enter preparation");
var entry=postalBag.Entries.First();
await intake.EditReceiptAsync(postalId,new(){EntryId=entry.Id,Version=postal.Version,Barcode=postalCode,RegularEnvelopes=4,PoBox="451",Reason="Correction"},user);
Check(postalBag.TotalEnvelopes==10&&postalBag.RegularEnvelopes==4&&postalBag.ExpressEnvelopes==6,"Receipt edit updates bag totals");
await Reject(()=>intake.CloseAsync(postalId,postal.Version,user),"Unreceived materials prevent closure");
await Reject(()=>intake.SaveMaterialAsync(postalId,new(){Version=postal.Version,IsUndelivered=true,Quantity=3},user),"Material cannot exceed announcement");
await intake.SaveMaterialAsync(postalId,new(){Version=postal.Version,IsUndelivered=true,Quantity=2},user);
await intake.SaveMaterialAsync(postalId,new(){Version=postal.Version,IsUndelivered=false,Quantity=2},user);
var material=postal.Materials.Single(x=>!x.IsUndelivered);
await intake.SaveMaterialAsync(postalId,new(){EntryId=material.Id,Version=postal.Version,IsUndelivered=false,Quantity=3,Reason="Correction"},user);
await intake.CloseAsync(postalId,postal.Version,user);
await Reject(()=>intake.EditReceiptAsync(postalId,new(){EntryId=entry.Id,Version=postal.Version,Barcode=postalCode,RegularEnvelopes=1,Reason="Too late"},user),"Closed receipt cannot be edited");
// Two contexts loading the same row verify actual optimistic concurrency, not only a stale input check.
var shared=new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite(db.Database.GetDbConnection()).Options;
await using(var concurrent=new TrackingDbContext(shared)) {
    var stale=await concurrent.Bags.Include(x=>x.Shipment).SingleAsync(x=>x.Id==postalBag.Id);
    await workflow.CountAsync(postalBag.Id,new(){Version=postalBag.Version,Counted=10},user);
    await Reject(()=>new WorkflowService(concurrent).CountAsync(stale.Id,new(){Version=stale.Version,Counted=10},user),"Competing count save is rejected by concurrency token");
}
Check(await db.AuditEntries.AnyAsync(x=>x.BagId==postalBag.Id&&x.Action=="Kontrolno brojanje završeno"),"Workflow mutations audited per bag");
var freeMobile=await db.GeneratedBags.FirstAsync(x=>x.Group==IntakeGroup.Mobilni&&x.Receipt==null);
var directId=await intake.DirectReceiptAsync(new(){Group=IntakeGroup.Mobilni,Barcode=freeMobile.Barcode,TotalEnvelopes=7},user);
var direct=await db.Shipments.Include(x=>x.Bags).SingleAsync(x=>x.Id==directId);
Check(direct.Bags.Count==1&&direct.ExpectedEnvelopes==7&&direct.Status==IntakeStatus.Open,"Direct intake creates complete review atomically");
await Reject(()=>intake.DirectReceiptAsync(new(){Group=IntakeGroup.Mobilni,Barcode=freeMobile.Barcode,TotalEnvelopes=7},user),"Direct duplicate rejected");
await Reject(()=>intake.DirectReceiptAsync(new(){Group=IntakeGroup.Posta,Barcode=freeMobile.Barcode,TotalEnvelopes=7},user),"Direct postal group rejected");
await intake.CloseAsync(directId,direct.Version,user);
var directBag=direct.Bags.Single();
await workflow.CountAsync(directBag.Id,new(){Version=directBag.Version,Counted=0,ConfirmDifference=true,DifferenceReason="Empty on recount"},user);
await workflow.PrepareAsync(directBag.Id,new(){Version=directBag.Version,Approved=0,Rejected=0},user);
await workflow.ReceiveAsync(directBag.Id,new(){Version=directBag.Version,Received=0},user);
Check(directBag.Stage==BagStage.Verification&&directBag.TotalEnvelopes==7,"Zero recount handled without losing original receipt");
Console.WriteLine($"{checks} checks passed. SQL Server DDL only; no live SQL Server available.");


