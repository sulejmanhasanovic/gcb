"""Run only against a disposable SQLite preview, with TRACKING_TEST_DB/URL/USER/PASSWORD.
Creates synthetic postal receipts, verifies and packages them through HTTP forms.
"""
import os, re, html, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar
from datetime import date
BASE=os.environ['TRACKING_TEST_URL']; DB=os.environ['TRACKING_TEST_DB']; PASSWORD=os.environ['TRACKING_TEST_PASSWORD']; checks=0
def check(ok,name):
    global checks
    assert ok,name
    checks+=1; print('PASS',name)
class Client:
    def __init__(self): self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(self,path,data=None):
        try:
            r=self.opener.open(BASE+path,urllib.parse.urlencode(data).encode() if data is not None else None)
            return r.status,html.unescape(r.read().decode()),r.url
        except urllib.error.HTTPError as e:return e.code,html.unescape(e.read().decode()),e.url
    def post(self,path,data,form='/Account/Password'):
        body=self.request(form)[1];token=re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"',body).group(1)
        return self.request(path,dict(data,__RequestVerificationToken=token))
    def login(self,name):return self.post('/Account/Login',{'UserName':name,'Password':PASSWORD},'/Account/Login')
def rows(sql,args=()):
    with sqlite3.connect(DB) as db:return db.execute(sql,args).fetchall()
def version(table,id):return rows(f'SELECT Version FROM {table} WHERE Id=?',(id,))[0][0]
admin=Client();anon=Client();tag=uuid.uuid4().hex[:6].upper()
check('/Account/Login' in anon.request('/Packaging')[2],'Anonymous requires login')
check('/Account/Login' not in admin.login(os.environ['TRACKING_TEST_USER'])[2],'Admin login')
check(admin.request('/Packaging')[0]==200,'Boxes page renders')
check(admin.request('/Packaging/Combinations')[0]==200,'Combination registry renders')
for path in ['/Packaging/Create','/Packaging/Allocate/1','/Packaging/Fill/1','/Packaging/FinishBag/1','/Packaging/Remove/1','/Workflow/FinalizeVerification/1']:
    check(admin.request(path,{})[0]==400,'CSRF required '+path)
for role in ['TRK_Pregled','TRK_Skeniranje']:
    name='pack.'+role.lower()+'.'+tag.lower();admin.post('/Users/Create',{'UserName':name,'DisplayName':'Test','Email':name+'@example.invalid','Password':PASSWORD,'Role':role},'/Users/Create')
    client=Client();client.login(name)
    check(client.request('/Packaging')[0]==200,role+' can view boxes')
    for path in ['/Packaging/Create','/Packaging/Allocate/1','/Packaging/Fill/1','/Packaging/FinishBag/1','/Packaging/Remove/1','/Workflow/FinalizeVerification/1']:
        result=client.post(path,{})
        check(result[0]==403 or '/Account/Denied' in result[2],role+' cannot write '+path)
admin.post('/BagRegistry/Generate',{'Group':'Posta','Quantity':2},'/BagRegistry')
codes=[r[0] for r in rows('SELECT Barcode FROM GeneratedBags WHERE "Group"=1 ORDER BY Id DESC LIMIT 2')]
result=admin.post('/Intake/Create',{'Reference':'DEMO-'+tag,'Group':'Posta','ReceivedDate':date.today().isoformat(),'ExpectedEnvelopes':200},'/Intake/Create')
check('/Intake/Details/' in result[2],'Postal shipment created')
sid=int(result[2].rsplit('/',1)[1]);bags=[]
for code,qty in zip(codes,[80,120]):
    result=admin.post('/Intake/AddBag/'+str(sid),{'Bag.Version':version('Shipments',sid),'Bag.Barcode':code,'Bag.RegularEnvelopes':qty,'Bag.TotalEnvelopes':qty},'/Intake/Details/'+str(sid))
    check(result[0]==200 and bool(rows('SELECT Id FROM Bags WHERE Barcode=?',(code,))),'Generated bag received '+code)
    bags.append((rows('SELECT Id FROM Bags WHERE Barcode=?',(code,))[0][0],qty))
admin.post('/Intake/Close/'+str(sid),{'version':version('Shipments',sid)})
check(rows('SELECT Status FROM Shipments WHERE Id=?',(sid,))[0][0]==2,'Receipt closed')
admin.post('/RejectionReasons/Edit',{'Id':0,'Group':'Posta','Name':'DEMO razlog '+tag,'IsActive':'true'},'/RejectionReasons/Edit')
reason_rows=rows('SELECT Id FROM RejectionReasons WHERE Name=?',('DEMO razlog '+tag,))
check(bool(reason_rows),'Rejection reason created');rid=reason_rows[0][0]
for bid,qty in bags:
    path='/Workflow/Details/'+str(bid)
    for action,data in [('Count',{'Count.Version':version('Bags',bid),'Count.Counted':qty})]:
        check(admin.post('/Workflow/'+action+'/'+str(bid),data,path)[0]==200,'Count form '+str(bid))
    admin.post('/Workflow/Prepare/'+str(bid),{'Preparation.Version':version('Bags',bid),'Preparation.Approved':qty,'Preparation.Rejected':0},path)
    admin.post('/Workflow/Receive/'+str(bid),{'Verification.Version':version('Bags',bid),'Verification.Received':qty},path)
    check('Konačni rezultat verifikacije' in admin.request(path)[1],'Final verification form shown')
    bad=admin.post('/Workflow/FinalizeVerification/'+str(bid),{'Final.Version':version('Bags',bid),'Final.Accepted':qty+1},path)
    check('mora odgovarati' in bad[1] and not rows('SELECT BagId FROM VerificationResults WHERE BagId=?',(bid,)),'Invalid final totals do not persist')
    result=admin.post('/Workflow/FinalizeVerification/'+str(bid),{'Final.Version':version('Bags',bid),'Final.Accepted':qty-2,'Final.Rejected':2,'Final.Reasons[0].ReasonId':rid,'Final.Reasons[0].Quantity':2},path)
    check('/Packaging/Bag/' in result[2] and result[0]==200,'Verification continues to packing')
boxids=[]
for combination in [1,2]:
    result=admin.post('/Packaging/Create',{'Group':'Posta','CombinationId':combination},'/Packaging')
    check('/Packaging/Details/' in result[2],'Box formed');boxids.append(int(result[2].rsplit('/',1)[1]))
bid=bags[0][0];target=boxids[0]
bad=admin.post('/Packaging/Allocate/'+str(bid),{'Version':version('Bags',bid),'BoxVersion':version('Boxes',target),'BoxId':target,'Quantity':81})
check('Preostalo je' in bad[1] and not rows('SELECT Id FROM BoxItems WHERE BagId=?',(bid,)),'HTTP rejects over-allocation')
for bid,box,qty in [(bags[0][0],boxids[0],50),(bags[0][0],boxids[1],28),(bags[1][0],boxids[0],118)]:
    result=admin.post('/Packaging/Allocate/'+str(bid),{'Version':version('Bags',bid),'BoxVersion':version('Boxes',box),'BoxId':box,'Quantity':qty})
    check(result[0]==200 and 'Količina je dodana' in result[1],'Allocate accepted quantity')
for bid,qty in bags:
    result=admin.post('/Packaging/FinishBag/'+str(bid),{'Version':version('Bags',bid)})
    check(rows('SELECT Stage FROM Bags WHERE Id=?',(bid,))[0][0]==6,'Bag packing completed')
for box in boxids:
    result=admin.post('/Packaging/Fill/'+str(box),{'Version':version('Boxes',box)})
    check(rows('SELECT Status FROM Boxes WHERE Id=?',(box,))[0][0]==2 and 'sadržaj zaključan' in result[1],'Filled box renders locked state')
check(rows('SELECT SUM(Quantity) FROM BoxItems WHERE BoxId=?',(boxids[0],))[0][0]==168,'Merged box has exact quantity 168')
check(rows('SELECT SUM(Quantity) FROM BoxItems WHERE BoxId=?',(boxids[1],))[0][0]==28,'Split box has exact quantity 28')
check(rows('SELECT COUNT(*) FROM VotesCast')[0][0]==0,'No scanning required')
print(f'{checks} packaging HTTP checks passed; demonstration box IDs: {boxids}')
