"""Run against a disposable preview database. Uses the workflow test's shared HTTP helpers."""
from pathlib import Path
exec(Path(__file__).with_name('workflow_http_checks.py').read_text(encoding='utf-8').split('admin=Client();')[0])
import datetime
admin=Client();admin.login(os.environ['TRACKING_TEST_USER'],os.environ['TRACKING_TEST_PASSWORD'])
admin.post('/BagRegistry/Generate',{'Group':'Posta','Quantity':1},'/BagRegistry')
reference='HTTP-POST-'+uuid.uuid4().hex[:8]
result=admin.post('/Intake/Create',{'Reference':reference,'Group':'Posta','ReceivedDate':str(datetime.date.today()),'ExpectedEnvelopes':10,'Undelivered':2,'OtherMaterials':3},'/Intake/Create')
check('/Intake/Details/' in result[2],'Postal shipment created')
path=urllib.parse.urlsplit(result[2]).path;shipment_id=path.rsplit('/',1)[1]
code=re.search(r'<datalist id="available-bags">\s*<option value="([^"]+)"',result[1]).group(1)
for regular,express,box in [(3,0,'451'),(0,6,'452')]:
    _,body,_=admin.request(path)
    result=admin.post('/Intake/AddBag/'+shipment_id,{'Bag.Version':field(body,'Bag.Version'),'Bag.Barcode':code,'Bag.RegularEnvelopes':regular,'Bag.ExpressEnvelopes':express,'Bag.PoBox':box},path)
    check('Vreća je evidentirana.' in result[1],'Postal entry '+box+' received')
entries=re.findall(r'href="(/Intake/EditReceipt/[^\"]+)"',result[1]);check(len(entries)==2,'Both postal receipt rows visible')
edit_path=entries[0];_,body,_=admin.request(edit_path)
result=admin.post(edit_path,{'EntryId':field(body,'EntryId'),'Version':field(body,'Version'),'Barcode':code,'RegularEnvelopes':4,'ExpressEnvelopes':0,'PoBox':'451','Reason':'Provjera ispravke'},edit_path)
check('Ispravka je sačuvana.' in result[1],'Postal entry correction submitted')
result=admin.post('/Intake/Close/'+shipment_id,{'version':field(result[1],'version')},path)
check('Evidentirajte sve najavljene' in result[1],'Closure blocks missing postal materials')
for undelivered,quantity in [('true',2),('false',2)]:
    _,body,_=admin.request(path)
    result=admin.post('/Intake/AddMaterial/'+shipment_id,{'Material.Version':field(body,'Material.Version'),'Material.IsUndelivered':undelivered,'Material.Quantity':quantity},path)
    check('Materijal je evidentiran.' in result[1],'Material received '+undelivered)
material_paths=re.findall(r'href="(/Intake/EditMaterial/[^\"]+)"',result[1]);check(len(material_paths)==2,'Material receipt rows visible')
edit_path=material_paths[-1];_,body,_=admin.request(edit_path)
result=admin.post(edit_path,{'EntryId':field(body,'EntryId'),'Version':field(body,'Version'),'IsUndelivered':field(body,'IsUndelivered'),'Quantity':3,'Reason':'Provjera ispravke'},edit_path)
check('Ispravka materijala je sačuvana.' in result[1],'Material correction submitted')
result=admin.post('/Intake/Close/'+shipment_id,{'version':field(result[1],'version')},path)
check('Prijem završen' in result[1],'Postal intake closes when both totals match')
bag_id=re.search(r'href="/Workflow/Details/(\d+)"',result[1]).group(1);flow='/Workflow/Details/'+bag_id
_,body,_=admin.request(flow)
result=admin.post('/Workflow/Count/'+bag_id,{'Count.Version':field(body,'Count.Version'),'Count.Counted':10},flow)
version=field(result[1],'Preparation.Version')
invalid=admin.post('/Workflow/Prepare/'+bag_id,{'Preparation.Version':version,'Preparation.Approved':9,'Preparation.Rejected':0},flow)
check('Zbir prihvaćenih i odbijenih' in invalid[1],'Preparation validation message is specific')
result=admin.post('/Workflow/Prepare/'+bag_id,{'Preparation.Version':version,'Preparation.Approved':10,'Preparation.Rejected':0},flow)
check('action="/Workflow/Receive/' in result[1],'Postal preparation completed')
result=admin.post('/Workflow/Receive/'+bag_id,{'Verification.Version':field(result[1],'Verification.Version'),'Verification.Received':10},flow)
check('Primljena na verifikaciju' in result[1],'Postal verification receipt completed')
print(str(checks)+' postal HTTP checks passed; sample '+BASE+path)
