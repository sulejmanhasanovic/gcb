"""Use only a disposable SQLite preview. Seeds synthetic voter records and scans them.
Required: TRACKING_TEST_DB, TRACKING_TEST_URL, TRACKING_TEST_USER,
TRACKING_TEST_PASSWORD, TRACKING_TEST_ELECTION. Never run against real election data.
"""
import os, re, html, sqlite3, uuid, urllib.request, urllib.parse, urllib.error, http.cookiejar
BASE=os.environ['TRACKING_TEST_URL']; PASSWORD=os.environ['TRACKING_TEST_PASSWORD']
ELECTION=os.environ['TRACKING_TEST_ELECTION']; checks=0
class Client:
    def __init__(self): self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(self,path,data=None):
        try:
            r=self.opener.open(BASE+path,urllib.parse.urlencode(data).encode() if data is not None else None)
            return r.status,html.unescape(r.read().decode()),r.url
        except urllib.error.HTTPError as e: return e.code,html.unescape(e.read().decode()),e.url
    def post(self,path,data,form='/Account/Password'):
        body=self.request(form)[1]; token=re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"',body).group(1)
        return self.request(path,dict(data,__RequestVerificationToken=token))
    def login(self,name):return self.post('/Account/Login',{'UserName':name,'Password':PASSWORD},'/Account/Login')
def check(ok,name):
    global checks
    assert ok,name
    checks+=1;print('PASS',name)
admin=Client();anon=Client()
check('/Account/Login' in anon.request('/Scanning')[2],'Anonymous requires login')
check('/Account/Login' not in admin.login(os.environ['TRACKING_TEST_USER'])[2],'Administrator login')
tag=uuid.uuid4().hex[:5].upper()
types=[('Nepotvrdjeni','N'),('Odsustvo','2'),('Mobilni','M'),('Posta','O'),('Dkp','D'),('Redovni','1')]
records=[]
with sqlite3.connect(os.environ['TRACKING_TEST_DB']) as db:
    for i,(category,source) in enumerate(types):
        jmbg='000'+str(uuid.uuid4().int%10**10).zfill(10); code='T'+tag+str(i)
        db.execute('INSERT INTO Voters(ElectionCode,Jmbg,FirstName,LastName,IsEligible,SourceEligibilityCode,SourceTypeCode,PollingStationCode) VALUES(?,?,?,?,?,?,?,?)',(ELECTION,jmbg,'Test','Skeniranje '+category,1,'1',source,code))
        records.append((category,jmbg,code))
body=admin.request('/Scanning')[1]
check('Skeniranje · Nepotvrđeni' in body and 'U PRIPREMI' not in body,'Scanning page replaces placeholder')
check('Ukupno za svih šest kategorija' in body,'Overall turnout displayed')
nav=re.search(r'<nav[^>]*aria-label="Glavna navigacija"[^>]*>(.*?)</nav>',body,re.S).group(1)
check(nav.index('Generisanje vreća')<nav.index('Prijem pošiljki')<nav.index('Prijem i verifikacija')<nav.index('Skeniranje')<nav.index('Administracija'),'Menu follows agreed order')
check(nav.index('Biračka mjesta')>nav.index('Administracija') and nav.index('Razlozi odbijanja')>nav.index('Administracija'),'Maintenance is under administration')
check(admin.request('/Scanning?category=99')[0]==400,'Invalid category rejected')
for action in ['Start','Scan/1','Finish/1']:
    check(admin.request('/Scanning/'+action,{})[0]==400,action+' requires CSRF')
for role,suffix in [('TRK_Pregled','viewer'),('TRK_Skeniranje','scanner')]:
    name='scan.'+suffix+'.'+tag.lower()
    result=admin.post('/Users/Create',{'UserName':name,'DisplayName':'Test '+suffix,'Email':name+'@example.invalid','Password':PASSWORD,'Role':role},'/Users/Create')
    client=Client();check('/Account/Login' not in client.login(name)[2],suffix+' login')
    check(client.request('/Scanning')[0]==200,suffix+' can read')
    if suffix=='viewer':
        for action in ['Start','Scan/1','Finish/1']:
            result=client.post('/Scanning/'+action,{'category':'Nepotvrdjeni','code':records[0][2]})
            check(result[0]==403 or '/Account/Denied' in result[2],'Viewer cannot '+action)
    else: scanner=client
for category,jmbg,code in records:
    result=scanner.post('/Scanning/Start',{'category':category,'code':code})
    check('/Scanning/Details/' in result[2] and result[0]==200,'Start '+category)
    path=urllib.parse.urlsplit(result[2]).path; ident=path.rsplit('/',1)[1]
    with sqlite3.connect(os.environ['TRACKING_TEST_DB']) as db:
        check(db.execute('SELECT COUNT(*) FROM VotesCast vc JOIN Voters v ON v.Id=vc.VoterId WHERE v.Jmbg=?',(jmbg,)).fetchone()[0]==0,'No preloading '+category)
    result=scanner.post('/Scanning/Scan/'+ident,{'jmbg':jmbg},path)
    check(result[0]==200 and 'Birač je uspješno evidentiran.' in result[1],'HTTP scan '+category)
    check(jmbg not in result[1] and jmbg not in result[2],'JMBG masked and absent from URL '+category)
    check('autofocus' in result[1] and 'data-scan-form' in result[1],'Scanner ready for next entry '+category)
    result=scanner.post('/Scanning/Scan/'+ident,{'jmbg':jmbg},path)
    check('Birač je već evidentiran' in result[1],'Duplicate message '+category)
    result=scanner.post('/Scanning/Finish/'+ident,{},path)
    check('Skeniranje je završeno' in result[1] and 'name="jmbg"' not in result[1],'Finish hides entry '+category)
    result=scanner.post('/Scanning/Scan/'+ident,{'jmbg':jmbg},path)
    check('Novi unosi nisu dozvoljeni' in result[1],'Closed session rejects forged post '+category)
    with sqlite3.connect(os.environ['TRACKING_TEST_DB']) as db:
        check(db.execute('SELECT COUNT(*) FROM VotesCast vc JOIN Voters v ON v.Id=vc.VoterId WHERE v.Jmbg=?',(jmbg,)).fetchone()[0]==1,'Exactly one persisted vote '+category)
check(scanner.request('/Intake/Create')[0]==403 or '/Account/Denied' in scanner.request('/Intake/Create')[2],'Scanner role cannot create intake')
print(str(checks)+' scanning HTTP checks passed')
