"""Run only against a disposable preview database; creates sample receipts and reasons."""
import os, re, urllib.request, urllib.parse, urllib.error, http.cookiejar, html, uuid
BASE=os.environ.get('TRACKING_TEST_URL','http://localhost:5181')
checks=0
class Client:
    def __init__(self): self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(self,path,data=None):
        try:
            r=self.opener.open(BASE+path,urllib.parse.urlencode(data,doseq=True).encode() if data is not None else None)
            return r.status,html.unescape(r.read().decode()),r.url
        except urllib.error.HTTPError as e: return e.code,html.unescape(e.read().decode()),e.url
    def post(self,path,data,form):
        status,body,_=self.request(form)
        token=re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"',body).group(1)
        return self.request(path,dict(data,__RequestVerificationToken=token))
    def login(self,user,password):return self.post('/Account/Login',{'UserName':user,'Password':password},'/Account/Login')
def field(body,name):
    return re.search(r'name="'+re.escape(name)+r'"[^>]*value="([^"]*)"',body).group(1)
def check(ok,name):
    global checks
    assert ok,name
    checks+=1;print('PASS',name)
admin=Client();anonymous=Client();password=os.environ['TRACKING_TEST_PASSWORD']
check('/Account/Login' in anonymous.request('/Workflow')[2],'Anonymous workflow requires login')
check(admin.login(os.environ['TRACKING_TEST_USER'],password)[0]==200,'Admin login')
for path in ['/Workflow','/RejectionReasons','/Intake/Direct?group=Odsustvo']:
    check(admin.request(path)[0]==200,'Renders '+path)
check(admin.request('/Workflow?stage=99')[0]==400,'Invalid stage rejected')
check(admin.request('/Intake/Direct?group=Posta')[0]==400,'Postal direct intake forbidden')
for action in ['Count','Prepare','Receive','Return']:
    check(admin.request('/Workflow/'+action+'/1',{})[0]==400,action+' requires CSRF')
for suffix,role in [('receiver','TRK_Prijem'),('viewer','TRK_Pregled')]:
    username='workflow.test.'+suffix
    admin.post('/Users/Create',{'UserName':username,'DisplayName':'Workflow Test','Email':username+'@example.invalid','Password':password,'Role':role},'/Users/Create')
    client=Client();check('/Account/Login' not in client.login(username,password)[2],suffix+' login')
    check(client.request('/Workflow')[0]==200,suffix+' workflow read access')
    for path in ['/RejectionReasons/Edit','/Workflow/Return/1','/Intake/EditReceipt/1','/Intake/EditMaterial/1']:
        result=client.post(path,{},'/Account/Password');check(result[0]==403 or '/Account/Denied' in result[2],suffix+' cannot modify '+path)
    if suffix=='viewer':
        for action in ['Count','Prepare','Receive']:
            result=client.post('/Workflow/'+action+'/1',{},'/Account/Password');check(result[0]==403 or '/Account/Denied' in result[2],'Viewer cannot '+action)
# Follow the rendered forms so route/model-binding and status transitions are exercised together.
admin.post('/BagRegistry/Generate',{'Group':'Odsustvo','Quantity':1},'/BagRegistry')
_,body,_=admin.request('/Intake/Direct?group=Odsustvo')
code=re.search(r'<datalist id="direct-bags">\s*<option value="([^"]+)"',body).group(1)
import datetime
result=admin.post('/Intake/Direct',{'Group':'Odsustvo','Barcode':code,'TotalEnvelopes':10,'ReceivedDate':str(datetime.date.today())},'/Intake/Direct?group=Odsustvo')
check('/Intake/Details/' in result[2],'Direct receipt opens review')
intake_path=urllib.parse.urlsplit(result[2]).path;shipment_id=intake_path.rsplit('/',1)[1]
result=admin.post('/Intake/Close/'+shipment_id,{'version':field(result[1],'version')},intake_path)
check('Prijem završen' in result[1],'Direct intake closes')
bag_id=re.search(r'href="/Workflow/Details/(\d+)"',result[1]).group(1);path='/Workflow/Details/'+bag_id
_,body,_=admin.request(path)
version=field(body,'Count.Version')
invalid=admin.post('/Workflow/Count/'+bag_id,{'Count.Version':version,'Count.Counted':'abc'},path)
check('action="/Workflow/Count/' in invalid[1] and 'action="/Workflow/Prepare/' not in invalid[1],'Malformed count cannot advance')
result=admin.post('/Workflow/Count/'+bag_id,{'Count.Version':version,'Count.Counted':11},path)
check('Ponovite brojanje' in result[1],'Mismatch displayed without advancing')
result=admin.post('/Workflow/Count/'+bag_id,{'Count.Version':version,'Count.Counted':11,'Count.ConfirmDifference':'true','Count.DifferenceReason':'Ponovno prebrojano'},path)
check('action="/Workflow/Prepare/' in result[1],'Count advances to preparation')
reason_name='Provjera '+uuid.uuid4().hex[:8]
admin.post('/RejectionReasons/Edit',{'Name':reason_name,'Group':'Odsustvo','IsActive':'true'},'/RejectionReasons/Edit')
_,body,_=admin.request(path);version=field(body,'Preparation.Version')
rows=re.findall(r'name="Preparation.Reasons\[(\d+)\].ReasonId"[^>]*value="(\d+)"',body)
payload={'Preparation.Version':version,'Preparation.Approved':10,'Preparation.Rejected':1}
for index,reason_id in rows:
    payload['Preparation.Reasons['+index+'].ReasonId']=reason_id
    payload['Preparation.Reasons['+index+'].Quantity']=1 if index==rows[0][0] else 0
result=admin.post('/Workflow/Prepare/'+bag_id,payload,path)
check('action="/Workflow/Receive/' in result[1],'Preparation advances to verification intake')
version=field(result[1],'Verification.Version')
result=admin.post('/Workflow/Receive/'+bag_id,{'Verification.Version':version,'Verification.Received':9},path)
check('Provjerite unos ili vratite' in result[1],'Verification mismatch stays in prepared stage')
result=admin.post('/Workflow/Receive/'+bag_id,{'Verification.Version':version,'Verification.Received':10},path)
check('Primljena na verifikaciju' in result[1] and 'action="/Workflow/Receive/' not in result[1],'Verification receipt completed')
version=field(result[1],'Verification.Version')
result=admin.post('/Workflow/Return/'+bag_id,{'Verification.Version':version,'Verification.Comment':'Ponoviti pripremu'},path)
check('action="/Workflow/Count/' in result[1] and 'Ponoviti pripremu' in result[1],'Supervisor return keeps history and restarts count')
print(str(checks)+' workflow HTTP checks passed; sample bag '+code+' at '+BASE+path)
