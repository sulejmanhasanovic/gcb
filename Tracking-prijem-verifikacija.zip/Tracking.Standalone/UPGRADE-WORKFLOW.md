# Nadogradnja obrade vreća

Detaljne upute i konekcija za Visual Studio su u README.md.

- Postojeća baza iz prve etape: backup, skripte 02 → 03 → 04.
- Već instaliran registar s biračkim mjestima: backup, samo 04.
- Nova baza: 01 → 02 → 03 → 04, zatim inicijalizacija administratora.
- Zadržite postojeću konekciju i korisnika; nemojte kreirati drugu bazu.

Skripta 04 čuva postojeće prijeme, prenosi stavke i uvodi kontrolno brojanje, pripremu, razloge odbijanja i prijem na verifikaciju. Prije produkcije provjerite nadogradnju na kopiji SQL Server baze. Živa SQL Server instanca nije bila dostupna za izvršavanje skripti u razvojnom okruženju.
