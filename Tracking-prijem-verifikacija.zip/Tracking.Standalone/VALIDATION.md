# Validation — 2026-09-24

- .NET 10 Release build passed, zero errors; NU1900: NuGet vulnerability metadata unavailable due to network.
- ProviderChecks: 147 checks passed. Covers SQLite upgrade from the original schema with an existing receipt, provider-isolated migrations, model/snapshot consistency, SQL Server DDL, station import, bag generation/deletion, all five processing flows, mismatch and reason checks, history preservation, actual competing-context saves, postal aggregation/corrections/materials and direct intake.
- registry_http_checks.py: 16 checks passed.
- workflow_http_checks.py: 35 checks passed, including role enforcement, CSRF, direct receipt and full count/preparation/verification/return form submissions.
- postal_http_checks.py: 14 checks passed, including repeated postal entries, corrections, material totals and the complete workflow.
- Total: 212 automated checks. HTTP tests create data; run only on a disposable preview database. Configure TRACKING_TEST_URL, TRACKING_TEST_USER and TRACKING_TEST_PASSWORD. ProviderChecks uses an in-memory database and accepts the polling-stations.json path as its first argument.
- Browser visual QA: preparation, historical counts, completed postal receipt and its per-pretinac rows.
- SQL Server DDL and idempotent migration script generated and reviewed. No live SQL Server execution was performed. Test SQL upgrades on a backup of the target database before operational use.
- Package excludes databases, keys, preview accounts/passwords, bin/obj and personal filesystem paths.
