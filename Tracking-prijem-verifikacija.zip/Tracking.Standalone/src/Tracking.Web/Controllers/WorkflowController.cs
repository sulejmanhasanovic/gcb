using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;
namespace Tracking.Web.Controllers;
[Authorize(Policy = Permissions.View)]
public class WorkflowController(TrackingDbContext db, WorkflowService workflow, UserManager<AppUser> users) : Controller {
    public async Task<IActionResult> Index(IntakeGroup? group, BagStage? stage, string? search, int page = 1) {
        if (!ModelState.IsValid || group.HasValue && !Enum.IsDefined(group.Value) || stage.HasValue && !Enum.IsDefined(stage.Value)) return BadRequest();
        page = Math.Clamp(page,1,100000); search = search?.Trim();
        var q = db.Bags.AsNoTracking().Where(x => x.Shipment.Status == IntakeStatus.Closed);
        if (group.HasValue) q = q.Where(x => x.Shipment.Group == group);
        if (stage.HasValue) q = q.Where(x => x.Stage == stage);
        if (!string.IsNullOrWhiteSpace(search)) { var normalized = IntakeService.Normalize(search); q = q.Where(x => x.Barcode.Contains(normalized) || x.Shipment.Reference.Contains(normalized)); }
        return View(new WorkflowList { Group = group, Stage = stage, Search = search, Page = page, Total = await q.CountAsync(), Bags = await q.Include(x => x.Shipment).OrderBy(x => x.Stage).ThenBy(x => x.Barcode).Skip((page-1)*25).Take(25).ToListAsync() });
    }
    public async Task<IActionResult> Details(int id) { var m = await Model(id); return m == null ? NotFound() : View(m); }
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> Count(int id, [Bind(Prefix="Count")] CountInput input) {
        if (ModelState.IsValid) try { await workflow.CountAsync(id,input,(await users.GetUserAsync(User))!); TempData["Success"]="Kontrolno brojanje je sačuvano. Unesite prihvaćene i odbijene koverte."; return RedirectToAction(nameof(Details),new{id}); } catch(IntakeException e) { ModelState.AddModelError("",e.Message); }
        db.ChangeTracker.Clear(); var m=await Model(id); if(m==null)return NotFound(); m.Count=input; return View("Details",m);
    }
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> Prepare(int id, [Bind(Prefix="Preparation")] PreparationInput input) {
        if (ModelState.IsValid) try { await workflow.PrepareAsync(id,input,(await users.GetUserAsync(User))!); TempData["Success"]="Vreća je spremna za prijem na verifikaciju."; return RedirectToAction(nameof(Details),new{id}); } catch(IntakeException e) { ModelState.AddModelError("",e.Message); }
        db.ChangeTracker.Clear(); var m=await Model(id); if(m==null)return NotFound();
        // Rebuild server-owned reason IDs so a stale/tampered form cannot relabel quantities.
        var old=input.Reasons ?? []; input.Reasons=m.Reasons.Select(r=>old.FirstOrDefault(x=>x.ReasonId==r.Id) ?? new RejectionInput{ReasonId=r.Id}).ToList();
        var errors=ModelState.Values.SelectMany(x=>x.Errors).Select(x=>string.IsNullOrWhiteSpace(x.ErrorMessage)?"Neispravan unos. Provjerite količine.":x.ErrorMessage).ToList();
        ModelState.Clear();foreach(var error in errors)ModelState.AddModelError("",error);
        m.Preparation=input; return View("Details",m);
    }
    [HttpPost, Authorize(Policy = Permissions.Receive)]
    public async Task<IActionResult> Receive(int id, [Bind(Prefix="Verification")] VerificationInput input) {
        if (ModelState.IsValid) try { await workflow.ReceiveAsync(id,input,(await users.GetUserAsync(User))!); TempData["Success"]="Vreća je primljena na verifikaciju."; return RedirectToAction(nameof(Details),new{id}); } catch(IntakeException e) { ModelState.AddModelError("",e.Message); }
        db.ChangeTracker.Clear(); var m=await Model(id); if(m==null)return NotFound(); m.Verification=input; return View("Details",m);
    }
    [HttpPost, Authorize(Policy = Permissions.Correct)]
    public async Task<IActionResult> Return(int id, [Bind(Prefix="Verification")] VerificationInput input) {
        if(!ModelState.IsValid)return BadRequest();
        try { await workflow.ReturnAsync(id,input,(await users.GetUserAsync(User))!); TempData["Success"]="Vreća je vraćena na kontrolno brojanje. Prethodni podaci su sačuvani u historiji."; } catch(IntakeException e) { TempData["Error"]=e.Message; }
        return RedirectToAction(nameof(Details),new{id});
    }
    private async Task<WorkflowDetails?> Model(int id) {
        var b=await db.Bags.AsNoTracking().Include(x=>x.Shipment).SingleOrDefaultAsync(x=>x.Id==id); if(b==null)return null;
        var reasons=await db.RejectionReasons.AsNoTracking().Where(x=>x.IsActive && x.Group==b.Shipment.Group).OrderBy(x=>x.Name).ToListAsync();
        return new WorkflowDetails { Bag=b, Reasons=reasons, Count=new(){Version=b.Version}, Preparation=new(){Version=b.Version,Reasons=reasons.Select(x=>new RejectionInput{ReasonId=x.Id}).ToList()}, Verification=new(){Version=b.Version}, Rejections=await db.BagRejections.AsNoTracking().Where(x=>x.BagId==id && x.RunId==b.RunId).ToListAsync(), History=await db.AuditEntries.AsNoTracking().Where(x=>x.BagId==id).OrderByDescending(x=>x.Id).ToListAsync() };
    }
}
