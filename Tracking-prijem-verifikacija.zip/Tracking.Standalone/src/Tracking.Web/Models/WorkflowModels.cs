using System.ComponentModel.DataAnnotations;
using System.Text.Json;
namespace Tracking.Web.Models;

public enum BagStage { Received = 1, Counted = 2, Prepared = 3, Verification = 4 }
public static class WorkflowLabels {
    public static string Stage(BagStage stage) => stage switch { BagStage.Received => "Čeka kontrolno brojanje", BagStage.Counted => "Priprema za verifikaciju", BagStage.Prepared => "Spremna za verifikaciju", BagStage.Verification => "Primljena na verifikaciju", _ => "—" };
    public static string AuditData(string? json) {
        if(string.IsNullOrWhiteSpace(json))return "—";
        try {
            using var doc=JsonDocument.Parse(json);var root=doc.RootElement;var bag=root.TryGetProperty("Bag",out var nested)?nested:root;var parts=new List<string>();
            if(bag.TryGetProperty("Stage",out var stage))parts.Add(Stage((BagStage)stage.GetInt32()));
            foreach(var (key,label) in new[]{("TotalEnvelopes","Prijem"),("CountedEnvelopes","Prebrojano"),("ApprovedEnvelopes","Prihvaćeno"),("RejectedEnvelopes","Odbijeno"),("VerificationReceived","Verifikacija")})
                if(bag.TryGetProperty(key,out var value)&&value.ValueKind!=JsonValueKind.Null)parts.Add(label+": "+value);
            foreach(var key in new[]{"DifferenceReason","PreparationComment","VerificationComment"})if(bag.TryGetProperty(key,out var value)&&value.ValueKind==JsonValueKind.String&&!string.IsNullOrWhiteSpace(value.GetString()))parts.Add(value.GetString()!);
            if(root.TryGetProperty("Rejections",out var reasons)&&reasons.ValueKind==JsonValueKind.Array)foreach(var r in reasons.EnumerateArray())parts.Add(r.GetProperty("ReasonName").GetString()+": "+r.GetProperty("Quantity")+(r.TryGetProperty("Comment",out var c)&&c.ValueKind==JsonValueKind.String?" ("+c.GetString()+")":""));
            return string.Join(" · ",parts);
        }catch(JsonException){return "Zapis promjene je sačuvan.";}
    }
}
public class RejectionReason {
    public int Id { get; set; }
    [MaxLength(200)] public string Name { get; set; } = "";
    [MaxLength(200)] public string NormalizedName { get; set; } = "";
    public IntakeGroup Group { get; set; }
    public bool IsActive { get; set; } = true;
    public Guid Version { get; set; } = Guid.NewGuid();
}
public class BagRejection {
    public int Id { get; set; }
    public int BagId { get; set; }
    public Bag Bag { get; set; } = null!;
    public Guid RunId { get; set; }
    public int RejectionReasonId { get; set; }
    public RejectionReason RejectionReason { get; set; } = null!;
    [MaxLength(200)] public string ReasonName { get; set; } = "";
    public int Quantity { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
}
public class BagReceiptEntry {
    public int Id { get; set; }
    public int BagId { get; set; }
    public Bag Bag { get; set; } = null!;
    public int RegularEnvelopes { get; set; }
    public int ExpressEnvelopes { get; set; }
    public int TotalEnvelopes { get; set; }
    [MaxLength(20)] public string? PoBox { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
public class MaterialReceipt {
    public int Id { get; set; }
    public int ShipmentId { get; set; }
    public Shipment Shipment { get; set; } = null!;
    public bool IsUndelivered { get; set; }
    public int Quantity { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
public class ReasonInput {
    public int Id { get; set; }
    public Guid Version { get; set; }
    [Required, StringLength(200), Display(Name = "Naziv razloga")] public string Name { get; set; } = "";
    [EnumDataType(typeof(IntakeGroup)), Display(Name = "Kategorija")] public IntakeGroup Group { get; set; } = IntakeGroup.Posta;
    [Display(Name = "Aktivan")] public bool IsActive { get; set; } = true;
}
public class CountInput {
    public Guid Version { get; set; }
    [Range(0,1000000), Display(Name = "Broj koverata utvrđen kontrolnim brojanjem")] public int Counted { get; set; }
    [Display(Name = "Ponovnim brojanjem potvrđujem razliku")] public bool ConfirmDifference { get; set; }
    [StringLength(1000), Display(Name = "Obrazloženje razlike")] public string? DifferenceReason { get; set; }
}
public class RejectionInput {
    public int ReasonId { get; set; }
    [Range(0,1000000)] public int Quantity { get; set; }
    [StringLength(1000)] public string? Comment { get; set; }
}
public class PreparationInput {
    public Guid Version { get; set; }
    [Range(0,1000000), Display(Name = "Prihvaćene koverte prije verifikacije")] public int Approved { get; set; }
    [Range(0,1000000), Display(Name = "Odbijene koverte prije verifikacije")] public int Rejected { get; set; }
    [StringLength(1000), Display(Name = "Napomena")] public string? Comment { get; set; }
    public List<RejectionInput> Reasons { get; set; } = [];
}
public class VerificationInput {
    public Guid Version { get; set; }
    [Range(0,1000000), Display(Name = "Broj preuzetih koverata")] public int Received { get; set; }
    [StringLength(1000), Display(Name = "Napomena / razlog vraćanja")] public string? Comment { get; set; }
}
public class MaterialInput {
    public Guid Version { get; set; }
    public int EntryId { get; set; }
    [Display(Name = "Vrsta materijala")] public bool IsUndelivered { get; set; }
    [Range(1,1000000), Display(Name = "Količina")] public int Quantity { get; set; }
    [StringLength(1000), Display(Name = "Napomena")] public string? Comment { get; set; }
    [StringLength(1000), Display(Name = "Razlog ispravke")] public string? Reason { get; set; }
}
public class ReceiptEditInput : BagInput {
    public int EntryId { get; set; }
    [Required, StringLength(1000), Display(Name = "Razlog ispravke")] public string Reason { get; set; } = "";
}
public class WorkflowDetails {
    public Bag Bag { get; set; } = null!;
    public CountInput Count { get; set; } = new();
    public PreparationInput Preparation { get; set; } = new();
    public VerificationInput Verification { get; set; } = new();
    public List<RejectionReason> Reasons { get; set; } = [];
    public List<BagRejection> Rejections { get; set; } = [];
    public List<AuditEntry> History { get; set; } = [];
}
public class WorkflowList {
    public List<Bag> Bags { get; set; } = [];
    public IntakeGroup? Group { get; set; }
    public BagStage? Stage { get; set; }
    public string? Search { get; set; }
    public int Page { get; set; }
    public int Total { get; set; }
}
public class DirectReceiptInput : IValidatableObject {
    [EnumDataType(typeof(IntakeGroup)), Display(Name="Kategorija")] public IntakeGroup Group { get; set; }=IntakeGroup.Odsustvo;
    [Required,StringLength(40),Display(Name="Broj vreće")] public string Barcode { get; set; }="";
    [Range(1,1000000),Display(Name="Broj primljenih koverata")] public int TotalEnvelopes { get; set; }
    [DataType(DataType.Date),Display(Name="Datum prijema")] public DateOnly ReceivedDate { get; set; }=DateOnly.FromDateTime(DateTime.Today);
    [StringLength(1000),Display(Name="Napomena")] public string? Comment { get; set; }
    public IEnumerable<ValidationResult> Validate(ValidationContext context) {
        if(Group==IntakeGroup.Posta)yield return new("Za Poštu otvorite grupnu pošiljku.");
        if(ReceivedDate<new DateOnly(2000,1,1)||ReceivedDate>DateOnly.FromDateTime(DateTime.Today))yield return new("Neispravan datum prijema.");
    }
}
