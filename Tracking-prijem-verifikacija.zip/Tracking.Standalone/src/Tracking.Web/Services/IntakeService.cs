using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;
public class IntakeException(string message) : Exception(message);
public class IntakeService(TrackingDbContext db)
{
    public static string Normalize(string value) => value.Trim().ToUpperInvariant();
    public async Task<int> DirectReceiptAsync(DirectReceiptInput input,AppUser actor) {
        Validate(input);var code=Normalize(input.Barcode);
        var generated=await db.GeneratedBags.Include(x=>x.PollingStation).SingleOrDefaultAsync(x=>x.Barcode==code)??throw new IntakeException("Prvo generišite vreću za biračko mjesto.");
        if(generated.Group!=input.Group||generated.PollingStation?.IsActive!=true)throw new IntakeException("Vreća ne pripada odabranoj kategoriji ili mjesto nije aktivno.");
        if(await db.Bags.AnyAsync(x=>x.Barcode==code))throw new IntakeException("Ova vreća je već zaprimljena.");
        var s=new Shipment{Reference="PR-"+Guid.NewGuid().ToString("N")[..20].ToUpperInvariant(),Group=input.Group,ReceivedDate=input.ReceivedDate,ExpectedEnvelopes=input.TotalEnvelopes,CreatedById=actor.Id,Comment=input.Comment?.Trim()};
        var bag=new Bag{Barcode=code,GeneratedBagId=generated.Id,PollingStationCode=generated.PollingStation.Code,TotalEnvelopes=input.TotalEnvelopes,Comment=input.Comment?.Trim(),CreatedById=actor.Id};
        bag.Entries.Add(new(){TotalEnvelopes=input.TotalEnvelopes,Comment=input.Comment?.Trim(),CreatedById=actor.Id});s.Bags.Add(bag);
        await using var tx=await db.Database.BeginTransactionAsync();db.Shipments.Add(s);await SaveAsync();
        Audit(s.Id,actor,"Direktan prijem vreće",null,new{s.Reference,bag.Barcode,bag.TotalEnvelopes,s.ReceivedDate},null);await SaveAsync();await tx.CommitAsync();return s.Id;
    }
    public async Task<int> CreateAsync(ShipmentInput input, AppUser actor)
    {
        Validate(input);
        var reference = Normalize(input.Reference);
        if (await db.Shipments.AnyAsync(x => x.Reference == reference)) throw new IntakeException("Pošiljka s ovom oznakom već postoji.");
        var s = new Shipment { Reference = reference, Group = input.Group, ReceivedDate = input.ReceivedDate,
            ExpectedEnvelopes = input.ExpectedEnvelopes, Undelivered = input.Undelivered, OtherMaterials = input.OtherMaterials,
            Comment = input.Comment?.Trim(), CreatedById = actor.Id };
        await using var tx = await db.Database.BeginTransactionAsync();
        db.Shipments.Add(s); await SaveAsync();
        Audit(s.Id, actor, "Otvoren prijem", null, Snapshot(s), null);
        await SaveAsync(); await tx.CommitAsync(); return s.Id;
    }
    public async Task AddBagAsync(int id, BagInput input, AppUser actor)
    {
        Validate(input);
        var s = await GetOpenAsync(id, input.Version);
        var barcode = Normalize(input.Barcode);
        var existing = await db.Bags.SingleOrDefaultAsync(x => x.Barcode == barcode);
        if (existing != null && (s.Group != IntakeGroup.Posta || existing.ShipmentId != id || existing.Stage != BagStage.Received)) throw new IntakeException("Ova vreća je već evidentirana. Provjerite barkod i pošiljku.");
        var generated = await db.GeneratedBags.Include(x => x.PollingStation).SingleOrDefaultAsync(x => x.Barcode == barcode)
            ?? throw new IntakeException("Vreća nije generisana. Prvo je dodajte u pregled generisanih vreća.");
        if (generated.Group != s.Group) throw new IntakeException("Vreća ne pripada kategoriji ovog prijema.");
        if (generated.PollingStation is { IsActive: false }) throw new IntakeException("Biračko mjesto nije aktivno.");
        var total = input.TotalEnvelopes;
        if (s.Group == IntakeGroup.Posta) total = checked(input.RegularEnvelopes + input.ExpressEnvelopes);
        else if (input.RegularEnvelopes != 0 || input.ExpressEnvelopes != 0 || !string.IsNullOrWhiteSpace(input.PoBox))
            throw new IntakeException("Poštanska polja se koriste samo za grupu Pošta.");
        if (total <= 0 || total > 1000000) throw new IntakeException("Broj koverata mora biti između 1 i 1.000.000.");
        if ((long)s.Bags.Sum(x => x.TotalEnvelopes) + total > s.ExpectedEnvelopes)
            throw new IntakeException("Broj koverata prelazi najavljenu količinu. Supervizor prvo treba ispraviti podatke pošiljke.");
        var bag = existing ?? new Bag { ShipmentId = id, Barcode = barcode, GeneratedBagId = generated.Id, PollingStationCode = generated.PollingStation?.Code,
            PoBox = input.PoBox?.Trim(), RegularEnvelopes = input.RegularEnvelopes, ExpressEnvelopes = input.ExpressEnvelopes,
            TotalEnvelopes = total, Comment = input.Comment?.Trim(), CreatedById = actor.Id };
        if (existing == null) db.Bags.Add(bag);
        else { bag.TotalEnvelopes += total; bag.RegularEnvelopes += input.RegularEnvelopes; bag.ExpressEnvelopes += input.ExpressEnvelopes; bag.Version = Guid.NewGuid(); }
        bag.Entries.Add(new BagReceiptEntry { RegularEnvelopes = input.RegularEnvelopes, ExpressEnvelopes = input.ExpressEnvelopes, TotalEnvelopes = total, PoBox = input.PoBox?.Trim(), Comment = input.Comment?.Trim(), CreatedById = actor.Id });
        s.Version = Guid.NewGuid();
        Audit(id, actor, existing == null ? "Primljena vreća" : "Dopunjena poštanska vreća", null, new { bag.Barcode, bag.TotalEnvelopes, bag.RegularEnvelopes, bag.ExpressEnvelopes, bag.PollingStationCode, Unos = new { TotalEnvelopes = total, input.RegularEnvelopes, input.ExpressEnvelopes, input.PoBox, input.Comment } }, null);
        await SaveAsync();
    }
    public async Task CloseAsync(int id, Guid version, AppUser actor)
    {
        var s = await GetOpenAsync(id, version);
        if (s.Bags.Sum(x => x.TotalEnvelopes) != s.ExpectedEnvelopes)
            throw new IntakeException("Prijem se može završiti tek kada se najavljena i primljena količina koverata podudaraju.");
        if (s.Materials.Where(x => x.IsUndelivered).Sum(x => x.Quantity) != s.Undelivered || s.Materials.Where(x => !x.IsUndelivered).Sum(x => x.Quantity) != s.OtherMaterials)
            throw new IntakeException("Evidentirajte sve najavljene neuručene pošiljke i ostale materijale prije završetka prijema.");
        var before = Snapshot(s); s.Status = IntakeStatus.Closed; s.ClosedAtUtc = DateTime.UtcNow; s.Version = Guid.NewGuid();
        Audit(id, actor, "Završen prijem", before, Snapshot(s), null); await SaveAsync();
    }
    public async Task EditAsync(int id, ShipmentInput input, AppUser actor)
    {
        Validate(input);
        if (string.IsNullOrWhiteSpace(input.Reason)) throw new IntakeException("Razlog ispravke je obavezan.");
        var s = await GetOpenAsync(id, input.Version);
        if (s.Group != input.Group) throw new IntakeException("Grupa prijema se ne može mijenjati.");
        var reference = Normalize(input.Reference);
        if (await db.Shipments.AnyAsync(x => x.Reference == reference && x.Id != id)) throw new IntakeException("Ova oznaka pošiljke već postoji.");
        if (input.ExpectedEnvelopes < s.Bags.Sum(x => x.TotalEnvelopes)) throw new IntakeException("Najavljena količina ne može biti manja od već primljenih koverata.");
        if (input.Undelivered < s.Materials.Where(x => x.IsUndelivered).Sum(x => x.Quantity) || input.OtherMaterials < s.Materials.Where(x => !x.IsUndelivered).Sum(x => x.Quantity)) throw new IntakeException("Najava materijala ne može biti manja od već evidentirane količine.");
        var before = Snapshot(s);
        s.Reference = reference; s.ReceivedDate = input.ReceivedDate; s.ExpectedEnvelopes = input.ExpectedEnvelopes;
        s.Undelivered = input.Undelivered; s.OtherMaterials = input.OtherMaterials; s.Comment = input.Comment?.Trim(); s.Version = Guid.NewGuid();
        Audit(id, actor, "Ispravljeni podaci pošiljke", before, Snapshot(s), input.Reason.Trim()); await SaveAsync();
    }
    private async Task<Shipment> GetOpenAsync(int id, Guid version)
    {
        var s = await db.Shipments.Include(x => x.Bags).Include(x => x.Materials).SingleOrDefaultAsync(x => x.Id == id) ?? throw new IntakeException("Pošiljka nije pronađena.");
        if (s.Status != IntakeStatus.Open) throw new IntakeException("Prijem je završen. Izmjene više nisu dozvoljene.");
        if (version == Guid.Empty || s.Version != version) throw new IntakeException("Drugi operater je izmijenio podatke. Osvježite stranicu prije nastavka.");
        return s;
    }
    public async Task EditReceiptAsync(int id, ReceiptEditInput input, AppUser actor) {
        Validate(input);
        if (string.IsNullOrWhiteSpace(input.Reason)) throw new IntakeException("Razlog ispravke je obavezan.");
        var s = await GetOpenAsync(id, input.Version);
        var entry = await db.BagReceiptEntries.Include(x => x.Bag).SingleOrDefaultAsync(x => x.Id == input.EntryId && x.Bag.ShipmentId == id) ?? throw new IntakeException("Unos vreće nije pronađen.");
        var total = s.Group == IntakeGroup.Posta ? checked(input.RegularEnvelopes + input.ExpressEnvelopes) : input.TotalEnvelopes;
        if (s.Group != IntakeGroup.Posta && (input.RegularEnvelopes != 0 || input.ExpressEnvelopes != 0 || !string.IsNullOrWhiteSpace(input.PoBox))) throw new IntakeException("Poštanska polja se koriste samo za Poštu.");
        if (total < 1 || total > 1000000 || (long)s.Bags.Sum(x => x.TotalEnvelopes) - entry.TotalEnvelopes + total > s.ExpectedEnvelopes) throw new IntakeException("Količina mora biti pozitivna i ne smije prelaziti najavu pošiljke.");
        var before = new { entry.Id, entry.Bag.Barcode, entry.RegularEnvelopes, entry.ExpressEnvelopes, entry.TotalEnvelopes, entry.PoBox, entry.Comment };
        entry.Bag.TotalEnvelopes += total - entry.TotalEnvelopes;
        entry.Bag.RegularEnvelopes += input.RegularEnvelopes - entry.RegularEnvelopes;
        entry.Bag.ExpressEnvelopes += input.ExpressEnvelopes - entry.ExpressEnvelopes;
        entry.RegularEnvelopes = input.RegularEnvelopes; entry.ExpressEnvelopes = input.ExpressEnvelopes; entry.TotalEnvelopes = total; entry.PoBox = input.PoBox?.Trim(); entry.Comment = input.Comment?.Trim();
        entry.Bag.Version = Guid.NewGuid(); s.Version = Guid.NewGuid();
        Audit(id,actor,"Ispravljen unos vreće",before,new{entry.Id,entry.Bag.Barcode,entry.RegularEnvelopes,entry.ExpressEnvelopes,entry.TotalEnvelopes,entry.PoBox,entry.Comment},input.Reason.Trim());
        await SaveAsync();
    }
    public async Task SaveMaterialAsync(int id, MaterialInput input, AppUser actor) {
        Validate(input); var s = await GetOpenAsync(id,input.Version);
        if(s.Group != IntakeGroup.Posta)throw new IntakeException("Odvojeni materijali se evidentiraju samo za Poštu.");
        MaterialReceipt? entry = null; object? before = null;
        if(input.EntryId != 0) {
            if(string.IsNullOrWhiteSpace(input.Reason))throw new IntakeException("Razlog ispravke je obavezan.");
            entry=s.Materials.SingleOrDefault(x=>x.Id==input.EntryId)??throw new IntakeException("Materijal nije pronađen.");
            if(entry.IsUndelivered!=input.IsUndelivered)throw new IntakeException("Vrstu evidentiranog materijala nije moguće mijenjati.");
            before=new{entry.Id,entry.IsUndelivered,entry.Quantity,entry.Comment};
        }
        var already=s.Materials.Where(x=>x.IsUndelivered==input.IsUndelivered).Sum(x=>(long)x.Quantity);
        if(already-(entry?.Quantity??0)+input.Quantity > (input.IsUndelivered?s.Undelivered:s.OtherMaterials))throw new IntakeException("Količina materijala prelazi najavu. Supervizor može ispraviti podatke pošiljke.");
        if(entry==null){entry=new MaterialReceipt{ShipmentId=id,IsUndelivered=input.IsUndelivered,CreatedById=actor.Id};db.MaterialReceipts.Add(entry);}
        entry.Quantity=input.Quantity;entry.Comment=input.Comment?.Trim();s.Version=Guid.NewGuid();
        Audit(id,actor,input.EntryId==0?"Primljen odvojeni materijal":"Ispravljen odvojeni materijal",before,new{entry.IsUndelivered,entry.Quantity,entry.Comment},input.Reason?.Trim()); await SaveAsync();
    }
    private static object Snapshot(Shipment s) => new { s.Reference, s.Group, s.ReceivedDate, s.ExpectedEnvelopes, s.Undelivered, s.OtherMaterials, s.Comment, s.Status };
    private void Audit(int id, AppUser actor, string action, object? before, object? after, string? reason) => db.AuditEntries.Add(new AuditEntry {
        ShipmentId = id, ActorId = actor.Id, ActorName = actor.DisplayName, Action = action, Reason = reason,
        BeforeJson = before == null ? null : JsonSerializer.Serialize(before), AfterJson = after == null ? null : JsonSerializer.Serialize(after)
    });
    private static void Validate(object value)
    {
        var results = new List<ValidationResult>();
        if (!Validator.TryValidateObject(value, new ValidationContext(value), results, true)) throw new IntakeException(string.Join(" ", results.Select(x => x.ErrorMessage)));
    }
    private async Task SaveAsync()
    {
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateConcurrencyException) { db.ChangeTracker.Clear(); throw new IntakeException("Podatke je izmijenio drugi operater. Osvježite stranicu i pokušajte ponovo."); }
        catch (DbUpdateException e) when (e.InnerException is Microsoft.Data.SqlClient.SqlException { Number: 2601 or 2627 or 547 }) {
            db.ChangeTracker.Clear(); throw new IntakeException("Zapis nije sačuvan: oznaka već postoji ili podaci nisu ispravni.");
        }
        catch (DbUpdateException e) when (e.InnerException is Microsoft.Data.Sqlite.SqliteException { SqliteErrorCode: 19 }) {
            db.ChangeTracker.Clear(); throw new IntakeException("Zapis nije sačuvan: oznaka već postoji ili podaci nisu ispravni.");
        }
    }
}
