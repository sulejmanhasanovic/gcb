import os, re, urllib.request, urllib.parse, urllib.error, http.cookiejar, html
BASE=os.environ.get('TRACKING_TEST_URL','http://localhost:5181')
checks=0
class Client:
    def __init__(self): self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def request(self,path,data=None):
        try:
            r=self.opener.open(BASE+path,urllib.parse.urlencode(data,doseq=True).encode() if data is not None else None)
            return r.status,r.read().decode(),r.url
        except urllib.error.HTTPError as e: return e.code,e.read().decode(),e.url
    def post(self,path,data,form):
        status,body,_=self.request(form)
        token=re.search(r'name="__RequestVerificationToken"[^>]*value="([^"]+)"',body).group(1)
        return self.request(path,dict(data,__RequestVerificationToken=html.unescape(token)))
    def login(self,user,password): return self.post('/Account/Login',{'UserName':user,'Password':password},'/Account/Login')
def check(ok,name):
    global checks
    assert ok,name
    checks+=1;print('PASS',name)
admin=Client(); anonymous=Client()
check('/Account/Login' in anonymous.request('/BagRegistry')[2],'Anonymous registry requires login')
check('/Account/Login' in anonymous.request('/BagRegistry/Stations')[2],'Anonymous stations require login')
check(admin.login(os.environ['TRACKING_TEST_USER'],os.environ['TRACKING_TEST_PASSWORD'])[0]==200,'Admin login')
check(admin.request('/BagRegistry')[0]==200,'Registry renders')
check(admin.request('/BagRegistry/Stations?group=Odsustvo')[0]==200,'Station filter renders')
check(admin.request('/BagRegistry?group=99')[0]==400,'Invalid category rejected')
check(admin.request('/BagRegistry/Generate',{'Group':'Posta','Quantity':1})[0]==400,'Generation requires CSRF token')
check(admin.request('/BagRegistry/Delete',{'ids':[1]})[0]==400,'Deletion requires CSRF token')
for suffix,role in [('receiver','TRK_Prijem'),('viewer','TRK_Pregled')]:
    user='registry.test.'+suffix
    password=os.environ['TRACKING_TEST_PASSWORD']
    result=admin.post('/Users/Create',{'UserName':user,'DisplayName':'Registry Test','Email':user+'@example.invalid','Password':password,'Role':role},'/Users/Create')
    client=Client();check(client.login(user,password)[0]==200,suffix+' login')
    status,body,_=client.request('/BagRegistry')
    check(status==200 and 'action="/BagRegistry/Generate"' not in body,suffix+' can view but has no generation form')
    denied=client.post('/BagRegistry/Generate',{'Group':'Posta','Quantity':1},'/Account/Password')
    check(denied[0]==403 or '/Account/Denied' in denied[2],suffix+' direct generate forbidden')
    denied=client.post('/BagRegistry/Delete',{'ids':[1]},'/Account/Password')
    check(denied[0]==403 or '/Account/Denied' in denied[2],suffix+' direct delete forbidden')
print(str(checks)+' HTTP checks passed')
