param([string]$SqlServer, [string]$Database = 'Tracking', [switch]$TrustServerCertificate, [switch]$Initialize, [int]$Port = 5180)
$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'src/Tracking.Web'
Push-Location $PSScriptRoot
try {
    dotnet restore "$project/Tracking.Web.csproj" --configfile "$PSScriptRoot/NuGet.Config"
    if ($LASTEXITCODE -ne 0) { throw 'NuGet restore nije uspio.' }
    dotnet build "$project/Tracking.Web.csproj" --no-restore -c Release
    if ($LASTEXITCODE -ne 0) { throw 'Build nije uspio.' }
    $env:ASPNETCORE_ENVIRONMENT = 'Development'
    $env:Tracking__DataDirectory = Join-Path $project 'App_Data'
    if ($SqlServer) {
        if ($SqlServer -match ';' -or $Database -match ';') { throw 'Neispravan naziv servera ili baze.' }
        $env:Database__Provider = 'SqlServer'
        $env:ConnectionStrings__Tracking = "Server=$SqlServer;Database=$Database;Integrated Security=True;Encrypt=True;TrustServerCertificate=$($TrustServerCertificate.IsPresent)"
    } elseif ($env:Database__Provider -ne 'SqlServer') { $env:Database__Provider = 'Sqlite' }
    if ($Initialize -or ($env:Database__Provider -eq 'Sqlite' -and -not (Test-Path "$project/App_Data/tracking.db"))) {
        Write-Host 'Prvi administrator: najmanje 12 znakova, veliko i malo slovo, broj i poseban znak.'
        $env:Bootstrap__UserName = Read-Host 'Korisnicko ime'
        $env:Bootstrap__Email = Read-Host 'E-mail'
        $secret = Read-Host 'Lozinka' -AsSecureString
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
        try { $env:Bootstrap__Password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
        try {
            dotnet run --project "$project" -c Release --no-build --no-launch-profile -- --initialize
            if ($LASTEXITCODE -ne 0) { throw 'Inicijalizacija nije uspjela. Provjerite konekciju i pravila lozinke, pa ponovite sa -Initialize.' }
        } finally {
            Remove-Item Env:Bootstrap__Password -ErrorAction SilentlyContinue
            Remove-Item Env:Bootstrap__UserName -ErrorAction SilentlyContinue
            Remove-Item Env:Bootstrap__Email -ErrorAction SilentlyContinue
        }
    }
    Write-Host "Otvorite http://localhost:$Port. Zaustavljanje: Ctrl+C."
    dotnet run --project "$project" -c Release --no-build --no-launch-profile --urls "http://localhost:$Port"
} finally { Pop-Location }
