# Validation — 2026-09-23

- .NET 10 Release build: passed, 0 warnings, 0 errors.
- `dotnet run --project tests/ProviderChecks -c Release`: passed all 10 checks. Confirms provider migration isolation, SQL Server DDL (Identity/business tables, SQL Server identity columns), SQLite migration execution and all three intake flows, stale-version rejection and transactional audit counts.
- SQL Server idempotent migration script generated from `SqlServerTrackingDbContext`; database bootstrap wrapper added for a new `Tracking` database.
- A live SQL Server execution was not possible in this environment: the installed LocalDB instance API returned an unexpected error. SQL Server installation, connection permissions and live receipt/login workflows must be verified on the target SQL Server. No production database was accessed.
- Earlier SQLite stage: 26 domain/database checks and 31 HTTP checks passed; browser login, receipt creation and bag receipt were verified. Those results precede the provider addition and do not constitute live SQL Server validation.
- Publication excludes App_Data, databases, keys, bin/obj, preview credentials and personal filesystem paths.
