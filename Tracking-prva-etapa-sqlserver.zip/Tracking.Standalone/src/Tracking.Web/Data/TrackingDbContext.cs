using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Models;
namespace Tracking.Web.Data;
public class TrackingDbContext : IdentityDbContext<AppUser> {
    public TrackingDbContext(DbContextOptions<TrackingDbContext> options) : base(options) { }
    protected TrackingDbContext(DbContextOptions options) : base(options) { }
    public DbSet<Shipment> Shipments => Set<Shipment>();
    public DbSet<Bag> Bags => Set<Bag>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();
    protected override void OnModelCreating(ModelBuilder b) {
        base.OnModelCreating(b);
        b.Entity<Shipment>().HasIndex(x => x.Reference).IsUnique();
        b.Entity<Shipment>().Property(x => x.Version).IsConcurrencyToken();
        b.Entity<Shipment>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Bag>().HasIndex(x => x.Barcode).IsUnique();
        b.Entity<Bag>().HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Bag>().HasOne(x => x.Shipment).WithMany(x => x.Bags).HasForeignKey(x => x.ShipmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<AuditEntry>().HasIndex(x => new { x.ShipmentId, x.AtUtc });
        b.Entity<Shipment>().ToTable(t => {
            t.HasCheckConstraint("CK_Shipment_Counts", "ExpectedEnvelopes >= 0 AND ExpectedEnvelopes <= 1000000 AND Undelivered >= 0 AND Undelivered <= 1000000 AND OtherMaterials >= 0 AND OtherMaterials <= 1000000");
            t.HasCheckConstraint("CK_Shipment_Group", "\"Group\" IN (1, 2, 3)");
        });
        b.Entity<Bag>().ToTable(t => t.HasCheckConstraint("CK_Bag_Counts", "TotalEnvelopes > 0 AND TotalEnvelopes <= 1000000 AND RegularEnvelopes >= 0 AND ExpressEnvelopes >= 0"));
    }
}
