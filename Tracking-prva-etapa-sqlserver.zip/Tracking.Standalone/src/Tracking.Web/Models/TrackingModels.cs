using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
namespace Tracking.Web.Models;
public class AppUser : IdentityUser { [MaxLength(100)] public string DisplayName { get; set; } = ""; }
public static class Roles {
    public const string Admin = "TRK_Admin", Supervisor = "TRK_Supervizor", Receiver = "TRK_Prijem", Viewer = "TRK_Pregled";
    public static readonly string[] All = [Admin, Supervisor, Receiver, Viewer];
    public static string Label(string role) => role switch { Admin => "Administrator", Supervisor => "Supervizor", Receiver => "Operater prijema", Viewer => "Pregled", _ => role };
}
public static class Permissions { public const string View = "Shipment.View", Receive = "Shipment.Create", Correct = "Shipment.Edit", Users = "Users.Manage"; }
public enum IntakeGroup { [Display(Name = "Pošta")] Posta = 1, [Display(Name = "Mobilni")] Mobilni = 2, [Display(Name = "Nepotvrđeni")] Nepotvrdjeni = 3 }
public enum IntakeStatus { Open = 1, Closed = 2 }
public static class Labels {
    public static string Group(IntakeGroup group) => group switch { IntakeGroup.Posta => "Pošta", IntakeGroup.Mobilni => "Mobilni", IntakeGroup.Nepotvrdjeni => "Nepotvrđeni", _ => "—" };
    public static string Status(IntakeStatus status) => status == IntakeStatus.Closed ? "Prijem završen" : "U prijemu";
}
public class Shipment {
    public int Id { get; set; }
    [MaxLength(40)] public string Reference { get; set; } = "";
    public IntakeGroup Group { get; set; }
    public DateOnly ReceivedDate { get; set; }
    public int ExpectedEnvelopes { get; set; }
    public int Undelivered { get; set; }
    public int OtherMaterials { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
    public IntakeStatus Status { get; set; } = IntakeStatus.Open;
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public AppUser CreatedBy { get; set; } = null!;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? ClosedAtUtc { get; set; }
    public Guid Version { get; set; } = Guid.NewGuid();
    public List<Bag> Bags { get; set; } = [];
}
public class Bag {
    public int Id { get; set; }
    public int ShipmentId { get; set; }
    public Shipment Shipment { get; set; } = null!;
    [MaxLength(40)] public string Barcode { get; set; } = "";
    [MaxLength(10)] public string? PollingStationCode { get; set; }
    [MaxLength(20)] public string? PoBox { get; set; }
    public int RegularEnvelopes { get; set; }
    public int ExpressEnvelopes { get; set; }
    public int TotalEnvelopes { get; set; }
    [MaxLength(1000)] public string? Comment { get; set; }
    [MaxLength(450)] public string CreatedById { get; set; } = "";
    public AppUser CreatedBy { get; set; } = null!;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}
public class AuditEntry {
    public long Id { get; set; }
    public int? ShipmentId { get; set; }
    [MaxLength(450)] public string ActorId { get; set; } = "";
    [MaxLength(100)] public string ActorName { get; set; } = "";
    [MaxLength(80)] public string Action { get; set; } = "";
    public DateTime AtUtc { get; set; } = DateTime.UtcNow;
    [MaxLength(1000)] public string? Reason { get; set; }
    public string? BeforeJson { get; set; }
    public string? AfterJson { get; set; }
}
