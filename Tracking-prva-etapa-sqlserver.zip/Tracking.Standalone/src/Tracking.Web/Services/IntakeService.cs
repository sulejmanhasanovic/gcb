using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
namespace Tracking.Web.Services;
public class IntakeException(string message) : Exception(message);
public class IntakeService(TrackingDbContext db)
{
    public static string Normalize(string value) => value.Trim().ToUpperInvariant();
    public async Task<int> CreateAsync(ShipmentInput input, AppUser actor)
    {
        Validate(input);
        var reference = Normalize(input.Reference);
        if (await db.Shipments.AnyAsync(x => x.Reference == reference)) throw new IntakeException("Pošiljka s ovom oznakom već postoji.");
        var s = new Shipment { Reference = reference, Group = input.Group, ReceivedDate = input.ReceivedDate,
            ExpectedEnvelopes = input.ExpectedEnvelopes, Undelivered = input.Undelivered, OtherMaterials = input.OtherMaterials,
            Comment = input.Comment?.Trim(), CreatedById = actor.Id };
        await using var tx = await db.Database.BeginTransactionAsync();
        db.Shipments.Add(s); await SaveAsync();
        Audit(s.Id, actor, "Otvoren prijem", null, Snapshot(s), null);
        await SaveAsync(); await tx.CommitAsync(); return s.Id;
    }
    public async Task AddBagAsync(int id, BagInput input, AppUser actor)
    {
        Validate(input);
        var s = await GetOpenAsync(id, input.Version);
        var barcode = Normalize(input.Barcode);
        if (await db.Bags.AnyAsync(x => x.Barcode == barcode)) throw new IntakeException("Ova vreća je već evidentirana. Provjerite barkod.");
        var total = input.TotalEnvelopes;
        if (s.Group == IntakeGroup.Posta) total = checked(input.RegularEnvelopes + input.ExpressEnvelopes);
        else if (input.RegularEnvelopes != 0 || input.ExpressEnvelopes != 0 || !string.IsNullOrWhiteSpace(input.PoBox))
            throw new IntakeException("Poštanska polja se koriste samo za grupu Pošta.");
        if (s.Group != IntakeGroup.Posta && string.IsNullOrWhiteSpace(input.PollingStationCode))
            throw new IntakeException("Unesite šifru biračkog mjesta ili mobilnog tima.");
        if (total <= 0 || total > 1000000) throw new IntakeException("Broj koverata mora biti između 1 i 1.000.000.");
        if ((long)s.Bags.Sum(x => x.TotalEnvelopes) + total > s.ExpectedEnvelopes)
            throw new IntakeException("Broj koverata prelazi najavljenu količinu. Supervizor prvo treba ispraviti podatke pošiljke.");
        var bag = new Bag { ShipmentId = id, Barcode = barcode, PollingStationCode = input.PollingStationCode?.Trim(),
            PoBox = input.PoBox?.Trim(), RegularEnvelopes = input.RegularEnvelopes, ExpressEnvelopes = input.ExpressEnvelopes,
            TotalEnvelopes = total, Comment = input.Comment?.Trim(), CreatedById = actor.Id };
        db.Bags.Add(bag); s.Version = Guid.NewGuid();
        Audit(id, actor, "Primljena vreća", null, new { bag.Barcode, bag.TotalEnvelopes, bag.RegularEnvelopes, bag.ExpressEnvelopes, bag.PollingStationCode, bag.PoBox, bag.Comment }, null);
        await SaveAsync();
    }
    public async Task CloseAsync(int id, Guid version, AppUser actor)
    {
        var s = await GetOpenAsync(id, version);
        if (s.Bags.Sum(x => x.TotalEnvelopes) != s.ExpectedEnvelopes)
            throw new IntakeException("Prijem se može završiti tek kada se najavljena i primljena količina koverata podudaraju.");
        var before = Snapshot(s); s.Status = IntakeStatus.Closed; s.ClosedAtUtc = DateTime.UtcNow; s.Version = Guid.NewGuid();
        Audit(id, actor, "Završen prijem", before, Snapshot(s), null); await SaveAsync();
    }
    public async Task EditAsync(int id, ShipmentInput input, AppUser actor)
    {
        Validate(input);
        if (string.IsNullOrWhiteSpace(input.Reason)) throw new IntakeException("Razlog ispravke je obavezan.");
        var s = await GetOpenAsync(id, input.Version);
        if (s.Group != input.Group) throw new IntakeException("Grupa prijema se ne može mijenjati.");
        var reference = Normalize(input.Reference);
        if (await db.Shipments.AnyAsync(x => x.Reference == reference && x.Id != id)) throw new IntakeException("Ova oznaka pošiljke već postoji.");
        if (input.ExpectedEnvelopes < s.Bags.Sum(x => x.TotalEnvelopes)) throw new IntakeException("Najavljena količina ne može biti manja od već primljenih koverata.");
        var before = Snapshot(s);
        s.Reference = reference; s.ReceivedDate = input.ReceivedDate; s.ExpectedEnvelopes = input.ExpectedEnvelopes;
        s.Undelivered = input.Undelivered; s.OtherMaterials = input.OtherMaterials; s.Comment = input.Comment?.Trim(); s.Version = Guid.NewGuid();
        Audit(id, actor, "Ispravljeni podaci pošiljke", before, Snapshot(s), input.Reason.Trim()); await SaveAsync();
    }
    private async Task<Shipment> GetOpenAsync(int id, Guid version)
    {
        var s = await db.Shipments.Include(x => x.Bags).SingleOrDefaultAsync(x => x.Id == id) ?? throw new IntakeException("Pošiljka nije pronađena.");
        if (s.Status != IntakeStatus.Open) throw new IntakeException("Prijem je završen. Izmjene više nisu dozvoljene.");
        if (version == Guid.Empty || s.Version != version) throw new IntakeException("Drugi operater je izmijenio podatke. Osvježite stranicu prije nastavka.");
        return s;
    }
    private static object Snapshot(Shipment s) => new { s.Reference, s.Group, s.ReceivedDate, s.ExpectedEnvelopes, s.Undelivered, s.OtherMaterials, s.Comment, s.Status };
    private void Audit(int id, AppUser actor, string action, object? before, object? after, string? reason) => db.AuditEntries.Add(new AuditEntry {
        ShipmentId = id, ActorId = actor.Id, ActorName = actor.DisplayName, Action = action, Reason = reason,
        BeforeJson = before == null ? null : JsonSerializer.Serialize(before), AfterJson = after == null ? null : JsonSerializer.Serialize(after)
    });
    private static void Validate(object value)
    {
        var results = new List<ValidationResult>();
        if (!Validator.TryValidateObject(value, new ValidationContext(value), results, true)) throw new IntakeException(string.Join(" ", results.Select(x => x.ErrorMessage)));
    }
    private async Task SaveAsync()
    {
        try { await db.SaveChangesAsync(); }
        catch (DbUpdateConcurrencyException) { db.ChangeTracker.Clear(); throw new IntakeException("Podatke je izmijenio drugi operater. Osvježite stranicu i pokušajte ponovo."); }
        catch (DbUpdateException e) when (e.InnerException is Microsoft.Data.SqlClient.SqlException { Number: 2601 or 2627 or 547 }) {
            db.ChangeTracker.Clear(); throw new IntakeException("Zapis nije sačuvan: oznaka već postoji ili podaci nisu ispravni.");
        }
        catch (DbUpdateException e) when (e.InnerException is Microsoft.Data.Sqlite.SqliteException { SqliteErrorCode: 19 }) {
            db.ChangeTracker.Clear(); throw new IntakeException("Zapis nije sačuvan: oznaka već postoji ili podaci nisu ispravni.");
        }
    }
}
