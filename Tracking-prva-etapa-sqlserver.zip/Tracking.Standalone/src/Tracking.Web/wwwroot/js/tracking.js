document.querySelectorAll("[data-group-selector]").forEach(select => {
    const fields = document.querySelector("[data-postal-fields]");
    const update = () => {
        const isPost = select.value === "1";
        fields.hidden = !isPost;
        fields.querySelectorAll("input").forEach(input => { input.disabled = !isPost; });
    };
    select.addEventListener("change", update); update();
});
document.querySelectorAll("[data-barcode]").forEach(input => {
    input.addEventListener("keydown", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            const inputs = Array.from(input.form.querySelectorAll("input:not([type=hidden]),textarea,select"));
            inputs[inputs.indexOf(input) + 1]?.focus();
        }
    });
});
