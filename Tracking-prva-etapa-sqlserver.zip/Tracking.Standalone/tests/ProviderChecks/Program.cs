using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;

void Check(bool ok, string name) { if (!ok) throw new Exception(name); Console.WriteLine("PASS " + name); }
await using var sql = new SqlServerDesignFactory().CreateDbContext([]);
Check(sql.Database.GetMigrations().Count() == 1 && sql.Database.GetMigrations().Single().EndsWith("InitialSqlServer"), "SQL Server migration isolation");
var ddl = sql.Database.GenerateCreateScript();
Check(ddl.Contains("IDENTITY") && ddl.Contains("[AspNetUsers]") && ddl.Contains("[Bags]") && !ddl.Contains("AUTOINCREMENT"), "SQL Server DDL and Identity tables");
var options = new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source=:memory:").Options;
await using var db = new TrackingDbContext(options);
await db.Database.OpenConnectionAsync();
Check(db.Database.GetMigrations().Count() == 1 && db.Database.GetMigrations().Single().EndsWith("InitialTracking"), "SQLite migration isolation");
await db.Database.MigrateAsync();
var user = new AppUser { Id = "test-user", UserName = "test", DisplayName = "Test" };
db.Users.Add(user); await db.SaveChangesAsync();
var service = new IntakeService(db);
foreach (var group in Enum.GetValues<IntakeGroup>()) {
    var id = await service.CreateAsync(new ShipmentInput { Reference = group.ToString(), Group = group, ExpectedEnvelopes = 5 }, user);
    var shipment = (await db.Shipments.FindAsync(id))!;
    var oldVersion = shipment.Version;
    await service.AddBagAsync(id, new BagInput { Barcode = group.ToString(), PollingStationCode = "001", Version = oldVersion, RegularEnvelopes = group == IntakeGroup.Posta ? 5 : 0, TotalEnvelopes = group == IntakeGroup.Posta ? 0 : 5 }, user);
    var rejected = false;
    try { await service.CloseAsync(id, oldVersion, user); } catch (IntakeException) { rejected = true; }
    Check(rejected, group + " rejects stale version");
    await service.CloseAsync(id, shipment.Version, user);
    Check(shipment.Status == IntakeStatus.Closed, group + " completes intake");
}
Check(await db.AuditEntries.CountAsync() == 9, "Audit records all successful mutations");
Console.WriteLine("Provider checks passed. SQL Server DDL was checked without connecting to a live SQL Server.");
