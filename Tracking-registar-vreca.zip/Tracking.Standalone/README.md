# Tracking — prijem i registar vreća

Samostalna ASP.NET Core MVC / .NET 10 aplikacija sa zasebnim Identity loginom i ulogama.

## Instalacija i nadogradnja

Preuzmite `Tracking-registar-vreca.zip` i raspakujte direktorij `Tracking.Standalone`. Otvorite `src/Tracking.Web/Tracking.Web.csproj` u Visual Studiju.

**Ako već imate bazu i korisnika, pratite [UPGRADE-REGISTRY.md](UPGRADE-REGISTRY.md)**. Upute sadrže redoslijed SQL skripti, primjer konekcije za Visual Studio i PowerShell pokretanje. Ne kreirajte bazu niti administratora ponovo.

Za novu SQL Server instalaciju izvršite `database/01-create-tracking.sql`, `02-upgrade-bag-registry.sql` i `03-import-polling-stations.sql`, pa pokrenite:

```powershell
.\Start-Tracking.ps1 -SqlServer '.\SQLEXPRESS' -TrustServerCertificate -Initialize
```

Unesite korisničko ime, e-mail i lozinku prvog administratora. Nema ugrađenih naloga ni lozinki. Lozinka: najmanje 12 znakova, veliko i malo slovo, broj i poseban znak. Naredni put izostavite `-Initialize`. Zamijenite SQL instancu svojom; zastavica za povjerenje certifikatu namijenjena je lokalnoj probi.

Bez SQL Servera: `Start-Tracking.ps1 -ImportPollingStations` koristi SQLite i učitava priloženi šifrarnik. Provideri imaju odvojene migracije i korisnike. Server je dostupan na http://localhost:5180 dok PowerShell radi; Ctrl+C ga zaustavlja.

Potrebni su .NET 10 SDK, pristup NuGetu pri prvom restoreu i SQL Server ako koristite SQL varijantu.

## Uključeno

- Zaseban login, promjena vlastite lozinke, zaključavanje nakon 5 pogrešnih pokušaja na 15 minuta, četiri uloge i administratorsko kreiranje korisnika.
- Kategorije Pošta, Mobilni, Nepotvrđeni, DKP i Odsustvo.
- Šifrarnik 662 biračka mjesta iz dostavljene skripte, s tekstualnim šiframa, nazivima, opštinama i svim izvornim brojevima glasača.
- Generisanje vreća po biračkim mjestima, pojedinačno dodavanje, Pošta po količini, pregled i filtriranje, brisanje nezaprimljenih vreća i audit.
- Prijem samo generisanih vreća odgovarajuće kategorije; automatsko preuzimanje biračkog mjesta.
- Pretraga pošiljki i barkodova, količinska kontrola, zaključavanje prijema, ispravke zaglavlja s razlogom i historija promjena.

## Preostali dogovoreni rad

Prijem trenutno zadržava zajedničko zaglavlje svih kategorija iz prve etape. Zaseban prijem drugih kategorija i grupni tok Pošte prema slikama, izmjene primljenih vreća, šifrarnik razloga odbijanja, kontrolno brojanje i prijem za verifikaciju slijede u narednoj etapi. Nisu implementirani sama verifikacija koverata, kutije, dalje sortiranje i izvještaji. Covid nije uključen.

## Provjere

Iz direktorija koji sadrži `outputs/Tracking` pokrenuti:

```powershell
dotnet run --project outputs/Tracking/tests/ProviderChecks
```

Kod raspakovanog projekta možete pokrenuti test iz proizvoljnog direktorija uz apsolutnu putanju do JSON-a kao prvi argument. HTTP provjere u `tests/registry_http_checks.py` pokreću se nad odvojenom testnom bazom i kreiraju testne naloge; ne pokretati nad radnom bazom. Nalaz je u [VALIDATION.md](VALIDATION.md).

## Server

Za IIS instalirati .NET 10 Hosting Bundle i uraditi `dotnet publish src/Tracking.Web -c Release -o publish`. Podesiti Production okruženje, SQL provider i konekciju te trajni direktorij `Tracking__DataDirectory` za Data Protection ključeve. Identitet aplikacije mora imati pristup bazi i direktoriju. Koristiti HTTPS i backup. Lokalno pokretanje ne objavljuje aplikaciju na internetu.
