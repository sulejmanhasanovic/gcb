# Provjera registra vreća — 24.09.2026.

- Release build: uspješan, 0 grešaka. NuGet audit upozorenje NU1900: mrežni pristup podacima o ranjivostima nije bio dostupan; skeniranje paketa nije potvrđeno.
- 59 automatizovanih provjera: oba EF providera i model snapshoti, migracija postojeće SQLite baze bez gubitka starog prijema, uvoz 662 mjesta i ponovni uvoz, sve četiri mape kategorija, početne nule, numeracija Pošte i preskakanje starih oznaka, pojedinačno/grupno generisanje bez duplikata, prijem u svih pet kategorija, pogrešna/nepoznata vreća, stare verzije, zaštita zaprimljenih vreća, atomarno odbijanje miješanog brisanja i audit.
- 16 HTTP provjera: prijava, anonimni pristup, prikaz i filteri, neispravna kategorija, CSRF za generisanje/brisanje, zabrana direktnih mutacija operateru prijema i ulozi pregled.
- Preglednik: potvrđeni prikaz registra, generisanje tri poštanske vreće, pojedinačna vreća Odsustvo 001A501 i promjena kategorije koja filtrira biračka mjesta.
- SQL Server: generisane odvojene migracije, idempotentna nadogradnja i skripta uvoza; DDL provjeren. Nema dostupne žive instance za izvršavanje SQL skripti, pa taj korak nije potvrđen.
- Testovi i browser koriste zasebnu lokalnu SQLite bazu; ona, korisnici, lozinke i ključevi nisu u paketu.
