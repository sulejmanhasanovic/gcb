using System.ComponentModel.DataAnnotations;
namespace Tracking.Web.Models;
public class ShipmentInput : IValidatableObject {
    [Required(ErrorMessage = "Unesite oznaku pošiljke."), StringLength(40), Display(Name = "Oznaka pošiljke / prijema")] public string Reference { get; set; } = "";
    [EnumDataType(typeof(IntakeGroup)), Display(Name = "Grupa")] public IntakeGroup Group { get; set; } = IntakeGroup.Posta;
    [DataType(DataType.Date), Display(Name = "Datum prijema")] public DateOnly ReceivedDate { get; set; } = DateOnly.FromDateTime(DateTime.Today);
    [Range(0, 1000000), Display(Name = "Najavljeni broj koverata")] public int ExpectedEnvelopes { get; set; }
    [Range(0, 1000000), Display(Name = "Neuručene pošiljke")] public int Undelivered { get; set; }
    [Range(0, 1000000), Display(Name = "Ostali materijali")] public int OtherMaterials { get; set; }
    [StringLength(1000), Display(Name = "Napomena")] public string? Comment { get; set; }
    public Guid Version { get; set; }
    [StringLength(1000), Display(Name = "Razlog ispravke")] public string? Reason { get; set; }
    public IEnumerable<ValidationResult> Validate(ValidationContext context) {
        if (ReceivedDate < new DateOnly(2000, 1, 1) || ReceivedDate > DateOnly.FromDateTime(DateTime.Today)) yield return new("Datum mora biti između 01.01.2000. i danas.", [nameof(ReceivedDate)]);
        if (Group != IntakeGroup.Posta && (Undelivered != 0 || OtherMaterials != 0)) yield return new("Neuručene pošiljke i ostali materijali unose se samo za Poštu.");
        if ((long)ExpectedEnvelopes + Undelivered + OtherMaterials == 0) yield return new("Unesite barem jednu kovertu ili drugi materijal.");
    }
}
public class BagInput {
    public Guid Version { get; set; }
    [Required(ErrorMessage = "Unesite ili skenirajte barkod vreće."), StringLength(40), Display(Name = "Barkod / oznaka vreće")] public string Barcode { get; set; } = "";
    [StringLength(20), Display(Name = "Poštanski pretinac")] public string? PoBox { get; set; }
    [Range(0, 1000000), Display(Name = "Redovne koverte")] public int RegularEnvelopes { get; set; }
    [Range(0, 1000000), Display(Name = "Brza pošta")] public int ExpressEnvelopes { get; set; }
    [Range(0, 1000000), Display(Name = "Broj koverata")] public int TotalEnvelopes { get; set; }
    [StringLength(1000), Display(Name = "Napomena uz vreću")] public string? Comment { get; set; }
}
public class LoginInput {
    [Required, Display(Name = "Korisničko ime")] public string UserName { get; set; } = "";
    [Required, DataType(DataType.Password), Display(Name = "Lozinka")] public string Password { get; set; } = "";
    public string? ReturnUrl { get; set; }
}
public class UserInput {
    [Required, StringLength(80), Display(Name = "Korisničko ime")] public string UserName { get; set; } = "";
    [Required, StringLength(100), Display(Name = "Ime i prezime")] public string DisplayName { get; set; } = "";
    [Required, EmailAddress, Display(Name = "E-mail")] public string Email { get; set; } = "";
    [Required, StringLength(128, MinimumLength = 12), DataType(DataType.Password), Display(Name = "Početna lozinka")] public string Password { get; set; } = "";
    [Required, Display(Name = "Uloga")] public string Role { get; set; } = Roles.Receiver;
}
public class PasswordInput {
    [Required, DataType(DataType.Password), Display(Name = "Trenutna lozinka")] public string CurrentPassword { get; set; } = "";
    [Required, StringLength(128, MinimumLength = 12), DataType(DataType.Password), Display(Name = "Nova lozinka")] public string NewPassword { get; set; } = "";
    [Required, Compare(nameof(NewPassword), ErrorMessage = "Lozinke se ne podudaraju."), DataType(DataType.Password), Display(Name = "Ponovite novu lozinku")] public string ConfirmPassword { get; set; } = "";
}
public class IntakeList {
    public List<Shipment> Shipments { get; set; } = [];
    public Dictionary<IntakeGroup, int> Counts { get; set; } = [];
    public IntakeGroup? Group { get; set; }
    public string? Search { get; set; }
    public IntakeStatus? Status { get; set; }
    public int Page { get; set; }
    public int Total { get; set; }
}
public class IntakeDetails {
    public List<GeneratedBag> AvailableBags { get; set; } = [];
    public Shipment Shipment { get; set; } = null!;
    public BagInput Bag { get; set; } = new();
    public List<AuditEntry> History { get; set; } = [];
}
