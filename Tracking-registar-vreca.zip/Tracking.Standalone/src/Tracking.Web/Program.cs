using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;

var builder = WebApplication.CreateBuilder(args);
// Console logging also works under restricted service accounts without Windows Event Log access.
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", LogLevel.Warning);
var dataPath = Path.GetFullPath(builder.Configuration["Tracking:DataDirectory"] ?? Path.Combine(builder.Environment.ContentRootPath, "App_Data"));
Directory.CreateDirectory(dataPath);
builder.Services.AddDataProtection().SetApplicationName("Tracking.Standalone").PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(dataPath, "keys")));
var provider = builder.Configuration["Database:Provider"] ?? "Sqlite";
if (provider.Equals("SqlServer", StringComparison.OrdinalIgnoreCase)) {
    var connection = builder.Configuration.GetConnectionString("Tracking")
        ?? throw new InvalidOperationException("Configure ConnectionStrings:Tracking for SQL Server.");
    builder.Services.AddDbContext<SqlServerTrackingDbContext>(o => o.UseSqlServer(connection));
    builder.Services.AddScoped<TrackingDbContext>(sp => sp.GetRequiredService<SqlServerTrackingDbContext>());
} else if (provider.Equals("Sqlite", StringComparison.OrdinalIgnoreCase)) {
    builder.Services.AddDbContext<TrackingDbContext>(o => o.UseSqlite($"Data Source={Path.Combine(dataPath, "tracking.db")};Foreign Keys=True"));
} else throw new InvalidOperationException("Database:Provider must be Sqlite or SqlServer.");
builder.Services.AddIdentity<AppUser, IdentityRole>(o => {
    o.Password.RequiredLength = 12; o.User.RequireUniqueEmail = true;
    o.Lockout.MaxFailedAccessAttempts = 5; o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
}).AddEntityFrameworkStores<TrackingDbContext>().AddDefaultTokenProviders();
builder.Services.ConfigureApplicationCookie(o => {
    o.Cookie.Name = "Tracking.Session"; o.Cookie.HttpOnly = true; o.Cookie.SameSite = SameSiteMode.Lax;
    o.Cookie.SecurePolicy = builder.Environment.IsDevelopment() ? CookieSecurePolicy.SameAsRequest : CookieSecurePolicy.Always;
    o.LoginPath = "/Account/Login"; o.AccessDeniedPath = "/Account/Denied";
    o.ExpireTimeSpan = TimeSpan.FromHours(8); o.SlidingExpiration = true;
});
builder.Services.Configure<SecurityStampValidatorOptions>(o => o.ValidationInterval = TimeSpan.Zero);
builder.Services.AddAuthorization(o => {
    o.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
    o.AddPolicy(Permissions.View, p => p.RequireRole(Roles.All));
    o.AddPolicy(Permissions.Receive, p => p.RequireRole(Roles.Admin, Roles.Supervisor, Roles.Receiver));
    o.AddPolicy(Permissions.Correct, p => p.RequireRole(Roles.Admin, Roles.Supervisor));
    o.AddPolicy(Permissions.Users, p => p.RequireRole(Roles.Admin));
});
builder.Services.AddControllersWithViews(o => o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()));
builder.Services.AddScoped<IntakeService>();
builder.Services.AddScoped<BagRegistryService>();
var app = builder.Build();
await using (var scope = app.Services.CreateAsyncScope()) {
    var database = scope.ServiceProvider.GetRequiredService<TrackingDbContext>().Database;
    // SQL Server schema is normally installed with database/01-create-tracking.sql.
    if (database.IsSqlite() || args.Contains("--initialize")) await database.MigrateAsync();
    var importIndex = Array.IndexOf(args, "--import-stations");
    if (importIndex >= 0) {
        if (importIndex + 1 >= args.Length) throw new InvalidOperationException("Specify the polling-stations.json path.");
        var added = await PollingStationImport.ImportAsync(scope.ServiceProvider.GetRequiredService<TrackingDbContext>(), args[importIndex + 1]);
        Console.WriteLine($"Učitano {added} novih biračkih mjesta.");
    } else await Bootstrap.InitializeAsync(scope.ServiceProvider, builder.Configuration);
}
if (args.Contains("--initialize") || args.Contains("--import-stations")) return;
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Account/Error"); app.UseHsts(); app.UseHttpsRedirection(); }
app.Use(async (ctx, next) => {
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "same-origin";
    ctx.Response.Headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'self'";
    if (!ctx.Request.Path.StartsWithSegments("/css") && !ctx.Request.Path.StartsWithSegments("/js")) ctx.Response.Headers.CacheControl = "no-store";
    await next();
});
app.UseStaticFiles(); app.UseRouting(); app.UseAuthentication(); app.UseAuthorization();
app.MapControllerRoute("default", "{controller=Intake}/{action=Index}/{id?}");
app.Run();
public partial class Program { }
