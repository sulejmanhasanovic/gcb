document.querySelectorAll("[data-group-selector]").forEach(select => {
    const fields = document.querySelector("[data-postal-fields]");
    const update = () => {
        const isPost = select.value === "1";
        fields.hidden = !isPost;
        fields.querySelectorAll("input").forEach(input => { input.disabled = !isPost; });
    };
    select.addEventListener("change", update); update();
});
document.querySelectorAll("[data-barcode]").forEach(input => {
    input.addEventListener("keydown", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            const inputs = Array.from(input.form.querySelectorAll("input:not([type=hidden]),textarea,select"));
            inputs[inputs.indexOf(input) + 1]?.focus();
        }
    });
});
const generationGroup = document.querySelector('#generate-group');
if (generationGroup) {
    const quantity = document.querySelector('#quantity');
    const station = document.querySelector('#station');
    const choices = Array.from(station.options).slice(1);
    const updateGeneration = () => {
        const postal = generationGroup.value === 'Posta';
        quantity.closest('.field').hidden = !postal;
        quantity.value = postal ? quantity.value : '1';
        station.closest('.field').hidden = postal;
        station.replaceChildren(new Option(postal ? 'Pošta bez biračkog mjesta' : 'Sva mjesta odabrane kategorije', ''));
        choices.filter(option => option.dataset.group === generationGroup.value).forEach(option => station.add(option));
    };
    generationGroup.addEventListener('change', updateGeneration);
    updateGeneration();
}
