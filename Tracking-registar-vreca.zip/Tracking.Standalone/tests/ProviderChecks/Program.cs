using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;

var checks = 0;
void Check(bool ok, string name) { if (!ok) throw new Exception(name); checks++; Console.WriteLine("PASS " + name); }
async Task Reject(Func<Task> action, string name) {
    var rejected = false;
    try { await action(); } catch (IntakeException) { rejected = true; }
    Check(rejected, name);
}
await using var sql = new SqlServerDesignFactory().CreateDbContext([]);
Check(sql.Database.GetMigrations().Count() == 2 && sql.Database.GetMigrations().Last().EndsWith("BagRegistrySqlServer"), "SQL Server migration isolation");
Check(!sql.Database.HasPendingModelChanges(), "SQL Server model matches migration");
var ddl = sql.Database.GenerateCreateScript();
Check(ddl.Contains("IDENTITY") && ddl.Contains("[PollingStations]") && ddl.Contains("[GeneratedBags]") && !ddl.Contains("AUTOINCREMENT"), "SQL Server registry DDL");
var options = new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source=:memory:").Options;
await using var db = new TrackingDbContext(options);
await db.Database.OpenConnectionAsync();
Check(db.Database.GetMigrations().Count() == 2, "SQLite migration isolation");
Check(!db.Database.HasPendingModelChanges(), "SQLite model matches migration");
// Upgrade from the first release with existing operational records.
await db.GetService<IMigrator>().MigrateAsync("20260923082830_InitialTracking");
var user = new AppUser { Id = "test-user", UserName = "test", DisplayName = "Test" };
db.Users.Add(user); await db.SaveChangesAsync();
await db.Database.ExecuteSqlRawAsync("INSERT INTO Shipments (Reference, \"Group\", ReceivedDate, ExpectedEnvelopes, Undelivered, OtherMaterials, Status, CreatedById, CreatedAtUtc, Version) VALUES ('LEGACY',1,'2026-09-23',5,0,0,1,'test-user','2026-09-23','00000000-0000-0000-0000-000000000001')");
await db.Database.ExecuteSqlRawAsync("INSERT INTO Bags (ShipmentId,Barcode,RegularEnvelopes,ExpressEnvelopes,TotalEnvelopes,CreatedById,CreatedAtUtc) VALUES (1,'001',5,0,5,'test-user','2026-09-23')");
await db.Database.MigrateAsync();
Check(await db.Bags.CountAsync() == 1 && (await db.Bags.SingleAsync()).GeneratedBagId == null, "Upgrade preserves old receipt");
var dataFile = Path.GetFullPath(args.Length > 0 ? args[0] : "outputs/Tracking/database/polling-stations.json");
Check(await PollingStationImport.ImportAsync(db, dataFile) == 662, "Imports all 662 supported polling stations");
Check(await PollingStationImport.ImportAsync(db, dataFile) == 0, "Re-import is idempotent");
Check(await db.PollingStations.CountAsync(x => x.Group == IntakeGroup.Dkp) == 20 && await db.PollingStations.CountAsync(x => x.Group == IntakeGroup.Odsustvo) == 114, "DKP and Odsustvo mappings");
Check(await db.PollingStations.AnyAsync(x => x.Code.StartsWith("0") && x.MunicipalityCode!.StartsWith("0")), "Leading zeroes retained");
var registry = new BagRegistryService(db);
var intake = new IntakeService(db);
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Posta, Quantity = 3 }, user) == 3, "Postal bulk generation");
Check(!await db.GeneratedBags.AnyAsync(x => x.Barcode == "001") && await db.GeneratedBags.AnyAsync(x => x.Barcode == "002"), "Postal sequence skips legacy barcodes");
var deletedPostal = await db.GeneratedBags.SingleAsync(x => x.Barcode == "004");
Check(await registry.DeleteAsync([deletedPostal.Id], user) == 1, "Delete unreceived postal bag");
await registry.GenerateAsync(new() { Group = IntakeGroup.Posta }, user);
Check(await db.GeneratedBags.AnyAsync(x => x.Barcode == "005") && !await db.GeneratedBags.AnyAsync(x => x.Barcode == "004"), "Deleted postal number not reused");
foreach (var group in Enum.GetValues<IntakeGroup>().Where(x => x != IntakeGroup.Posta)) {
    var station = await db.PollingStations.FirstAsync(x => x.Group == group);
    Check(await registry.GenerateAsync(new() { Group = group, PollingStationId = station.Id }, user) == 1, group + " single generation");
    Check(await registry.GenerateAsync(new() { Group = group, PollingStationId = station.Id }, user) == 0, group + " prevents duplicate generation");
}
await Reject(() => registry.GenerateAsync(new() { Group = IntakeGroup.Posta, PollingStationId = 1 }, user), "Postal station rejected");
await Reject(() => registry.GenerateAsync(new() { Group = IntakeGroup.Posta, Quantity = 1001 }, user), "Generation quantity bounded");
foreach (var group in Enum.GetValues<IntakeGroup>()) {
    var generated = await db.GeneratedBags.Include(x => x.PollingStation).FirstAsync(x => x.Group == group);
    var id = await intake.CreateAsync(new ShipmentInput { Reference = group.ToString(), Group = group, ExpectedEnvelopes = 5 }, user);
    var shipment = (await db.Shipments.FindAsync(id))!;
    var oldVersion = shipment.Version;
    BagInput Input(string barcode) => new() { Barcode = barcode, Version = oldVersion, RegularEnvelopes = group == IntakeGroup.Posta ? 5 : 0, TotalEnvelopes = group == IntakeGroup.Posta ? 0 : 5 };
    await Reject(() => intake.AddBagAsync(id, Input("NOT-GENERATED"), user), group + " rejects unknown bag");
    var other = await db.GeneratedBags.FirstAsync(x => x.Group != group);
    await Reject(() => intake.AddBagAsync(id, Input(other.Barcode), user), group + " rejects wrong category");
    await intake.AddBagAsync(id, Input(generated.Barcode), user);
    var receipt = await db.Bags.SingleAsync(x => x.GeneratedBagId == generated.Id);
    Check(receipt.PollingStationCode == generated.PollingStation?.Code, group + " receives generated bag with automatic station");
    await Reject(() => registry.DeleteAsync([generated.Id], user), group + " protects received bag");
    await Reject(() => intake.CloseAsync(id, oldVersion, user), group + " rejects stale version");
    await intake.CloseAsync(id, shipment.Version, user);
    Check(shipment.Status == IntakeStatus.Closed, group + " completes intake");
}
var freeBag = await db.GeneratedBags.FirstAsync(x => x.Receipt == null);
var usedBag = await db.GeneratedBags.FirstAsync(x => x.Receipt != null);
await Reject(() => registry.DeleteAsync([freeBag.Id, usedBag.Id], user), "Mixed deletion batch rejected atomically");
Check(await db.GeneratedBags.AnyAsync(x => x.Id == freeBag.Id), "Unreceived bag remains after failed batch");
var beforeCount = await db.GeneratedBags.CountAsync();
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Mobilni }, user) == 384, "Bulk station generation skips existing");
Check(await registry.GenerateAsync(new() { Group = IntakeGroup.Mobilni }, user) == 0, "Repeated bulk generation is idempotent");
Check(await db.AuditEntries.AnyAsync(x => x.Action == "Generisane vreće") && await db.AuditEntries.AnyAsync(x => x.Action == "Obrisane nezaprimljene vreće"), "Registry mutations audited");
Console.WriteLine($"{checks} checks passed. SQL Server DDL only; no live SQL Server available.");

