# Validation — scanning stage, 2026-09-24

- Release build passed with zero errors; NU1900: NuGet vulnerability metadata unavailable.
- ProviderChecks: 147 checks passed again against the extended schema. Includes upgrade preserving an existing receipt, provider migration isolation and SQL Server model/DDL consistency, station import, generation and all five intake/workflow categories.
- ScanningChecks: 72 checks passed. All six categories, eligibility, type, station, duplicates, unknown/malformed JMBG, operator/time, separate elections, real competing-context saves for duplicate and finish/scan races, transaction rollback and the database unique constraint.
- scanning_http_checks.py: 72 checks passed on a fresh disposable SQLite preview, including authentication, role authorization, CSRF, all six start/scan/finish flows, no preloading, duplicate/finished posts, masked JMBG and menu order. Required environment variables are listed in the script. Uses synthetic voter data only; each full run requires a fresh preview, including a fresh postal session.
- Total executed in this stage: 291 checks. Earlier registry/workflow/postal HTTP suites remain in tests; their previous 65 checks were not rerun in this stage.
- Browser: verified category/station list, start, Enter submits a synthetic JMBG, success/status/count, input clear and autofocus, collapsible menu. No real voter records used.
- SQL Server migration and import SQL generated/reviewed. The local service is running but connection failed with Windows/SSL credential errors. No live SQL Server execution is claimed; run 05/06 on a copy of the target database.
- Package excludes database files, data-protection keys, personal paths, local test credentials and build/cache outputs.
