using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Tracking.Web.Data;
using Tracking.Web.Models;
using Tracking.Web.Services;

var count=0;
void Check(bool ok,string name){if(!ok)throw new Exception(name);Console.WriteLine("PASS "+name);count++;}
var config=new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{{"Tracking:ElectionCode","TEST"}}).Build();
var file=Path.Combine(Path.GetTempPath(),"tracking-scan-"+Guid.NewGuid()+".db");
var interceptor=new RaceInterceptor();
var options=new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source="+file).AddInterceptors(interceptor).Options;
await using var db=new TrackingDbContext(options);
await db.Database.MigrateAsync();
Check(!db.Database.HasPendingModelChanges(),"SQLite model and migration match");
await using var sql=new SqlServerDesignFactory().CreateDbContext([]);
Check(!sql.Database.HasPendingModelChanges(),"SQL Server model and migration match");
Check(sql.Database.GetMigrations().Count()==4,"SQL Server migration isolation");
var ddl=sql.Database.GenerateCreateScript();
Check(ddl.Contains("CREATE UNIQUE INDEX [IX_VotesCast_ElectionCode_VoterId]") && ddl.Contains("[FK_ScanningSessions_AspNetUsers_StartedById]"),"SQL Server unique voter and operator constraints");
db.Users.AddRange(new AppUser{Id="operator",UserName="operator",DisplayName="Operater 1"},new AppUser{Id="other",UserName="other",DisplayName="Operater 2"});
int n=0;
foreach(var c in Enum.GetValues<ScanCategory>()){
    db.Voters.Add(new Voter{ElectionCode="TEST",Jmbg=(++n).ToString("D13"),FirstName="Test",LastName=ScanLabels.Category(c),IsEligible=true,SourceEligibilityCode="1",SourceTypeCode=ScanLabels.SourceType(c),PollingStationCode="PS"+(int)c});
}
db.Voters.AddRange(
    new Voter{ElectionCode="TEST",Jmbg="0000000000100",IsEligible=false,SourceTypeCode="N",PollingStationCode="PS1"},
    new Voter{ElectionCode="TEST",Jmbg="0000000000101",IsEligible=true,SourceTypeCode="N",PollingStationCode="OTHER"},
    new Voter{ElectionCode="TEST",Jmbg="0000000000102",IsEligible=true,SourceTypeCode="N",PollingStationCode="PS1"},
    new Voter{ElectionCode="TEST",Jmbg="0000000000103",IsEligible=true,SourceTypeCode="N",PollingStationCode="PS1"},
    new Voter{ElectionCode="TEST",Jmbg="0000000000104",IsEligible=true,SourceTypeCode="N",PollingStationCode="RACE"},
    new Voter{ElectionCode="OTHER-ELECTION",Jmbg="0000000000001",IsEligible=true,SourceTypeCode="N",PollingStationCode="PS1"});
await db.SaveChangesAsync();
var service=new ScanningService(db,config);
var sessions=new Dictionary<ScanCategory,int>();
foreach(var c in Enum.GetValues<ScanCategory>()){
    var list=await service.ListAsync(c,null,1);
    Check(list.Total>0,"List category "+c);
    var id=await service.StartAsync(c,"PS"+(int)c,"operator");sessions[c]=id;
    Check(await service.StartAsync(c,"PS"+(int)c,"other")==id,"Opening resumes existing session "+c);
    Check(!await db.VotesCast.AnyAsync(x=>x.ScanningSessionId==id),"Opening creates no votes "+c);
    var detail=(await service.DetailsAsync(id,1))!;
    Check(detail.Session.Status==ScanStatus.Started && detail.Attempts.Count==0,"Started state "+c);
    var result=await service.ScanAsync(id,((int)c).ToString("D13"),"operator");
    Check(result.Accepted,"Accept category "+c);
    Check((await service.DetailsAsync(id,1))!.Session.Status==ScanStatus.InProgress,"In progress state "+c);
    Check(!(await service.ScanAsync(id,((int)c).ToString("D13"),"other")).Accepted,"Reject duplicate "+c);
}
var ni=sessions[ScanCategory.Nepotvrdjeni];
foreach(var (jmbg,message) in new[]{("abc","13 cifara"),("0000000000999","nije pronađen"),("0000000000100","nema pravo"),("0000000000004","kategoriju"),("0000000000101","ne pripada")}){
    var result=await service.ScanAsync(ni,jmbg,"operator");Check(!result.Accepted && result.Message.Contains(message),"Reject "+message);
}
Check(await db.VotesCast.CountAsync()==6,"Rejected attempts never increase turnout");
Check(await db.ScanAttempts.CountAsync(x=>!x.Accepted)==11,"Rejected attempts are retained");
var vote=await db.VotesCast.FirstAsync();
Check(vote.CreatedById=="operator" && vote.CreatedAtUtc>DateTime.UtcNow.AddMinutes(-5),"Operator and server timestamp recorded");
Check(vote.RegisteredPollingStationCode=="PS1" && vote.RegisteredSourceTypeCode=="N","Registered station and type snapshot");
Check((await service.DetailsAsync(sessions[ScanCategory.Posta],1))!.Session.PollingStationCode=="","Postal session independent of polling station");
Check((await service.ListAsync(ScanCategory.Redovni,null,1)).Accepted==1,"Regular turnout uses actual scanned votes");
var otherService=new ScanningService(db,new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{{"Tracking:ElectionCode","OTHER-ELECTION"}}).Build());
var otherId=await otherService.StartAsync(ScanCategory.Nepotvrdjeni,"PS1","operator");
Check((await otherService.ScanAsync(otherId,"0000000000001","operator")).Accepted,"Same JMBG can vote in another election");
Check(await service.DetailsAsync(otherId,1)==null,"Other election session not displayed");
try{await service.ScanAsync(otherId,"0000000000001","operator");throw new Exception("Expected election rejection");}catch(ScanningException){Check(true,"Cross election write rejected");}
// Simulate another request committing between our read and SaveChanges.
var plainOptions=new DbContextOptionsBuilder<TrackingDbContext>().UseSqlite("Data Source="+file).Options;
interceptor.BeforeSave=async()=>{await using var competitor=new TrackingDbContext(plainOptions);var s=new ScanningService(competitor,config);Check((await s.ScanAsync(ni,"0000000000102","other")).Accepted,"Concurrent operator accepts first");};
Check(!(await service.ScanAsync(ni,"0000000000102","operator")).Accepted,"Concurrent duplicate is rejected after retry");
Check(await db.VotesCast.CountAsync(x=>x.Voter.Jmbg=="0000000000102")==1,"Concurrent requests produce one vote");
interceptor.BeforeSave=async()=>{await using var competitor=new TrackingDbContext(plainOptions);await new ScanningService(competitor,config).FinishAsync(ni,"other");};
try{await service.ScanAsync(ni,"0000000000103","operator");throw new Exception("Expected finished rejection");}catch(ScanningException){Check(true,"Concurrent finish blocks stale scan");}
Check(!await db.VotesCast.AnyAsync(x=>x.Voter.Jmbg=="0000000000103"),"Stale scan rolls back vote");
Check(!await db.ScanAttempts.AnyAsync(x=>x.Voter!=null && x.Voter.Jmbg=="0000000000103"),"Stale scan rolls back attempt");
Check((await service.DetailsAsync(ni,1))!.Session.CompletedById=="other","Finishing records operator");
var race=await service.StartAsync(ScanCategory.Nepotvrdjeni,"RACE","operator");
interceptor.BeforeSave=async()=>{await using var competitor=new TrackingDbContext(plainOptions);await new ScanningService(competitor,config).ScanAsync(race,"0000000000104","other");};
try{await service.FinishAsync(race,"operator");throw new Exception("Expected stale finish");}catch(ScanningException){Check(true,"Concurrent scan requires finish review");}
Check((await service.DetailsAsync(race,1))!.Session.Status==ScanStatus.InProgress,"Stale finish does not overwrite scan");
await service.FinishAsync(race,"operator");await service.FinishAsync(race,"operator");
Check((await service.DetailsAsync(race,1))!.Session.Status==ScanStatus.Finished,"Finish is idempotent");
try{await service.ScanAsync(race,"0000000000104","operator");throw new Exception("Expected closed rejection");}catch(ScanningException){Check(true,"Finished session rejects further scans");}
// The unique index protects even writes that bypass the service.
db.ChangeTracker.Clear();var existing=await db.VotesCast.AsNoTracking().FirstAsync();existing.Id=0;db.VotesCast.Add(existing);
try{await db.SaveChangesAsync();throw new Exception("Expected constraint");}catch(DbUpdateException){db.ChangeTracker.Clear();Check(true,"Database enforces voter uniqueness");}
Console.WriteLine($"{count} scanning checks passed. Disposable database: {file}");

class RaceInterceptor : SaveChangesInterceptor {
    public Func<Task>? BeforeSave { get; set; }
    public override async ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData,InterceptionResult<int> result,CancellationToken cancellationToken=default){var action=BeforeSave;BeforeSave=null;if(action!=null)await action();return result;}
}
